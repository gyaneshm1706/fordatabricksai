<<<<<<< HEAD
# Building Agentic AI Systems on Databricks: lab repository

Hands-on labs and live-demo code for the seven 2-hour modules. One support-agent use case runs through the whole
program: a hand-written loop (M1), behind portable adapters (M2), grounded in Databricks data (M3–M4), with
governed tools (M5), evaluated and deployed (M6), then operated and composed with other agents (M7).

```
Agents_on_Databricks_Labs/
├─ data/                     orders.json + policies/*.md (shared by every lab)
├─ common/offline_model.py   deterministic rule-based "LLM" so Modules 1–2 run with no key or network
├─ module01/                 Lab 1 (local)   completed lab files + solution/ + chaos.py, check_lab.py, check_env.py
├─ module02/                 Lab 2 (local)   completed project   + solution/ + tests/contract
├─ databricks/
│  ├─ labs/                  completed lab notebooks                   ← import this folder
│  ├─ solutions/             reference notebooks (with SOLUTION markers, source of truth)
│  └─ local_checks/          static check + local PySpark dry run (no workspace needed)
├─ handbook/                 Databricks_Lab_Handbook.pdf: step-by-step setup and Labs 3–7 (rebuild: build_handbook.py)
├─ outputs/                  saved output of every local run (see "What has been verified")
├─ run_local_labs.py         runs every Module 1–2 lab and demo, writes outputs/local_labs_output.txt
├─ make_starters.py          writes completed (--fill) or exercise TODO (--todo) lab files from the solutions
└─ requirements.txt          Modules 1–2
```

## Module → lab map

| Module | Lab files | Demos in the slides |
|---|---|---|
| 1 Agent architecture | `module01/`: `tools.py` (A), `agent.py` (A), `memory.py` (B), `safe_call.py` (C), `chaos.py`, `check_lab.py` | Demo 1 `agent.py` with `VERBOSE=1`; Demo 2 `GULLIBLE=1 APPROVAL=off`, then `APPROVAL=on`, then `WRAP_UNTRUSTED=1` |
| 2 Any platform | `module02/`: `core/factory.py` (A), `adapters/*` (B), tracer config (C), `tests/contract` (D) | Demo 3 `AGENT_ENV=offline` vs `cloud`; Demo 4 `tracer: langfuse` or `console` |
| 3 Data grounding | `00_setup` (prework), `01_prepare_data` (A), `02_vector_search` (B), `04_rag_agent` + `agents/rag_agent.py` (C–D) | Demo 5 workspace tour; Demo 6 `02_vector_search`; `03_ai_functions`; Demo 7 `04_rag_agent` |
| 4 Genie | `05_genie_agent` (A, C, D), `06_semantics` (B), `lab_assets/genie_instructions.md`, `benchmarks_template.csv` | Demo 8 `06_semantics`; Demo 9 `05_genie_agent` Part D |
| 5 Tools and governance | `07_tools` (A), `09_mcp` (B), `08_governance` + `agents/support_agent.py` (C–D) | Demo 10 `07_tools`; Demo 11 `09_mcp`; Demo 12 `08_governance` Part C |
| 6 Evaluate, optimise, deploy | `10_evaluate` (A), `11_optimize` (B), `12_deploy` (C–D) | Demos 13–15, same notebooks |
| 7 Ops, multi-agent, Agent Bricks | `14_multi_agent` (lab), `13_ops` (demo) | Demo 16 `13_ops`; Demo 17 `14_multi_agent` Part B; Demo 18 Agent Bricks UI |

## Modules 1–2: local setup (open source only)

```bash
python -m venv .venv
source .venv/bin/activate          # Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
python run_local_labs.py           # runs every Module 1–2 lab and demo; output in outputs/local_labs_output.txt
```

`MODEL=offline` (the default) needs no key: a deterministic rule-based model in `common/offline_model.py` that calls
tools like an LLM. For a real model: `pip install langchain-anthropic` (or `-openai`, `-ollama`) and set, for example,
`MODEL=anthropic:claude-sonnet-5-5` plus `ANTHROPIC_API_KEY`.

**Lab 1** (in `module01/`): `tools.py`, `agent.py`, `memory.py`, `safe_call.py` are complete. Check them with
`python check_lab.py` (checkpoints A, B, D) and `python chaos.py` (6 chaos tests); `--solution` runs the reference.
Participants' exercise versions: `python make_starters.py --todo` (your own completed files are kept).

**Lab 2** (in `module02/`): `core/` and `adapters/` are complete. Run
`python app.py --questions questions.txt` and `pytest tests/contract`. After an adapter change:
`CONTRACT_ENVS=offline,cloud pytest tests/contract`. `AGENT_ENV=local` needs Ollama and `python ingest.py` (Chroma).

## Modules 3–7: Databricks setup

1. **Import:** add this repository as a **Git folder** in the workspace (notebooks read `data/policies` from it).
2. **Instructor, 1–2 days before Module 3:** edit the first cell of `databricks/solutions/_config.py` (and the copy in
   `labs/`): endpoint names from your Serving page, `WAREHOUSE_ID`, group names. Then run `00_instructor_setup` and
   work through its checklist (Vector Search endpoint, checkpoint index, shared Genie space, analyst test user and
   secret `course/analyst_pat`, endpoint quotas).
3. **Participants, prework:** run `databricks/labs/00_setup` until it prints **ALL CHECKS PASSED**.
4. **Dry run:** run every `solutions/` notebook once in the delivery workspace, then pin the package versions
   printed by `12_deploy` in the `%pip` cells.

Each participant works in `course.<user>_support`. Later labs read settings saved by earlier ones (active index,
Genie space id, endpoint name) from the `course_settings` table; see `get_setting` in `_config`.

## Starters and solutions

Solution files mark lab work with `# >>> SOLUTION: <hint>` … `# <<< SOLUTION` (optionally `# >>> STARTER`).
The lab folders (`module01/`, `module02/`, `databricks/labs/`) currently hold the **completed** versions.

```bash
python make_starters.py --fill    # completed lab files (default)
python make_starters.py --todo    # exercise versions with '# TODO: hint' for participants
python make_starters.py --check   # fail if a lab file differs from the reference
```

Lab files you completed by hand (no TODO left, different from the reference) are never overwritten; the script
lists them as "kept". Add `--force` to overwrite them. Edit only the solution files.

## What has been verified

| Part | Status | Evidence |
|---|---|---|
| Module 1 (your completed files) | 6/6 chaos tests, 3/3 checkpoints, Demo 1 (trace, parallel calls, refusal, hard stop) and all three Demo 2 injection runs behave as the slides describe | `outputs/local_labs_output.txt` |
| Module 2 (completed project) | 5 questions with console tracing and citations, fail-fast config error, 5/5 contract tests | `outputs/local_labs_output.txt` |
| Databricks notebooks, static | All 17 notebooks + 3 agent files: 0 undefined names or syntax errors (analysed together with `_config`) | `outputs/databricks_static_check.txt` |
| Databricks notebooks, local Spark | 16/16 checks: data generation (3,008 orders, North late rate highest), policy copy, section split, chunking, stable chunk ids, 12 benchmark SQLs run on the data | `outputs/databricks_local_dryrun.txt` |
| Databricks services | **Not executed**: Vector Search, Model Serving, Genie, UC functions, MLflow judges, MCP and AI Functions need a workspace. Run every `labs/` notebook once in the delivery workspace | — |

Local runs used the offline model (no API key was available); set `MODEL=...` to repeat them with a real model.

APIs most likely to need adjustment in your workspace (all marked in the notebooks): `ResponsesAgent` helpers,
`mlflow.genai.datasets.create_dataset` signature, production-monitoring scorer `register/start`, managed MCP URLs,
`vector_search()` SQL argument name, Genie SDK result method names, metric view YAML `version`, AI Gateway SDK
classes, serving `Route` field names, and on-behalf-of-user scope names.

## Notes that differ from the slides

- UC functions are read-only, so the approval-gated action writes an **address-change request** to a governed table
  (`address_change_requests`, MODIFY grant) through a SQL warehouse, rather than calling a UC function.
- `get_order_status` is a scalar SQL function returning JSON (incl. `days_late`), which works reliably as a tool.
- Our policies are Markdown, so `01_prepare_data` reads them as text; `ai_parse_document` is shown as an optional cell for PDFs.
- The deployed agent (Module 6) runs with actions disabled: approval across serving replicas needs a persistent
  checkpointer (for example Postgres on Lakebase). The approve/reject flow is demonstrated in the notebook (Lab 5C).
=======
# fordatabricksai
>>>>>>> 01f183f8cd675b6be651a8ff421a65951d49df6d
