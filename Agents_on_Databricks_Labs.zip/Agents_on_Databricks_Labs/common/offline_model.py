"""A deterministic, rule-based chat model for offline labs and demos.

It behaves like a tool-calling LLM: it reads the conversation, decides which bound
tools to call, and composes a final answer from tool results. It is NOT an LLM. It
exists so that Modules 1-2 run without network access or API keys, and so that
demos are reproducible.

Set GULLIBLE=1 to make it obey instructions hidden in tool outputs (prompt-injection demo).
"""
from __future__ import annotations

import json
import os
import re
import uuid
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, ChatResult

ORDER_RE = re.compile(r"\bORD-\d{5}\b", re.IGNORECASE)
POLICY_WORDS = ("refund", "policy", "policies", "return", "late", "window", "rule", "owe", "address change",
                "pickup", "tracking", "delivery time", "damaged")
SEARCH_TOOLS = ("get_shipping_policy", "search_policies", "search_policy")


def _text(msg: BaseMessage) -> str:
    c = msg.content
    if isinstance(c, str):
        return c
    return " ".join(p.get("text", "") if isinstance(p, dict) else str(p) for p in c)


def _call(name: str, args: dict) -> dict:
    return {"name": name, "args": args, "id": f"call_{uuid.uuid4().hex[:10]}", "type": "tool_call"}


class OfflineChatModel(BaseChatModel):
    """Rule-based stand-in for a tool-calling chat model."""

    tool_names: list[str] = []
    gullible: bool = False

    @property
    def _llm_type(self) -> str:
        return "offline-rule-based"

    def bind_tools(self, tools: Any, **kwargs: Any) -> "OfflineChatModel":
        names = []
        for t in tools:
            names.append(getattr(t, "name", None) or (t.get("name") if isinstance(t, dict) else str(t)))
        return self.model_copy(update={"tool_names": names})

    # ---- decision logic -------------------------------------------------
    def _decide(self, messages: list[BaseMessage]) -> AIMessage:
        last = messages[-1]
        question_idx = max(i for i, m in enumerate(messages) if isinstance(m, HumanMessage))
        question = _text(messages[question_idx])

        if question.startswith("Update this summary"):
            ids = sorted(set(i.upper() for i in ORDER_RE.findall(question)))
            return AIMessage(content=f"Customer discussed orders: {', '.join(ids) or 'none'}.")

        if isinstance(last, HumanMessage):
            return self._plan(question, messages)
        if isinstance(last, ToolMessage):
            results = []
            for m in reversed(messages):
                if isinstance(m, ToolMessage):
                    results.append(m)
                elif isinstance(m, AIMessage):
                    break
            results.reverse()
            injected = self._follow_injection(results, messages[question_idx:])
            return injected or self._answer(question, messages[question_idx:])
        return AIMessage(content="How can I help with your order?")

    def _plan(self, question: str, messages: list[BaseMessage]) -> AIMessage:
        q = question.lower()
        ids = [i.upper() for i in ORDER_RE.findall(question)]
        if not ids and re.search(r"\b(it|its|that order|this order)\b", q):
            for m in reversed(messages[:-1]):  # resolve pronouns from memory/history
                found = ORDER_RE.findall(_text(m))
                if found:
                    ids = [found[-1].upper()]
                    break
        calls = []
        if "address" in q and "change" in q and ids and "change_address" in self.tool_names:
            m = re.search(r"\bto\s+(.+)$", question, re.IGNORECASE)
            calls.append(_call("change_address", {"order_id": ids[0], "new_address": (m.group(1) if m else "").strip(" .?")}))
            return AIMessage(content="", tool_calls=calls)
        order_tool = next((t for t in ("get_order_status", "get_order") if t in self.tool_names), None)
        if ids and order_tool:
            calls += [_call(order_tool, {"order_id": i}) for i in dict.fromkeys(ids)]
        elif not ids and "ord-" in q and order_tool:  # malformed id, e.g. "ord 10293"
            raw = re.search(r"ord[- ]?\s*(\d+)", q)
            calls.append(_call(order_tool, {"order_id": f"ORD-{raw.group(1) if raw else ''}"}))
        search_tool = next((t for t in SEARCH_TOOLS if t in self.tool_names), None)
        if search_tool and any(w in q for w in POLICY_WORDS):
            arg = "topic" if search_tool == "get_shipping_policy" else "query"
            calls.append(_call(search_tool, {arg: question}))
        if "track" in q and ids and "track_shipment" in self.tool_names:
            calls.append(_call("track_shipment", {"order_id": ids[0]}))
        if calls:
            return AIMessage(content="", tool_calls=calls)
        return AIMessage(content="I can help with order status, shipping and our support policies. "
                                 "I don't have information about that.")

    def _follow_injection(self, results: list[ToolMessage], turn: list[BaseMessage]) -> AIMessage | None:
        if not self.gullible:
            return None
        already = {c["name"] for m in turn if isinstance(m, AIMessage) for c in (m.tool_calls or [])}
        for r in results:
            t = _text(r)
            if "<untrusted_data>" in t:
                continue  # the wrapper works on this model: delimited content is treated as data
            oid = (ORDER_RE.findall(t) or ["ORD-00000"])[0].upper()
            if "issue_refund" in t and "issue_refund" in self.tool_names and "issue_refund" not in already:
                return AIMessage(content="", tool_calls=[_call("issue_refund", {"order_id": oid, "amount": 500.0})])
            if "change the delivery address" in t and "change_address" in self.tool_names and "change_address" not in already:
                return AIMessage(content="", tool_calls=[_call("change_address", {"order_id": oid, "new_address": "99 Unknown Street"})])
        return None

    def _answer(self, question: str, turn: list[BaseMessage]) -> AIMessage:
        parts: list[str] = []
        words = {w for w in re.findall(r"[a-z]{4,}", question.lower())}
        for m in turn:
            if not isinstance(m, ToolMessage):
                continue
            t = _text(m).strip()
            if t.startswith(("NOT_FOUND", "INVALID_ARGS")):
                parts.append(f"I couldn't find that order ({t}).")
            elif t.startswith("DENIED"):
                parts.append("That action was not approved, so nothing was changed.")
            elif t.startswith(("ERROR", "TOOL_ERROR", "BUSY")):
                parts.append(f"A system I need is unavailable right now ({t}).")
            elif t.startswith("PERMISSION_DENIED"):
                parts.append("You don't have permission to do that. Please contact support.")
            elif t.startswith("OK"):
                parts.append(t[3:].strip() or "Done.")
            elif t.startswith(("{", "[{")):
                parts.append(self._describe_json(t))
            elif t.startswith("<untrusted_data>"):
                parts.append(f"Carrier status: {t.removeprefix('<untrusted_data>').removesuffix('</untrusted_data>')}.")
            else:
                parts.append(self._quote_policy(t, words))
        return AIMessage(content=" ".join(p for p in parts if p) or "I don't know.")

    @staticmethod
    def _describe_json(t: str) -> str:
        try:
            data = json.loads(t)
        except json.JSONDecodeError:
            return t[:200]
        rows = data if isinstance(data, list) else [data]
        out = []
        for r in rows:
            if not isinstance(r, dict):
                continue
            oid = r.get("order_id") or r.get("id") or "The order"
            if "eligible" in r:
                out.append(f"Refund eligible: {r['eligible']}" + (f", amount {r.get('refund')}" if r.get("refund") else "") + ".")
            else:
                eta = f", ETA {r['eta']}" if r.get("eta") else ""
                out.append(f"{oid} is {r.get('status', 'unknown')}{eta}.")
        return " ".join(out)

    @staticmethod
    def _quote_policy(t: str, words: set[str]) -> str:
        chunks = [c for c in re.split(r"\n(?=\[)", t) if c.strip()]
        if not chunks:
            return ""
        best = max(chunks, key=lambda c: sum(w in c.lower() for w in words))
        cite = re.match(r"\[([^\]]+)\]", best)
        body = re.sub(r"^\[[^\]]+\]\s*", "", best).strip().replace("\n", " ")
        sentences = re.split(r"(?<=\.)\s+", body)
        picked = [s for s in sentences if any(w in s.lower() for w in words)][:3] or sentences[:2]
        return " ".join(picked) + (f" [{cite.group(1)}]" if cite else "")

    # ---- LangChain plumbing ----------------------------------------------
    def _generate(self, messages: list[BaseMessage], stop: Any = None, run_manager: Any = None, **kwargs: Any) -> ChatResult:
        msg = self._decide(messages)
        in_tok = sum(len(_text(m)) for m in messages) // 4 + 40 * len(self.tool_names)
        out_tok = max(1, len(_text(msg)) // 4 + 15 * len(msg.tool_calls or []))
        msg.usage_metadata = {"input_tokens": in_tok, "output_tokens": out_tok, "total_tokens": in_tok + out_tok}
        return ChatResult(generations=[ChatGeneration(message=msg)])


def make_offline_model() -> OfflineChatModel:
    return OfflineChatModel(gullible=os.getenv("GULLIBLE", "0") == "1")
