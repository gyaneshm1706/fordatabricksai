---
doc_type: policy
policy_id: AC-300
region: GLOBAL
effective_date: 2026-03-01
---
# Address Change Policy (AC-300)

## When an address can change
The delivery address can be changed only while the order status is "placed".
Once an order is shipped, the address cannot be changed; the customer may refuse
delivery and reorder instead.

## Approval
Every address change requires approval by a human support agent, who verifies the
customer's identity before confirming the change.

## Format
New addresses must include street, city and PIN code.
