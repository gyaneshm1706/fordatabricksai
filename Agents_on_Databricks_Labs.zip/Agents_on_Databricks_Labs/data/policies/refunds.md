---
doc_type: policy
policy_id: RP-204
region: GLOBAL
effective_date: 2026-04-01
---
# Refund Policy (RP-204)

## Refund window
Customers may request a refund within 30 days of delivery for any undamaged item.
Refunds are paid to the original payment method within 7 business days.

## Late deliveries
An order is late when it is delivered after its promised date.
Orders delivered more than 2 days late are eligible for a late-delivery refund.
The refund is a percentage of the order value that depends on the customer tier:
gold customers receive 100%, silver customers receive 50% and standard customers receive 25%.
Orders 2 days late or less are not eligible, but the agent may offer a 10% voucher.

## Cancelled orders
Cancelled orders are refunded in full automatically. No request is needed.

## Who can issue refunds
Only human support staff can issue refunds. Automated assistants may calculate
eligibility and explain the policy, but must never issue a refund themselves.
