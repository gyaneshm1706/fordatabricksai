---
doc_type: policy
policy_id: RP-204
region: GLOBAL
effective_date: 2024-01-01
superseded: true
---
# Refund Policy (RP-204), 2024 edition (SUPERSEDED)

## Late deliveries
Orders delivered more than 5 days late are eligible for a flat refund of 200 INR,
regardless of customer tier.

## Refund window
Customers may request a refund within 14 days of delivery.
