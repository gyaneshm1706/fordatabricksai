---
doc_type: policy
policy_id: RT-410
region: IN
effective_date: 2026-02-01
---
# Returns Policy, India (RT-410)

## Return pickup
In India, return pickups are free for gold and silver customers. Standard customers
pay a 99 INR pickup fee.

## Return window
Items can be returned within 10 days of delivery. Electronics must be unopened.

## Damaged items
Damaged items are replaced free of charge for all tiers when reported within 48 hours
of delivery, with a photo of the damage.
