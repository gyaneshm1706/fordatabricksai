---
doc_type: policy
policy_id: RT-420
region: US
effective_date: 2026-02-01
---
# Returns Policy, United States (RT-420)

## Return shipping
In the United States, customers print a prepaid label. Return shipping is free for
all tiers.

## Return window
Items can be returned within 30 days of delivery.
