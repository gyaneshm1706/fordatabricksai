---
doc_type: policy
policy_id: SP-110
region: GLOBAL
effective_date: 2026-01-15
---
# Shipping Policy (SP-110)

## Delivery times
Standard delivery takes 5 to 7 days from the order date. Express delivery takes 2 days
in metro cities. The promised date shown at checkout is the commitment we measure against.

## Tracking
A tracking number is issued when an order is shipped. Orders in status "placed" do not
have a tracking number yet.

## Delays
If a carrier reports a delay, the estimated arrival (ETA) is updated automatically.
Customers are notified through their preferred channel (email, SMS or phone).
