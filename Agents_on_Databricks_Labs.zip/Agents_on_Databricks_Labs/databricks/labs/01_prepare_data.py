# Databricks notebook source
# MAGIC %md
# MAGIC # Lab 3 · Part A: prepare documents for grounding (12 min)
# MAGIC **Goal:** turn the policy files in your volume into an index-ready Delta table:
# MAGIC one row per chunk, a stable `chunk_id`, metadata for filters and citations, and **Change Data Feed** on.
# MAGIC
# MAGIC Bronze `policy_raw` (files) → silver `policy_text` (one row per section) → gold `policy_chunks` (CDF on)

# COMMAND ----------

# MAGIC %pip install -U -qqq langchain-text-splitters

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./_config

# COMMAND ----------

# MAGIC %md ## 1. Bronze: read the raw files
# MAGIC Our policies are Markdown, so we read them as whole text files. For PDFs and Office documents use the
# MAGIC `ai_parse_document` AI Function instead (optional cell below).

# COMMAND ----------

spark.sql(f"""
CREATE OR REPLACE TABLE {FQ}.policy_raw AS
SELECT _metadata.file_name AS file, value AS raw
FROM read_files('{VOLUME_PATH}/', format => 'text', wholeText => true)
""")
display(spark.table(f"{FQ}.policy_raw"))

# COMMAND ----------

# MAGIC %md
# MAGIC *Optional (PDF/DOCX demo):* `SELECT path, ai_parse_document(content) FROM read_files('<volume>/pdfs/', format => 'binaryFile')`.
# MAGIC Availability of `ai_parse_document` depends on region and workspace settings.

# COMMAND ----------

# MAGIC %md ## 2. Silver: one row per section, with metadata from the front matter

# COMMAND ----------

import re

from pyspark.sql import functions as F, types as T

section_schema = T.ArrayType(T.StructType([
    T.StructField("section", T.StringType()), T.StructField("text", T.StringType()),
    T.StructField("doc_type", T.StringType()), T.StructField("policy_id", T.StringType()),
    T.StructField("region", T.StringType()), T.StructField("effective_date", T.StringType()),
    T.StructField("superseded", T.BooleanType())]))


@F.udf(section_schema)
def split_sections(raw: str):
    # Parse the '---' front matter into metadata, then split the body on '## ' headings
    _, front, body = raw.split("---", 2)
    meta = dict(line.split(": ", 1) for line in front.strip().splitlines())
    out = []
    for block in re.split(r"\n(?=## )", body):
        lines = block.strip().splitlines()
        if lines and lines[0].startswith("## "):
            out.append((lines[0][3:].strip(), " ".join(lines[1:]).strip(), meta.get("doc_type"), meta.get("policy_id"),
                        meta.get("region"), meta.get("effective_date"), meta.get("superseded") == "true"))
    return out


(spark.table(f"{FQ}.policy_raw")
 .select("file", F.explode(split_sections("raw")).alias("s"))
 .select(F.col("file").alias("source"), "s.*")
 .withColumn("effective_date", F.to_date("effective_date"))
 .write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(f"{FQ}.policy_text"))
display(spark.table(f"{FQ}.policy_text"))

# COMMAND ----------

# MAGIC %md ## 3. Gold: chunk, add a stable id, enable Change Data Feed

# COMMAND ----------

import pandas as pd
from langchain_text_splitters import RecursiveCharacterTextSplitter

split = RecursiveCharacterTextSplitter(chunk_size=1200, chunk_overlap=150).split_text   # characters


@F.pandas_udf(T.ArrayType(T.StringType()))
def chunk(texts: pd.Series) -> pd.Series:
    return texts.apply(split)


# Explode chunks, prefix each with its heading, hash source+section+text into chunk_id, write with CDF on
(spark.table(f"{FQ}.policy_text")
 .withColumn("chunk_text", F.explode(chunk("text")))
 .withColumn("chunk_text", F.concat_ws(": ", "section", "chunk_text"))      # heading helps retrieval
 .withColumn("chunk_id", F.sha2(F.concat_ws("|", "source", "section", "chunk_text"), 256))
 .withColumn("token_count", F.ceil(F.length("chunk_text") / 4))
 .select("chunk_id", "chunk_text", "source", "section", "doc_type", "policy_id", "region",
         "effective_date", "superseded", "token_count")
 .write.mode("overwrite").option("overwriteSchema", "true")
 .option("delta.enableChangeDataFeed", "true")
 .saveAsTable(f"{FQ}.policy_chunks"))
# Make sure CDF is on even when the table already existed (the writer option only applies at creation)
spark.sql(f"ALTER TABLE {FQ}.policy_chunks SET TBLPROPERTIES (delta.enableChangeDataFeed = true)")

# COMMAND ----------

# MAGIC %md ## Checkpoint A

# COMMAND ----------

display(spark.sql(f"""
SELECT count(*) AS chunks, round(avg(token_count)) AS avg_tokens, max(token_count) AS max_tokens,
       count_if(superseded) AS superseded_chunks
FROM {FQ}.policy_chunks"""))
props = {r.key: r.value for r in spark.sql(f"SHOW TBLPROPERTIES {FQ}.policy_chunks").collect()}
assert props.get("delta.enableChangeDataFeed") == "true", "CDF is not enabled: the Delta Sync index needs it"
assert spark.table(f"{FQ}.policy_chunks").select("chunk_id").distinct().count() == spark.table(f"{FQ}.policy_chunks").count(), "chunk_id must be unique"
print("Checkpoint A passed: chunks ready, ids unique, CDF on")
