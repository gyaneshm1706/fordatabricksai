# Databricks notebook source
# MAGIC %md
# MAGIC # Lab 3 · Part B: Vector Search index, filters and recall (10 min) — also Demo 6
# MAGIC **Goal:** a Delta Sync index over `policy_chunks`, three filtered queries, and a recall@k number you can improve.

# COMMAND ----------

# MAGIC %pip install -U -qqq databricks-vectorsearch

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./_config

# COMMAND ----------

import time

from databricks.vector_search.client import VectorSearchClient

vsc = VectorSearchClient(disable_notice=True)

# Create a Delta Sync index with managed embeddings on chunk_text (TRIGGERED pipeline)
try:
    index = vsc.get_index(VS_ENDPOINT, INDEX)
    index.sync()                                  # picks up changed rows via Change Data Feed
    print("index exists: sync triggered")
except Exception:
    index = vsc.create_delta_sync_index(
        endpoint_name=VS_ENDPOINT,
        index_name=INDEX,
        source_table_name=f"{FQ}.policy_chunks",
        primary_key="chunk_id",
        pipeline_type="TRIGGERED",
        embedding_source_column="chunk_text",
        embedding_model_endpoint_name=EMBEDDING_ENDPOINT,
    )
    print("index creating")

# COMMAND ----------

# MAGIC %md Wait up to ~6 minutes. If it is not ready, the rest of the notebook uses the shared checkpoint index.

# COMMAND ----------

def ready(name):
    try:
        return vsc.get_index(VS_ENDPOINT, name).describe().get("status", {}).get("ready", False)
    except Exception:
        return False


for _ in range(36):
    if ready(INDEX):
        break
    time.sleep(10)
ACTIVE_INDEX = INDEX if ready(INDEX) else SHARED_INDEX
print(f"using {ACTIVE_INDEX}")
idx = vsc.get_index(VS_ENDPOINT, ACTIVE_INDEX)

# COMMAND ----------

# MAGIC %md ## Query: plain, filtered, hybrid

# COMMAND ----------

COLS = ["chunk_id", "source", "section", "region", "chunk_text"]


def show(res):
    for row in res["result"]["data_array"]:
        print(f"{row[-1]:.3f}  {row[1]} > {row[2]}  [{row[3]}]")


print("— no filter"); show(idx.similarity_search(query_text="Refund for a late delivery?", columns=COLS, num_results=4))
print("— India + global, current policies only")
show(idx.similarity_search(query_text="How do returns work?", columns=COLS, num_results=4,
                           filters={"region": ["IN", "GLOBAL"], "superseded": False}))
print("— exact identifier: ANN vs HYBRID")
show(idx.similarity_search(query_text="policy RP-204", columns=COLS, num_results=3))
show(idx.similarity_search(query_text="policy RP-204", columns=COLS, num_results=3, query_type="HYBRID"))

# COMMAND ----------

# MAGIC %md
# MAGIC **Lab task:** write three filtered queries of your own (e.g. US returns, current refund window, address-change approval).
# MAGIC Filter syntax can differ by endpoint type and SDK version; check the docs if a filter errors.

# COMMAND ----------

# MAGIC %md ## Measure recall@k on labelled questions

# COMMAND ----------

LABELLED = [  # (question, expected "source > section")
    ("Can I get my money back if the parcel came late?", "refunds.md > Late deliveries"),
    ("How many days do I have to ask for a refund?", "refunds.md > Refund window"),
    ("What happens to the money when an order is cancelled?", "refunds.md > Cancelled orders"),
    ("Can the chatbot issue my refund?", "refunds.md > Who can issue refunds"),
    ("How long does standard delivery take?", "shipping.md > Delivery times"),
    ("Why is there no tracking number for my order?", "shipping.md > Tracking"),
    ("The carrier says my package is delayed", "shipping.md > Delays"),
    ("Can I change where my order is delivered after it shipped?", "address_changes.md > When an address can change"),
    ("Who approves an address change?", "address_changes.md > Approval"),
    ("What must a new address include?", "address_changes.md > Format"),
    ("Is return pickup free in India?", "returns_IN.md > Return pickup"),
    ("How many days to return an item in India?", "returns_IN.md > Return window"),
    ("My item arrived broken, what now?", "returns_IN.md > Damaged items"),
    ("Do I pay for return shipping in the US?", "returns_US.md > Return shipping"),
    ("US return window?", "returns_US.md > Return window"),
    ("gold customer refund percentage for late orders", "refunds.md > Late deliveries"),
    ("refund paid to which payment method", "refunds.md > Refund window"),
    ("express delivery metro cities", "shipping.md > Delivery times"),
    ("order status placed tracking", "shipping.md > Tracking"),
    ("RP-204 late delivery rule", "refunds.md > Late deliveries"),
]


def eval_recall(k=4, filters=None, query_type=None, index=idx):
    hits = 0
    for q, expected in LABELLED:
        kw = {"query_type": query_type} if query_type else {}
        res = index.similarity_search(query_text=q, columns=COLS, num_results=k, filters=filters, **kw)
        got = {f"{r[1]} > {r[2]}" for r in res["result"]["data_array"]}
        hits += expected in got
    return hits / len(LABELLED)


current = {"superseded": False}
print(f"recall@4 baseline            : {eval_recall(4):.0%}")
print(f"recall@4 current-only filter : {eval_recall(4, current):.0%}")
print(f"recall@4 filter + HYBRID     : {eval_recall(4, current, 'HYBRID'):.0%}")
print(f"recall@2 filter + HYBRID     : {eval_recall(2, current, 'HYBRID'):.0%}")

# COMMAND ----------

# MAGIC %md ## Same index from SQL (for analysts and evaluation sets)

# COMMAND ----------

for arg in ("query_text", "query"):          # the argument name differs between runtime versions
    try:
        display(spark.sql(f"SELECT source, section FROM vector_search(index => '{ACTIVE_INDEX}', "
                          f"{arg} => 'late delivery refund', num_results => 3)"))
        break
    except Exception as e:
        print(f"vector_search with {arg} => failed: {str(e)[:120]}")

# COMMAND ----------

set_setting("active_index", ACTIVE_INDEX)
print(f"Checkpoint B: index {ACTIVE_INDEX} ready; recall measured. Saved as your active index for later labs.")
