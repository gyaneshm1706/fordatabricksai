# Databricks notebook source
# MAGIC %md
# MAGIC # Module 3 demo · AI Functions: LLMs inside SQL
# MAGIC Remember the Module 1 decision guide: nightly ticket classification is a **workflow step**, not an agent.

# COMMAND ----------

# MAGIC %run ./_config

# COMMAND ----------

# MAGIC %md ## Task functions: no prompt engineering

# COMMAND ----------

display(spark.sql(f"""
SELECT ticket_id, body,
       ai_classify(body, ARRAY('refund', 'delivery', 'address_change', 'other')) AS intent,
       true_intent
FROM {FQ}.tickets LIMIT 20"""))

# COMMAND ----------

# Accuracy of the zero-shot classifier against the labels we generated
display(spark.sql(f"""
SELECT round(avg(CASE WHEN ai_classify(body, ARRAY('refund','delivery','address_change','other')) = true_intent
                      THEN 1 ELSE 0 END), 2) AS accuracy, count(*) AS n
FROM {FQ}.tickets"""))

# COMMAND ----------

# MAGIC %md ## `ai_query`: any prompt, any serving endpoint, row by row (batch inference)

# COMMAND ----------

display(spark.sql(f"""
SELECT ticket_id,
       ai_query('{LLM_ENDPOINT}',
                CONCAT('Summarise in one sentence for an agent handover: ', body)) AS summary
FROM {FQ}.tickets
WHERE created_at >= current_date() - INTERVAL 3 DAYS
LIMIT 10"""))

# COMMAND ----------

# MAGIC %md ## Structured output with `ai_query` + `responseFormat`

# COMMAND ----------

display(spark.sql(f"""
SELECT ticket_id,
       ai_query('{LLM_ENDPOINT}',
                CONCAT('Extract the order id and the customer request from: ', body),
                responseFormat => 'STRUCT<result: STRUCT<order_id: STRING, request: STRING>>') AS extracted
FROM {FQ}.tickets LIMIT 5"""))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pattern for solutions
# MAGIC Enrich data in scheduled pipelines with AI Functions (classify, summarise, extract);
# MAGIC reserve agents for the interactive, multi-step parts.
