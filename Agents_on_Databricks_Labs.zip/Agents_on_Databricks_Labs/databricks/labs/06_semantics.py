# Databricks notebook source
# MAGIC %md
# MAGIC # Lab 4 · Part B: semantics that make Genie right (15 min) — also Demo 8
# MAGIC **Goal:** comments, keys and a metric view, so Genie stops guessing what "revenue" and "late" mean.
# MAGIC Run Part A in `05_genie_agent` first (create the space and note which answers are wrong).

# COMMAND ----------

# MAGIC %run ./_config

# COMMAND ----------

# MAGIC %md ## 1. Table and column comments, in business language

# COMMAND ----------

# Describe the tables, units and allowed values that Genie keeps getting wrong
spark.sql(f"COMMENT ON TABLE {FQ}.orders IS 'One row per customer order. amount is the order value. Late = eta after promised_date.'")
spark.sql(f"ALTER TABLE {FQ}.orders ALTER COLUMN amount COMMENT 'Order value in INR incl. tax, excl. shipping'")
spark.sql(f"ALTER TABLE {FQ}.orders ALTER COLUMN status COMMENT 'placed | shipped | delivered | cancelled. Revenue excludes cancelled.'")
spark.sql(f"ALTER TABLE {FQ}.orders ALTER COLUMN region COMMENT 'Sales region: North, South, East or West'")
spark.sql(f"ALTER TABLE {FQ}.orders ALTER COLUMN promised_date COMMENT 'Delivery date promised at checkout'")
spark.sql(f"ALTER TABLE {FQ}.orders ALTER COLUMN eta COMMENT 'Actual or expected delivery date'")
spark.sql(f"COMMENT ON TABLE {FQ}.customers IS 'One row per customer. tier: gold | silver | standard.'")
spark.sql(f"COMMENT ON TABLE {FQ}.order_lines IS 'Products in each order. Line value = quantity * unit_price (INR).'")
spark.sql(f"COMMENT ON TABLE {FQ}.products IS 'Product catalogue with category and list price in INR.'")

# COMMAND ----------

# MAGIC %md ## 2. Keys: tell Genie how tables join (informational constraints)

# COMMAND ----------

def add_pk(table, col, name):
    spark.sql(f"ALTER TABLE {FQ}.{table} ALTER COLUMN {col} SET NOT NULL")
    try:
        spark.sql(f"ALTER TABLE {FQ}.{table} ADD CONSTRAINT {name} PRIMARY KEY ({col})")
    except Exception as e:
        print(f"{name}: {str(e)[:80]}")


def add_fk(table, col, ref_table, name):
    try:
        spark.sql(f"ALTER TABLE {FQ}.{table} ADD CONSTRAINT {name} FOREIGN KEY ({col}) REFERENCES {FQ}.{ref_table}")
    except Exception as e:
        print(f"{name}: {str(e)[:80]}")


# Primary keys on customers, products, orders; foreign keys orders->customers, order_lines->orders/products
add_pk("customers", "customer_id", "customers_pk")
add_pk("products", "product_id", "products_pk")
add_pk("orders", "order_id", "orders_pk")
add_fk("orders", "customer_id", "customers", "orders_customer_fk")
add_fk("order_lines", "order_id", "orders", "lines_order_fk")
add_fk("order_lines", "product_id", "products", "lines_product_fk")
print("keys added")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. A metric view: define each metric once
# MAGIC If `version: 0.1` is rejected in your workspace, use the version shown in the current metric view docs.

# COMMAND ----------

# Metric view with a cancelled-order filter, time and region dimensions, and revenue/orders/AOV/late measures
spark.sql(f"""
CREATE OR REPLACE VIEW {FQ}.order_metrics
WITH METRICS LANGUAGE YAML
COMMENT 'Governed order metrics. Revenue excludes cancelled orders. Fiscal year starts 1 April.'
AS $$
version: 0.1
source: {FQ}.orders
filter: status <> 'cancelled'
dimensions:
  - name: Order Date
    expr: order_date
  - name: Order Month
    expr: DATE_TRUNC('MONTH', order_date)
  - name: Fiscal Quarter
    expr: CONCAT('FY', YEAR(ADD_MONTHS(order_date, -3)), '-Q', QUARTER(ADD_MONTHS(order_date, -3)))
  - name: Region
    expr: region
  - name: Status
    expr: status
measures:
  - name: Revenue
    expr: SUM(amount)
  - name: Orders
    expr: COUNT(DISTINCT order_id)
  - name: Average Order Value
    expr: SUM(amount) / COUNT(DISTINCT order_id)
  - name: Late Orders
    expr: COUNT(DISTINCT order_id) FILTER (WHERE eta > promised_date)
  - name: Late Rate
    expr: COUNT(DISTINCT order_id) FILTER (WHERE eta > promised_date) / COUNT(DISTINCT order_id)
$$""")

# COMMAND ----------

display(spark.sql(f"""
SELECT `Region`, MEASURE(`Revenue`) AS revenue, MEASURE(`Late Rate`) AS late_rate
FROM {FQ}.order_metrics
WHERE `Order Date` >= current_date() - INTERVAL 90 DAYS
GROUP BY ALL ORDER BY late_rate DESC"""))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Back in the Genie space
# MAGIC 1. **Data:** add `order_metrics` to the space.
# MAGIC 2. **Instructions:** add the three lines from `lab_assets/genie_instructions.md` (fiscal year, currency, when to clarify).
# MAGIC 3. Ask the same 5 questions as in Part A and compare the SQL. Then go to Part C (benchmarks) in `05_genie_agent`.
