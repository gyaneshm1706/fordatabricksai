# Databricks notebook source
# MAGIC %md
# MAGIC # Lab 5 · Part B: MCP integration (12 min) — also Demo 11
# MAGIC **Goal:** discover and call tools through Databricks **managed MCP servers** (UC functions, Vector Search,
# MAGIC Genie), see that discovery follows Unity Catalog grants, and add MCP tools to an agent.
# MAGIC Managed MCP URL formats may change; if a URL returns 404, check the current docs or ask the instructor.

# COMMAND ----------

# MAGIC %pip install -U -qqq databricks-mcp databricks-sdk databricks-langchain langgraph "mlflow[databricks]>=3.1"

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./_config

# COMMAND ----------

from databricks.sdk import WorkspaceClient
from databricks_mcp import DatabricksMCPClient

w = WorkspaceClient()
host = w.config.host.rstrip("/")
SERVERS = {
    "functions": f"{host}/api/2.0/mcp/functions/{CATALOG}/{SCHEMA}",
    "search": f"{host}/api/2.0/mcp/vector-search/{CATALOG}/{SCHEMA}",
}
if GENIE_SPACE_ID:
    SERVERS["genie"] = f"{host}/api/2.0/mcp/genie/{GENIE_SPACE_ID}"


def discover(client_ws: WorkspaceClient, label: str) -> dict:
    found = {}
    for name, url in SERVERS.items():
        try:
            tools = DatabricksMCPClient(server_url=url, workspace_client=client_ws).list_tools()
            found[name] = [t.name for t in tools]
        except Exception as e:
            found[name] = [f"ERROR {type(e).__name__}: {str(e)[:80]}"]
    print(f"--- {label}")
    for k, v in found.items():
        print(f"{k:10} {v}")
    return found


mine = discover(w, "as you (owner)")

# COMMAND ----------

# MAGIC %md ## Call a tool directly

# COMMAND ----------

# Call your get_order_status function through the functions MCP server
fn = DatabricksMCPClient(server_url=SERVERS["functions"], workspace_client=w)
tool_name = next(t for t in mine["functions"] if t.endswith("get_order_status"))
res = fn.call_tool(tool_name, {"order_id": "ORD-10293"})
print(tool_name, "->", " ".join(getattr(c, "text", "") for c in res.content))

# COMMAND ----------

# MAGIC %md ## Discovery is dynamic: add a function, it appears without code changes

# COMMAND ----------

spark.sql(f"""CREATE OR REPLACE FUNCTION {FQ}.store_hours() RETURNS STRING
COMMENT 'Customer support opening hours.' RETURN 'Mon-Sat 09:00-18:00 IST'""")
discover(w, "after adding store_hours")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Discovery follows grants: the test analyst
# MAGIC Uses the analyst token in secret scope `course` (key `analyst_pat`). Never paste tokens into notebooks.

# COMMAND ----------

try:
    analyst = WorkspaceClient(host=host, token=dbutils.secrets.get("course", "analyst_pat"))
    discover(analyst, "as test analyst")
except Exception as e:
    print(f"analyst identity unavailable ({e}); see demo_outputs in the lab guide")

# COMMAND ----------

# MAGIC %md ## Add MCP tools to an agent

# COMMAND ----------

import mlflow
from databricks_langchain import ChatDatabricks
from langchain_core.tools import StructuredTool
from langgraph.prebuilt import create_react_agent


def mcp_tools(url: str, ws: WorkspaceClient) -> list:
    client = DatabricksMCPClient(server_url=url, workspace_client=ws)
    out = []
    for t in client.list_tools():
        def _call(_name=t.name, **kwargs):
            r = client.call_tool(_name, kwargs)
            return "\n".join(getattr(c, "text", "") for c in r.content)
        out.append(StructuredTool.from_function(func=_call, name=t.name[-64:], description=t.description or t.name,
                                                args_schema=t.inputSchema))
    return out


mlflow.set_experiment(EXPERIMENT)
mlflow.langchain.autolog()
tools = mcp_tools(SERVERS["functions"], w)
agent = create_react_agent(ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0), tools=tools,
                           prompt="Use the tools to answer order questions. Never invent data.")
print(agent.invoke({"messages": [("user", "Is ORD-10377 late, and what refund applies?")]})["messages"][-1].content)

# COMMAND ----------

# MAGIC %md
# MAGIC **When deploying an agent that uses MCP**, declare the servers' underlying resources at log time
# MAGIC (recent `databricks-mcp` versions offer `DatabricksMCPClient(...).get_databricks_resources()`), so automatic
# MAGIC authentication passthrough can grant the endpoint access.
