# Databricks notebook source
# MAGIC %md
# MAGIC # Lab 6 · Parts C–D: log, validate, register, deploy and check (22 min) — also Demo 15
# MAGIC **Start the deployment by 1:30.** Provisioning takes 10–20 minutes; run Part D against the instructor's
# MAGIC checkpoint endpoint while yours is being created.

# COMMAND ----------

# MAGIC %pip install -U -qqq "mlflow[databricks]>=3.1" databricks-agents databricks-langchain "unitycatalog-ai[databricks]" databricks-sdk databricks-vectorsearch databricks-ai-bridge langgraph uv

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./_config

# COMMAND ----------

import os
from importlib.metadata import version

import mlflow
import yaml
from mlflow.models.resources import (DatabricksFunction, DatabricksServingEndpoint, DatabricksSQLWarehouse,
                                     DatabricksTable, DatabricksVectorSearchIndex)

mlflow.set_registry_uri("databricks-uc")
mlflow.set_experiment(EXPERIMENT)

# Deployment config: no in-process actions (approval across replicas needs a persistent checkpointer)
config = yaml.safe_load(open(os.path.join(AGENT_DIR, "agent_config.yaml")))
config.update({"enable_actions": False, "use_obo": False})
yaml.safe_dump(config, open(os.path.join(AGENT_DIR, "agent_config.yaml"), "w"))
EXAMPLE = {"input": [{"role": "user", "content": "Where is ORD-10293?"}]}
PINNED = [f"{p}=={version(p)}" for p in ("mlflow", "databricks-langchain", "langgraph", "databricks-sdk",
                                          "unitycatalog-ai", "databricks-vectorsearch", "databricks-ai-bridge")]
print(PINNED)

# COMMAND ----------

# MAGIC %md ## 1. Log the agent from code, with the resources it needs (automatic auth passthrough)

# COMMAND ----------

# Declare every endpoint, index, function, table and warehouse the agent touches
resources = [
    DatabricksServingEndpoint(endpoint_name=config["llm_endpoint"]),
    DatabricksServingEndpoint(endpoint_name=EMBEDDING_ENDPOINT),
    DatabricksVectorSearchIndex(index_name=config["vs_index"]),
    *[DatabricksFunction(function_name=f) for f in config["uc_functions"]],
    DatabricksTable(table_name=f"{FQ}.orders"),
    DatabricksTable(table_name=f"{FQ}.customers"),
]
if WAREHOUSE_ID:
    resources.append(DatabricksSQLWarehouse(warehouse_id=WAREHOUSE_ID))
if config.get("genie_space_id"):
    from mlflow.models.resources import DatabricksGenieSpace
    resources.append(DatabricksGenieSpace(genie_space_id=config["genie_space_id"]))

with mlflow.start_run(run_name="deploy-v0.3.1"):
    mlflow.set_tag("agent_version", "0.3.1")
    info = mlflow.pyfunc.log_model(
        name="agent",
        python_model=os.path.join(AGENT_DIR, "support_agent.py"),
        code_paths=[os.path.join(AGENT_DIR, "genie_tool.py")],
        model_config=os.path.join(AGENT_DIR, "agent_config.yaml"),
        resources=resources,
        input_example=EXAMPLE,
        pip_requirements=PINNED,
    )
print(info.model_uri)

# COMMAND ----------

# MAGIC %md ## 2. Validate in a clean environment before deploying (catches missing packages in ~1 minute)

# COMMAND ----------

mlflow.models.predict(model_uri=info.model_uri, input_data=EXAMPLE, env_manager="uv")

# COMMAND ----------

# MAGIC %md ## 3. Register in Unity Catalog and deploy

# COMMAND ----------

from databricks import agents

mv = mlflow.register_model(info.model_uri, UC_MODEL)
deployment = agents.deploy(UC_MODEL, mv.version, scale_to_zero=True, tags={"agent_version": "0.3.1"})
ENDPOINT = getattr(deployment, "endpoint_name", None)
set_setting("endpoint_name", ENDPOINT or "")
set_setting("model_version", str(mv.version))
print(deployment)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Part D: endpoint checks
# MAGIC While your endpoint is still provisioning, this uses the instructor's checkpoint endpoint automatically
# MAGIC (`shared_checkpoint_endpoint` in `course.shared.course_settings`). Re-run the cell later to test your own.

# COMMAND ----------

import time

from databricks.sdk import WorkspaceClient

w = WorkspaceClient()
ENDPOINT = ENDPOINT if "ENDPOINT" in globals() and ENDPOINT else get_setting("endpoint_name")


def is_ready(name: str) -> bool:
    try:
        ready = w.serving_endpoints.get(name).state.ready
        return str(getattr(ready, "value", ready)).upper() == "READY"
    except Exception:
        return False


CHECK_ENDPOINT = ENDPOINT if ENDPOINT and is_ready(ENDPOINT) else get_setting("shared_checkpoint_endpoint", ENDPOINT)
state = w.serving_endpoints.get(CHECK_ENDPOINT).state
print(f"checking {CHECK_ENDPOINT} ({'your endpoint' if CHECK_ENDPOINT == ENDPOINT else 'instructor checkpoint'}): "
      f"ready={state.ready} config_update={state.config_update}")
oai = w.serving_endpoints.get_open_ai_client()


def ask(q: str) -> str:
    return oai.responses.create(model=CHECK_ENDPOINT, input=[{"role": "user", "content": q}]).output_text


ask("hello")                    # warm-up: scale-to-zero cold start is not part of the latency budget

# COMMAND ----------

SMOKE = [("Where is ORD-10293?", "ORD-10293"), ("What is the refund window?", "30"), ("What is the CEO's salary?", "")]
for q, must in SMOKE:
    t0 = time.time()
    out = ask(q)
    ms = (time.time() - t0) * 1000
    assert must.lower() in out.lower(), (q, out)
    assert ms < 15_000, f"slow: {ms:.0f} ms"
    print(f"PASS {ms:6.0f} ms  {q}")

# COMMAND ----------

# Streaming check (stretch): time to first event
t0 = time.time()
for ev in oai.responses.create(model=CHECK_ENDPOINT, stream=True,
                               input=[{"role": "user", "content": "Refund rules for late orders?"}]):
    print(f"first event after {(time.time() - t0) * 1000:.0f} ms: {ev.type}")
    break

# COMMAND ----------

# MAGIC %md ## Promote with an alias; open the Review App

# COMMAND ----------

from mlflow import MlflowClient

MlflowClient().set_registered_model_alias(UC_MODEL, "champion", mv.version)
print(f"champion -> version {mv.version}")
print("Review App:", getattr(deployment, "review_app_url", "see the deployment output above"))
