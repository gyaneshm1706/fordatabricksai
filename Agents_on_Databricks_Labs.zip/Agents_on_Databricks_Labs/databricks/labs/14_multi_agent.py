# Databricks notebook source
# MAGIC %md
# MAGIC # Lab 7: multi-agent supervisor and Agent Bricks (36 min) — also Demo 17
# MAGIC **Goal:** a supervisor that routes multi-domain questions across three specialists you already built
# MAGIC (Genie analyst, policy RAG, order operations), one trace per request, a routing evaluation, and an
# MAGIC Agent Bricks Knowledge Assistant compared with your hand-built `policy_expert`.

# COMMAND ----------

# MAGIC %pip install -U -qqq "mlflow[databricks]>=3.1" databricks-langchain "unitycatalog-ai[databricks]" databricks-sdk databricks-vectorsearch langgraph langgraph-supervisor

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./_config

# COMMAND ----------

import os
import sys

import mlflow
from databricks_langchain import ChatDatabricks, UCFunctionToolkit, VectorSearchRetrieverTool
from langgraph.prebuilt import create_react_agent

sys.path.insert(0, AGENT_DIR)
from genie_tool import GENIE_DESCRIPTION, make_genie_tool

mlflow.set_experiment(EXPERIMENT)
mlflow.langchain.autolog()
LLM = ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0)                 # supervisor: strongest model
LLM_SMALL = ChatDatabricks(endpoint=LLM_SMALL_ENDPOINT, temperature=0)     # workers: narrow jobs
assert GENIE_SPACE_ID, "set your Genie space id in Lab 4 (05_genie_agent)"

# COMMAND ----------

# MAGIC %md ## Part A: workers, each tested alone

# COMMAND ----------

# Three named workers with small toolsets and focused instructions
policy_expert = create_react_agent(
    LLM_SMALL, name="policy_expert",
    tools=[VectorSearchRetrieverTool(index_name=get_setting("active_index", SHARED_INDEX), tool_name="search_policies",
                                     tool_description="Search current support policies.", num_results=3,
                                     columns=["chunk_id", "source", "section", "chunk_text"],
                                     filters={"superseded": False})],
    prompt="Answer policy questions only, with [source > section] citations. Say so if no policy applies.")

order_ops = create_react_agent(
    LLM_SMALL, name="order_ops",
    tools=UCFunctionToolkit(function_names=[f"{FQ}.get_order_status", f"{FQ}.refund_eligibility"]).tools,
    prompt="Look up specific orders and compute refund eligibility. Never change data. Report facts only.")

sales_analyst = create_react_agent(
    LLM_SMALL, name="sales_analyst",
    tools=[make_genie_tool(GENIE_SPACE_ID, GENIE_DESCRIPTION)],
    prompt="Answer questions about counts, totals and trends across many orders using the Genie tool.")

for worker, q in [(policy_expert, "What is the refund window?"),
                  (order_ops, "Is ORD-10377 late?"),
                  (sales_analyst, "How many orders were late last week in the North region?")]:
    print(f"[{worker.name}] {worker.invoke({'messages': [('user', q)]})['messages'][-1].content[:300]}\n")

# COMMAND ----------

# MAGIC %md ## Part B: the supervisor

# COMMAND ----------

from langgraph_supervisor import create_supervisor

# Routing policy only; pass back last messages, not full worker histories
supervisor = create_supervisor(
    agents=[sales_analyst, policy_expert, order_ops],
    model=LLM,
    prompt=("You coordinate three experts. Split the user's request into parts and delegate each part: "
            "sales_analyst for counts, totals and trends across many orders; policy_expert for company rules; "
            "order_ops for one specific order or a refund calculation. Never answer from your own knowledge. "
            "Combine the experts' answers into one reply and keep every citation."),
    output_mode="last_message",
).compile()

QUESTIONS = [
    "How many North-region orders were late last week, what do we owe those customers, and what's the status of ORD-10377?",
    "Which region has the highest late rate this quarter, and what is our late-delivery policy?",
    "Is ORD-10688 late and what refund applies?",
    "What's the refund window, and how many refunds-eligible late orders did we have last month?",
    "Who approves address changes?",
]
for q in QUESTIONS:
    out = supervisor.invoke({"messages": [("user", q)]}, {"recursion_limit": 30})
    called = [m.name for m in out["messages"] if getattr(m, "name", None) in ("sales_analyst", "policy_expert", "order_ops")]
    print(f"Q: {q}\nworkers: {sorted(set(called))}\nA: {out['messages'][-1].content[:500]}\n")

# COMMAND ----------

# MAGIC %md ## Part C: evaluate routing (10 cases)

# COMMAND ----------

from mlflow.genai.scorers import Correctness, scorer

ROUTING = [
    ("How many orders were late last week in the North?", ["sales_analyst"]),
    ("What is the refund window?", ["policy_expert"]),
    ("Where is ORD-10293?", ["order_ops"]),
    ("Is ORD-10377 late and what refund applies?", ["order_ops"]),
    ("Revenue by region this quarter and our late-delivery policy", ["sales_analyst", "policy_expert"]),
    ("Status of ORD-10688 and the return window in India", ["order_ops", "policy_expert"]),
    ("Which region has the most late orders, and what do we owe a silver customer 5 days late?", ["sales_analyst", "policy_expert"]),
    ("Who approves address changes?", ["policy_expert"]),
    ("Top 5 products by units last 90 days", ["sales_analyst"]),
    ("Late rate in the West last month and the status of ORD-10102", ["sales_analyst", "order_ops"]),
]


@scorer
def routed_correctly(outputs, expectations) -> bool:
    return set(expectations["workers"]) <= set(outputs["workers"])


def run_supervisor(question: str) -> dict:
    out = supervisor.invoke({"messages": [("user", question)]}, {"recursion_limit": 30})
    workers = sorted({m.name for m in out["messages"] if getattr(m, "name", None) in ("sales_analyst", "policy_expert", "order_ops")})
    return {"answer": out["messages"][-1].content, "workers": workers}


with mlflow.start_run(run_name="supervisor-routing"):
    res = mlflow.genai.evaluate(
        data=[{"inputs": {"question": q}, "expectations": {"workers": w}} for q, w in ROUTING],
        predict_fn=run_supervisor, scorers=[routed_correctly])
print(res.metrics)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Part D: Agent Bricks Knowledge Assistant
# MAGIC 1. **Agents → Agent Bricks → Knowledge Assistant** (or open the instructor's pre-built *Support Policies* assistant;
# MAGIC    builds take time, so don't wait for a new one).
# MAGIC 2. Source: your `raw_policies` volume (or the shared index). Description: *"Answers customer-support policy questions with citations."*
# MAGIC 3. Paste its **endpoint name** below and compare with your `policy_expert` on the same three questions:
# MAGIC    quality, latency, and how much effort each took to build.

# COMMAND ----------

import time

from databricks.sdk import WorkspaceClient

dbutils.widgets.text("ka_endpoint", get_setting("shared_ka_endpoint"), "Knowledge Assistant endpoint")
KA = dbutils.widgets.get("ka_endpoint").strip()
oai = WorkspaceClient().serving_endpoints.get_open_ai_client()
for q in ["Can I get a refund on a late order?", "Is return pickup free in India?", "Who approves address changes?"]:
    t0 = time.time()
    mine = policy_expert.invoke({"messages": [("user", q)]})["messages"][-1].content
    t_mine = time.time() - t0
    line = f"Q: {q}\n  policy_expert ({t_mine:.1f}s): {mine[:250]}"
    if KA:
        t0 = time.time()
        theirs = oai.responses.create(model=KA, input=[{"role": "user", "content": q}]).output_text
        line += f"\n  knowledge_assistant ({time.time() - t0:.1f}s): {theirs[:250]}"
    print(line + "\n")

# COMMAND ----------

# MAGIC %md
# MAGIC **Stretch:** add the Knowledge Assistant as a fourth worker (wrap its endpoint in a tool with a distinct
# MAGIC description) and re-run the routing evaluation. Or build the same system with an **Agent Bricks Multi-Agent
# MAGIC Supervisor** in the UI, pointing at your Genie space and the Knowledge Assistant, and compare.
