# Databricks notebook source
# MAGIC %md
# MAGIC # 99 · Cleanup (after the capstone is graded)
# MAGIC Deletes **your** endpoint, index and schema. Irreversible: set `CONFIRM = True` to run.

# COMMAND ----------

# MAGIC %pip install -U -qqq databricks-sdk databricks-vectorsearch

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./_config

# COMMAND ----------

CONFIRM = False
if CONFIRM:
    from databricks.sdk import WorkspaceClient
    from databricks.vector_search.client import VectorSearchClient

    ep = get_setting("endpoint_name")
    if ep:
        WorkspaceClient().serving_endpoints.delete(ep)
        print(f"deleted endpoint {ep}")
    try:
        VectorSearchClient(disable_notice=True).delete_index(VS_ENDPOINT, INDEX)
        print(f"deleted index {INDEX}")
    except Exception as e:
        print(f"index: {e}")
    spark.sql(f"DROP SCHEMA IF EXISTS {FQ} CASCADE")
    print(f"dropped {FQ}")
else:
    print("Set CONFIRM = True to delete your endpoint, index and schema.")
