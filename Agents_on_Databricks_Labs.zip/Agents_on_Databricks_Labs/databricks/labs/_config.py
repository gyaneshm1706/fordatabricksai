# Databricks notebook source
# MAGIC %md
# MAGIC # Course configuration (shared by every lab notebook)
# MAGIC Run with `%run ./_config` at the top of each notebook. **Instructor:** set the names in the first cell once per
# MAGIC workspace; participants never edit this file. Each participant works in their own schema `course.<user>_support`.

# COMMAND ----------

import os
import re

# Folder of the calling notebook (robust to os.chdir in earlier cells)
try:
    _nb_path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
    NOTEBOOK_DIR = "/Workspace" + os.path.dirname(_nb_path)
except Exception:                                   # some compute types restrict the notebook context
    NOTEBOOK_DIR = os.getcwd().replace(os.sep + "agents", "") if os.getcwd().endswith("agents") else os.getcwd()
AGENT_DIR = os.path.join(NOTEBOOK_DIR, "agents")
REPO_ROOT = os.path.dirname(os.path.dirname(NOTEBOOK_DIR))        # course Git folder root

# ---- instructor settings (check names on the Serving and Compute > Vector Search pages) ----
CATALOG = "course"                                          # course catalog (created by 00_instructor_setup)
SHARED_SCHEMA = "shared"                                    # checkpoint assets everyone can read
VS_ENDPOINT = "agents-course-vs"                            # pre-created Vector Search endpoint
LLM_ENDPOINT = "databricks-claude-sonnet-4-5"               # tool-calling chat model endpoint
LLM_SMALL_ENDPOINT = "databricks-meta-llama-3-3-70b-instruct"  # smaller/cheaper model for routing and workers
EMBEDDING_ENDPOINT = "databricks-gte-large-en"
WAREHOUSE_ID = ""                                           # SQL warehouse id for Genie and governed writes
COURSE_GROUP = "agents-course-participants"                 # account group of all participants
ANALYST_GROUP = "agents-course-analysts"                    # 'test analyst' identity for access tests

# ---- derived per-participant names (do not edit) ----
USER = spark.sql("SELECT current_user()").first()[0]
USER_SLUG = re.sub(r"[^a-z0-9]", "_", USER.split("@")[0].lower())
SCHEMA = f"{USER_SLUG}_support"
FQ = f"{CATALOG}.{SCHEMA}"
VOLUME_PATH = f"/Volumes/{CATALOG}/{SCHEMA}/raw_policies"
INDEX = f"{FQ}.policy_chunks_index"
SHARED_INDEX = f"{CATALOG}.{SHARED_SCHEMA}.policy_chunks_index"      # checkpoint if yours is still syncing
UC_MODEL = f"{FQ}.support_agent"
EXPERIMENT = f"/Users/{USER}/agents-course"
EVAL_TABLE = f"{FQ}.agent_eval_v1"
REQUESTS_TABLE = f"{FQ}.address_change_requests"

SHARED_SETTINGS = f"{CATALOG}.{SHARED_SCHEMA}.course_settings"   # set once by the instructor


def get_setting(key: str, default: str = "") -> str:
    """Your own settings saved by earlier labs; falls back to the instructor's shared settings."""
    for table in (f"{FQ}.course_settings", SHARED_SETTINGS):
        try:
            row = spark.sql(f"SELECT value FROM {table} WHERE key = :k", args={"k": key}).first()
            if row and row[0]:
                return row[0]
        except Exception:
            pass
    return default


def set_setting(key: str, value: str) -> None:
    spark.sql(f"CREATE TABLE IF NOT EXISTS {FQ}.course_settings (key STRING, value STRING)")
    spark.sql(f"DELETE FROM {FQ}.course_settings WHERE key = :k", args={"k": key})
    spark.sql(f"INSERT INTO {FQ}.course_settings VALUES (:k, :v)", args={"k": key, "v": value})


GENIE_SPACE_ID = get_setting("genie_space_id") or get_setting("shared_genie_space_id")

try:
    spark.sql(f"USE CATALOG {CATALOG}")
except Exception as e:
    print(f"WARNING: catalog {CATALOG} not available yet: {e}")
print(f"user={USER}\nschema={FQ}\nindex={INDEX}\nllm={LLM_ENDPOINT}\nexperiment={EXPERIMENT}")
