# Local checks for the Databricks notebooks (no workspace needed)

These catch bugs before a workspace dry run. They do **not** replace one: Vector Search, Model Serving, Genie,
Unity Catalog functions, MLflow judges and AI Functions only run on Databricks.

| Script | What it checks |
|---|---|
| `static_check.py` | Every notebook in `databricks/labs`, analysed together with `_config` (which it `%run`s): undefined names, syntax errors, misused imports |
| `spark_dryrun.py` | Runs the Databricks-independent cells on local PySpark: data generation (`00_setup`), policy copy, section split, chunking and stable ids (`01_prepare_data`), and the Genie benchmark SQL (`05_genie_agent`) against the generated data |

Requirements: Python 3.12 (PySpark does not support 3.14 yet), Java 17 or 21.

```bash
pip install "pyspark>=4.0,<4.1" pandas pyarrow langchain-text-splitters pyflakes
python static_check.py ../labs
python spark_dryrun.py ../labs
```

On Windows, if Spark fails to start: set `JAVA_HOME` to an installed JDK 17/21 and `SPARK_HOME` to the installed
`pyspark` package folder for that shell (an older system Spark in `SPARK_HOME` causes `'JavaPackage' object is not callable`).

Latest results: `outputs/databricks_static_check.txt` and `outputs/databricks_local_dryrun.txt`.
