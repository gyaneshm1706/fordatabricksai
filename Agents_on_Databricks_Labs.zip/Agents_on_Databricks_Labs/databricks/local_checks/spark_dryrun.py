"""Local PySpark dry run of the Databricks-independent cells of 00_setup, 01_prepare_data and 05_genie_agent.

Databricks-only statements (volumes, read_files, CDF properties, UC) are emulated or skipped and reported.
Tables are kept as global temp views (no Hadoop/winutils needed on Windows).
"""
import os
import pathlib
import re
import shutil
import sys
import tempfile

os.environ["PYSPARK_PYTHON"] = sys.executable
os.environ["PYSPARK_DRIVER_PYTHON"] = sys.executable

from pyspark.sql import DataFrameWriter, SparkSession  # noqa: E402

labs = pathlib.Path(sys.argv[1])
repo = labs.parents[1]
spark = (SparkSession.builder.master("local[2]").appName("labs-dryrun")
         .config("spark.sql.shuffle.partitions", "4").config("spark.ui.enabled", "false").getOrCreate())
spark.sparkContext.setLogLevel("ERROR")


def _save(self, name, *a, **k):
    self._df.createOrReplaceGlobalTempView(name.split(".")[-1])


DataFrameWriter.saveAsTable = _save
DataFrameWriter.mode = lambda self, m: self
DataFrameWriter.option = lambda self, *a, **k: self

vol = pathlib.Path(tempfile.mkdtemp()) / "raw_policies"
vol.mkdir()


class _FS:
    def ls(self, p):
        return [f.name for f in pathlib.Path(p).iterdir()]


class _DBUtils:
    fs = _FS()


def display(obj):
    if hasattr(obj, "toPandas"):
        print(obj.limit(20).toPandas().to_string(max_colwidth=60))
    else:
        print(obj)


ns = {"spark": spark, "dbutils": _DBUtils(), "display": display, "CATALOG": "global_temp", "SCHEMA": "global_temp",
      "FQ": "global_temp", "VOLUME_PATH": str(vol), "REPO_ROOT": str(repo), "NOTEBOOK_DIR": str(labs)}


def cells(nb):
    return [c for c in (labs / nb).read_text(encoding="utf-8").split("# COMMAND ----------")]


def run(nb, must_contain, transform=lambda s: s, title=None):
    for c in cells(nb):
        if must_contain in c:
            print(f"\n----- {nb}: {title or must_contain}")
            exec(compile(transform(c), f"{nb}", "exec"), ns)
            return
    raise RuntimeError(f"cell with {must_contain!r} not found in {nb}")


checks = []
NO_DELTA = lambda s: re.sub(r"spark\.sql\(f\"ALTER TABLE[^\n]*\n", "", s)   # Delta table properties: Databricks only


def check(name, cond):
    checks.append((name, bool(cond)))
    print(f"{'PASS' if cond else 'FAIL'}  {name}")


# ---------------- 00_setup ----------------
run("00_setup.py", "rnd = random.Random(42)", title="generate course data")
orders = spark.table("global_temp.orders")
check("orders: 3,008 rows (8 named + 3,000 history)", orders.count() == 3008)
check("all 8 named demo orders present",
      orders.filter("order_id IN ('ORD-10293','ORD-10377','ORD-10411','ORD-10102','ORD-10555','ORD-10620','ORD-10688','ORD-10702')").count() == 8)
check("customers: 300 rows", spark.table("global_temp.customers").count() == 300)
check("tickets: 60 rows with true_intent labels", spark.table("global_temp.tickets").count() == 60)
late = {r["region"]: r["late_rate"] for r in spark.sql(
    "SELECT region, avg(CASE WHEN eta > promised_date THEN 1 ELSE 0 END) AS late_rate FROM global_temp.orders "
    "WHERE status <> 'cancelled' GROUP BY region").collect()}
print("late rate by region:", {k: round(v, 3) for k, v in late.items()})
check("North has the highest late rate (pattern for Genie to find)", max(late, key=late.get) == "North")
check("overall late rate realistic (20-40%)", 0.2 <= sum(late.values()) / len(late) <= 0.4)
lines_sum = spark.sql("SELECT count(*) n FROM global_temp.orders o LEFT ANTI JOIN global_temp.order_lines l USING (order_id)").first()["n"]
check("every order has order lines", lines_sum == 0)
run("00_setup.py", "repo_policies", title="copy policy documents into the volume")
check("6 policy files copied", len(list(vol.glob("*.md"))) == 6)

# ---------------- 01_prepare_data ----------------
print("\n----- 01_prepare_data: bronze (read_files emulated with wholetext read)")
raw = spark.createDataFrame([(f.name, f.read_text(encoding="utf-8")) for f in sorted(vol.glob("*.md"))], ["file", "raw"])
raw.createOrReplaceGlobalTempView("policy_raw")
run("01_prepare_data.py", "def split_sections", title="silver: split sections with front matter")
text = spark.table("global_temp.policy_text")
display(text.select("source", "section", "region", "effective_date", "superseded"))
check("silver: 17 sections across 6 files", text.count() == 17)
run("01_prepare_data.py", "def chunk(", transform=NO_DELTA, title="gold: chunk + stable id")
chunks = spark.table("global_temp.policy_chunks")
check("gold: chunk_id unique", chunks.select("chunk_id").distinct().count() == chunks.count())
check("gold: superseded 2024 policy flagged", chunks.filter("superseded").count() == 2)
check("gold: every chunk prefixed with its heading",
      chunks.filter("chunk_text LIKE concat(section, ': %')").count() == chunks.count())
display(spark.sql("SELECT count(*) AS chunks, round(avg(token_count)) AS avg_tokens, max(token_count) AS max_tokens, "
                  "count_if(superseded) AS superseded_chunks FROM global_temp.policy_chunks"))
first_ids = sorted(r.chunk_id for r in chunks.collect())
run("01_prepare_data.py", "def chunk(", transform=NO_DELTA, title="re-run gold: ids must be stable")
check("gold: chunk ids identical on re-run (incremental sync)",
      first_ids == sorted(r.chunk_id for r in spark.table("global_temp.policy_chunks").collect()))
print("(Databricks-only, not run here: read_files, CDF table property, SHOW TBLPROPERTIES)")

# ---------------- 05_genie_agent: benchmark rendering ----------------
tpl = (labs / "lab_assets" / "benchmarks_template.csv").read_text(encoding="utf-8")
rendered = tpl.replace("{FQ}", "course.demo_support")
import csv  # noqa: E402
import io  # noqa: E402

rows = list(csv.DictReader(io.StringIO(rendered)))
check("benchmarks: 20 questions, 3 out of scope", len(rows) == 20 and sum("out of scope" in r["expected_sql"] for r in rows) == 3)
check("benchmarks: no unrendered {FQ}", "{FQ}" not in rendered)
# run each in-scope benchmark SQL against the local tables (metric-view ones need Databricks)
ok = skipped = 0
for r in rows:
    sql = r["expected_sql"]
    if "out of scope" in sql:
        continue
    if "order_metrics" in sql or "MEASURE(" in sql:
        skipped += 1
        continue
    spark.sql(sql.replace("course.demo_support", "global_temp")).collect()
    ok += 1
check(f"benchmarks: {ok} plain-SQL expected queries execute on the generated data", ok == 12)
print(f"({skipped} metric-view benchmarks need Databricks metric views)")

print(f"\nSUMMARY: {sum(c for _, c in checks)}/{len(checks)} checks passed")
spark.stop()
sys.exit(0 if all(c for _, c in checks) else 1)
