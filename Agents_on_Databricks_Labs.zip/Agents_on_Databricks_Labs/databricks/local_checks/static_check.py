"""Static check of Databricks notebooks: undefined names, unused imports, redefinitions.

Each notebook is analysed together with _config (which it %run's) and the Databricks globals.
"""
import pathlib
import sys

from pyflakes.api import check
from pyflakes.reporter import Reporter

labs = pathlib.Path(sys.argv[1])
PRELUDE = "spark = dbutils = display = displayHTML = None\n"
config = (labs / "_config.py").read_text(encoding="utf-8")


class Collect(Reporter):
    def __init__(self):
        self.msgs = []

    def flake(self, m):
        self.msgs.append(m)

    def syntaxError(self, filename, msg, lineno, offset, text):
        self.msgs.append(f"SYNTAX {lineno}: {msg}")

    def unexpectedError(self, filename, msg):
        self.msgs.append(f"ERROR {msg}")


IGNORE = ("imported but unused", "redefinition of unused", "f-string is missing placeholders")
total = 0
for nb in sorted(labs.rglob("*.py")):
    src = nb.read_text(encoding="utf-8")
    uses_config = "%run ./_config" in src
    head, body = "", src
    if "from __future__" in src:                      # stubs must come after __future__ imports
        i = src.index("\n", src.index("from __future__")) + 1
        head, body = src[:i], src[i:]
    full = head + PRELUDE + (config if uses_config and nb.name != "_config.py" else "") + "\n" + body
    offset = full.count("\n") - src.count("\n")  # lines added before the notebook
    r = Collect()
    check(full, str(nb), r)
    issues = []
    for m in r.msgs:
        text = str(m) if isinstance(m, str) else m.message % m.message_args
        line = getattr(m, "lineno", 0) - offset
        if any(i in text for i in IGNORE):
            continue
        issues.append(f"  line {line}: {text}")
    total += len(issues)
    print(f"{'OK  ' if not issues else 'WARN'} {nb.relative_to(labs)}")
    for i in issues:
        print(i)
print(f"\n{total} issues")
