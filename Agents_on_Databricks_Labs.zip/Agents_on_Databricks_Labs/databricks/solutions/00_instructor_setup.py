# Databricks notebook source
# MAGIC %md
# MAGIC # 00 · Instructor setup (once per workspace, 1–2 days before Module 3)
# MAGIC Run as a user with **CREATE CATALOG** on the metastore and permission to create Vector Search endpoints.
# MAGIC Follow the phases in order. See the *Lab Handbook*, chapter 2, for the UI and CLI steps around this notebook.
# MAGIC
# MAGIC | Phase | What | Time |
# MAGIC |---|---|---|
# MAGIC | 1 | Catalog, shared schema, shared settings table, grants | 1 min |
# MAGIC | 2 | Vector Search endpoint | 5–15 min |
# MAGIC | — | **Run `00_setup`, then `01_prepare_data`, as yourself** (creates your own schema and chunks) | 5 min |
# MAGIC | 3 | Checkpoint copies + checkpoint index in `course.shared` | 5–10 min |
# MAGIC | 4 | Shared settings (Genie space, checkpoint endpoint, Knowledge Assistant) after you create them | 1 min |
# MAGIC | 5 | Automated readiness check | 1 min |

# COMMAND ----------

# MAGIC %pip install -U -qqq databricks-vectorsearch databricks-sdk

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./_config

# COMMAND ----------

# MAGIC %md ## Phase 1: catalog, shared schema, shared settings, grants

# COMMAND ----------

spark.sql(f"CREATE CATALOG IF NOT EXISTS {CATALOG}")
# If this fails with "no storage root": CREATE CATALOG course MANAGED LOCATION 'abfss://.../course' (or s3://, gs://)
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{SHARED_SCHEMA}")
spark.sql(f"CREATE TABLE IF NOT EXISTS {SHARED_SETTINGS} (key STRING, value STRING) "
          "COMMENT 'Course-wide settings read by every participant through _config.get_setting'")
for grp in (COURSE_GROUP, ANALYST_GROUP):
    spark.sql(f"GRANT USE CATALOG, CREATE SCHEMA ON CATALOG {CATALOG} TO `{grp}`")
    spark.sql(f"GRANT USE SCHEMA, SELECT, EXECUTE ON SCHEMA {CATALOG}.{SHARED_SCHEMA} TO `{grp}`")
print("Phase 1 done: catalog, shared schema, shared settings table and grants ready")

# COMMAND ----------

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.sql import WarehouseAccessControlRequest, WarehousePermissionLevel
from databricks.sdk.service.workspace import AclPermission

w = WorkspaceClient()
# Participants can use the course SQL warehouse (Genie, governed writes, access tests)
if WAREHOUSE_ID:
    w.warehouses.update_permissions(WAREHOUSE_ID, access_control_list=[
        WarehouseAccessControlRequest(group_name=g, permission_level=WarehousePermissionLevel.CAN_USE)
        for g in (COURSE_GROUP, ANALYST_GROUP)])
    print(f"CAN USE on warehouse {WAREHOUSE_ID} granted")
else:
    print("WAREHOUSE_ID is empty in _config: set it, then re-run this cell")
# Participants can read the analyst token secret (the value itself is added with the CLI, see the handbook)
try:
    w.secrets.create_scope("course")
    print("secret scope 'course' created")
except Exception as e:
    print(f"secret scope 'course': {str(e)[:80]}")
w.secrets.put_acl("course", COURSE_GROUP, AclPermission.READ)
print(f"READ on secret scope 'course' granted to {COURSE_GROUP}")

# COMMAND ----------

# MAGIC %md ## Phase 2: Vector Search endpoint (5–15 minutes)

# COMMAND ----------

from databricks.vector_search.client import VectorSearchClient

vsc = VectorSearchClient(disable_notice=True)
existing = [e["name"] for e in vsc.list_endpoints().get("endpoints", [])]
if VS_ENDPOINT not in existing:
    vsc.create_endpoint_and_wait(name=VS_ENDPOINT, endpoint_type="STANDARD")
print(vsc.get_endpoint(VS_ENDPOINT).get("endpoint_status"))
# Then: Compute > Vector Search > agents-course-vs > Permissions > add the participant group (Can Use / Can Manage)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Before Phase 3: run `00_setup` and then `01_prepare_data` as yourself
# MAGIC They create your own schema (`course.<you>_support`) with the course data and the policy chunks that
# MAGIC Phase 3 copies into `course.shared`. Come back here when `01_prepare_data` prints *Checkpoint A passed*.

# COMMAND ----------

# MAGIC %md ## Phase 3: checkpoint copies and checkpoint index in `course.shared`

# COMMAND ----------

src = FQ   # your own schema after 00_setup + 01_prepare_data
assert spark.catalog.tableExists(f"{src}.policy_chunks"), "run 00_setup and 01_prepare_data first"
for t in ["orders", "customers", "products", "order_lines", "tickets", "policy_chunks"]:
    spark.sql(f"CREATE OR REPLACE TABLE {CATALOG}.{SHARED_SCHEMA}.{t} DEEP CLONE {src}.{t}")
spark.sql(f"ALTER TABLE {CATALOG}.{SHARED_SCHEMA}.policy_chunks SET TBLPROPERTIES (delta.enableChangeDataFeed = true)")

try:
    vsc.get_index(VS_ENDPOINT, SHARED_INDEX).sync()
    print("checkpoint index exists: sync triggered")
except Exception:
    vsc.create_delta_sync_index(endpoint_name=VS_ENDPOINT, index_name=SHARED_INDEX,
                                source_table_name=f"{CATALOG}.{SHARED_SCHEMA}.policy_chunks",
                                primary_key="chunk_id", pipeline_type="TRIGGERED",
                                embedding_source_column="chunk_text",
                                embedding_model_endpoint_name=EMBEDDING_ENDPOINT)
    print("checkpoint index creating (ready in a few minutes)")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Phase 4: shared settings
# MAGIC Fill the widgets after you have created each asset (handbook chapter 2), then run the cell.
# MAGIC Empty widgets are skipped, so you can run this cell several times.
# MAGIC - `shared_genie_space_id`: a Genie space on `course.shared` (Lab 4 recipe)
# MAGIC - `shared_checkpoint_endpoint`: the endpoint you deployed by running `12_deploy` yourself
# MAGIC - `shared_ka_endpoint`: the Agent Bricks Knowledge Assistant endpoint (Module 7)

# COMMAND ----------

for key in ("shared_genie_space_id", "shared_checkpoint_endpoint", "shared_ka_endpoint"):
    dbutils.widgets.text(key, "", key)


def set_shared(key: str, value: str) -> None:
    spark.sql(f"DELETE FROM {SHARED_SETTINGS} WHERE key = :k", args={"k": key})
    spark.sql(f"INSERT INTO {SHARED_SETTINGS} VALUES (:k, :v)", args={"k": key, "v": value})


for key in ("shared_genie_space_id", "shared_checkpoint_endpoint", "shared_ka_endpoint"):
    value = dbutils.widgets.get(key).strip()
    if value:
        set_shared(key, value)
display(spark.table(SHARED_SETTINGS))

# COMMAND ----------

# MAGIC %md ## Phase 5: automated readiness check (re-run until everything is OK)

# COMMAND ----------

results = {}


def check(name, fn):
    try:
        out = fn()
        results[name] = "OK" if out in (None, True) else f"OK ({out})"
    except Exception as e:
        results[name] = f"FAILED: {type(e).__name__}: {str(e)[:140]}"


def _must(cond, msg):
    if not cond:
        raise RuntimeError(msg)


check("catalog + shared schema", lambda: spark.sql(f"DESCRIBE SCHEMA {CATALOG}.{SHARED_SCHEMA}").count())
check("chat endpoint", lambda: w.serving_endpoints.get(LLM_ENDPOINT).name)
check("small chat endpoint", lambda: w.serving_endpoints.get(LLM_SMALL_ENDPOINT).name)
check("embedding endpoint", lambda: w.serving_endpoints.get(EMBEDDING_ENDPOINT).name)
check("vector search endpoint ONLINE", lambda: _must(
    vsc.get_endpoint(VS_ENDPOINT).get("endpoint_status", {}).get("state") == "ONLINE", "not ONLINE yet"))
check("checkpoint index ready", lambda: _must(
    vsc.get_index(VS_ENDPOINT, SHARED_INDEX).describe().get("status", {}).get("ready"), "not ready yet"))
check("sql warehouse", lambda: _must(bool(WAREHOUSE_ID), "WAREHOUSE_ID empty") or w.warehouses.get(WAREHOUSE_ID).name)
check("participant group exists", lambda: _must(any(True for _ in w.groups.list(filter=f'displayName eq "{COURSE_GROUP}"')), "missing"))
check("analyst group exists", lambda: _must(any(True for _ in w.groups.list(filter=f'displayName eq "{ANALYST_GROUP}"')), "missing"))
check("secret course/analyst_pat", lambda: _must("analyst_pat" in [s.key for s in w.secrets.list_secrets("course")], "missing: see handbook 2.4"))
check("ai_query works", lambda: spark.sql(f"SELECT ai_query('{LLM_ENDPOINT}', 'Reply with OK') AS r").first()[0][:20])
for key in ("shared_genie_space_id", "shared_checkpoint_endpoint", "shared_ka_endpoint"):
    check(f"setting {key}", lambda k=key: _must(get_setting(k), "not set yet (Phase 4)") or get_setting(k))

for k, v in results.items():
    print(f"{k:34} {v}")
blocking = [k for k, v in results.items() if v.startswith("FAILED") and not k.startswith("setting shared_ka")]
print("\nINSTRUCTOR SETUP COMPLETE" if not blocking else f"\nNOT READY: fix {blocking}")
