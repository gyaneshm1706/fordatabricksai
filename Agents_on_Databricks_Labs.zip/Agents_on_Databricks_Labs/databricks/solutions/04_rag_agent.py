# Databricks notebook source
# MAGIC %md
# MAGIC # Lab 3 · Parts C–D: author, trace and improve a RAG agent (23 min) — also Demo 7
# MAGIC **Goal:** a RAG agent on a Foundation Model endpoint that cites sources, declines out-of-scope questions,
# MAGIC and writes MLflow traces you can inspect.
# MAGIC
# MAGIC The agent lives in `agents/rag_agent.py` (models-from-code): the retriever tool and the `predict_stream` loop.

# COMMAND ----------

# MAGIC %pip install -U -qqq "mlflow[databricks]>=3.1" databricks-langchain databricks-vectorsearch langgraph
# MAGIC # Instructor: after a dry run, pin exact versions here and in requirements for deployment.

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./_config

# COMMAND ----------

import os
import sys

import mlflow
import yaml

sys.path.insert(0, AGENT_DIR)
active_index = get_setting("active_index", SHARED_INDEX)
config = {"llm_endpoint": LLM_ENDPOINT, "vs_index": active_index, "num_results": 4}
with open(os.path.join(AGENT_DIR, "agent_config.yaml"), "w") as f:
    yaml.safe_dump(config, f)
mlflow.set_experiment(EXPERIMENT)
print(config)

# COMMAND ----------

# MAGIC %md ## Load the agent and ask the five test questions

# COMMAND ----------

os.chdir(AGENT_DIR)                       # ModelConfig reads agent_config.yaml relative to the cwd
import importlib

import rag_agent

importlib.reload(rag_agent)
AGENT = rag_agent.AGENT

QUESTIONS = [
    "Can I get a refund on a late order?",
    "How many days do I have to request a refund?",
    "Is return pickup free in India for silver customers?",
    "Who approves an address change?",
    "What is the capital of Australia?",            # out of scope: should decline
]


def ask(q: str) -> str:
    resp = AGENT.predict({"input": [{"role": "user", "content": q}]})
    return resp.output[-1].content[0]["text"]


with mlflow.start_run(run_name="rag-v1"):
    for q in QUESTIONS:
        print(f"Q: {q}\nA: {ask(q)}\n")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inspect the traces
# MAGIC Open the **Traces** tab of the experiment (or the trace widget above). For each answer:
# MAGIC 1. Find the `search_policies` **RETRIEVER** span and read the documents it returned.
# MAGIC 2. Check every citation in the answer matches a returned document.
# MAGIC 3. Note latency and token usage per span (we use them in Module 6).

# COMMAND ----------

exp_id = mlflow.get_experiment_by_name(EXPERIMENT).experiment_id
traces = mlflow.search_traces(experiment_ids=[exp_id], max_results=5, return_type="list")
for t in traces:
    retr = t.search_spans(span_type="RETRIEVER")
    docs = retr[0].outputs if retr else []
    sources = sorted({(d.get("metadata") or {}).get("doc_uri", "?") for d in (docs or []) if isinstance(d, dict)})
    print(f"{t.info.trace_id}  {t.info.execution_duration} ms  retrieved={sources}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Part D: improve one thing (8 min)
# MAGIC Change **one** of: `num_results` in the config, the tool description, or the filter in `rag_agent.py`.
# MAGIC Re-run the questions under a new run name, then compare both runs' traces. Post before/after in chat.

# COMMAND ----------

# >>> SOLUTION: example improvement: fewer, better chunks (k=2) and compare
config["num_results"] = 2
with open(os.path.join(AGENT_DIR, "agent_config.yaml"), "w") as f:
    yaml.safe_dump(config, f)
importlib.reload(rag_agent)
AGENT = rag_agent.AGENT
with mlflow.start_run(run_name="rag-v1-k2"):
    for q in QUESTIONS:
        print(f"Q: {q}\nA: {ask(q)}\n")
# <<< SOLUTION
