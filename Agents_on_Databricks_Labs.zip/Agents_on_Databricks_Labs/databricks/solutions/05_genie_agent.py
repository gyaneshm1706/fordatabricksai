# Databricks notebook source
# MAGIC %md
# MAGIC # Lab 4: a Genie space you can trust, used by your agent (50 min) — also Demo 9
# MAGIC | Part | Where | Time |
# MAGIC |---|---|---|
# MAGIC | A. Create the space, ask 5 questions | Genie UI + this notebook (save the id) | 10 min |
# MAGIC | B. Semantics | `06_semantics` | 15 min |
# MAGIC | C. Benchmarks | Genie UI, with the CSV this notebook renders | 15 min |
# MAGIC | D. Use Genie from your agent | this notebook | 10 min |

# COMMAND ----------

# MAGIC %pip install -U -qqq "mlflow[databricks]>=3.1" databricks-langchain databricks-sdk databricks-vectorsearch langgraph

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./_config

# COMMAND ----------

# MAGIC %md
# MAGIC ## Part A: create the space
# MAGIC Follow `lab_assets/genie_instructions.md`: **New → Genie space**, warehouse, the 4 tables, then ask the five sample
# MAGIC questions. For each wrong answer, open **Show code** and write down *why* it's wrong.
# MAGIC Paste the space id (from the URL `.../genie/rooms/<space_id>`) below and run the cell.

# COMMAND ----------

dbutils.widgets.text("genie_space_id", get_setting("genie_space_id"), "Genie space id")   # your own space
space_id = dbutils.widgets.get("genie_space_id").strip()
assert space_id, "paste your Genie space id in the widget at the top"
set_setting("genie_space_id", space_id)
print(f"saved genie_space_id={space_id}")

# COMMAND ----------

# MAGIC %md ## Conversation API: the same space, from code

# COMMAND ----------

import os
import sys

sys.path.insert(0, AGENT_DIR)
from databricks.sdk import WorkspaceClient
from genie_tool import GENIE_DESCRIPTION, ask_genie, make_genie_tool

w = WorkspaceClient()
print(ask_genie(space_id, "How many orders were late last week in the North region?", w))

# COMMAND ----------

# Follow-ups keep conversational context
msg = w.genie.start_conversation_and_wait(space_id, "Revenue by region in the last 90 days")
follow = w.genie.create_message_and_wait(space_id, msg.conversation_id, "Only for the North region")
for att in follow.attachments or []:
    if att.query:
        print(att.query.query)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Part C: benchmarks
# MAGIC The cell below renders the 20 benchmark questions with **your** table names. In the space: **Benchmarks → Add**,
# MAGIC paste each question and its expected SQL (or import the CSV if your UI offers it). Run all, open failures,
# MAGIC fix with **one** example SQL or instruction at a time, and re-run. Target ≥ 85%, and the 3 out-of-scope
# MAGIC questions must be declined.

# COMMAND ----------

import csv
import io

tpl = open(os.path.join(NOTEBOOK_DIR, "lab_assets", "benchmarks_template.csv"), encoding="utf-8").read()
rendered = tpl.replace("{FQ}", FQ)
spark.sql(f"CREATE VOLUME IF NOT EXISTS {FQ}.lab_files")
with open(f"/Volumes/{CATALOG}/{SCHEMA}/lab_files/genie_benchmarks.csv", "w", encoding="utf-8") as f:
    f.write(rendered)
display(spark.createDataFrame(list(csv.DictReader(io.StringIO(rendered)))))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Part D: Genie as a tool in your agent
# MAGIC The agent now has two tools: `search_policies` (documents) and `sales_analyst` (Genie, governed SQL).
# MAGIC Routing depends on the **tool descriptions**. Read them before running.

# COMMAND ----------

import mlflow
from databricks_langchain import ChatDatabricks, VectorSearchRetrieverTool
from langgraph.prebuilt import create_react_agent

mlflow.set_experiment(EXPERIMENT)
mlflow.langchain.autolog()

LLM = ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0)
search_policies = VectorSearchRetrieverTool(
    index_name=get_setting("active_index", SHARED_INDEX), tool_name="search_policies",
    tool_description="Search current support policies (refunds, late deliveries, shipping, returns, address changes).",
    num_results=3, columns=["chunk_id", "source", "section", "chunk_text"], filters={"superseded": False})

# >>> SOLUTION: build the Genie tool with a precise description and add it next to the retriever
sales_analyst = make_genie_tool(space_id, GENIE_DESCRIPTION)
tools = [search_policies, sales_analyst]
# >>> STARTER
# tools = [search_policies]          # TODO: add make_genie_tool(space_id, <your description>)
# <<< SOLUTION

agent = create_react_agent(LLM, tools=tools, prompt=(
    "You are a support and operations assistant. Use sales_analyst for numbers about orders, revenue and late "
    "deliveries; use search_policies for rules and cite [source > section]. Combine both when asked."))

for q in ["How many orders were late last week in the North region?",
          "And what does our policy say we owe customers whose orders are late?"]:
    out = agent.invoke({"messages": [("user", q)]}, {"recursion_limit": 12})
    called = [c["name"] for m in out["messages"] for c in (getattr(m, "tool_calls", None) or [])]
    print(f"Q: {q}\nTools: {called}\nA: {out['messages'][-1].content}\n")

# COMMAND ----------

# MAGIC %md
# MAGIC **Checkpoint D:** open the newest traces. The first question should call `sales_analyst` (its span contains the
# MAGIC Genie SQL); the second should call `search_policies`. If routing is wrong, improve one tool description and re-run.
# MAGIC
# MAGIC *Alternative:* `from databricks_langchain.genie import GenieAgent` wraps a space as a LangChain runnable,
# MAGIC and the managed MCP server `/api/2.0/mcp/genie/{space_id}` exposes it to any MCP client (Module 5).
