# Databricks notebook source
# MAGIC %md
# MAGIC # Lab 5 · Part A: governed tools as Unity Catalog functions (12 min) — also Demo 10
# MAGIC **Goal:** two UC functions (SQL for data, Python for logic), unit-tested without any LLM, then used by the agent.

# COMMAND ----------

# MAGIC %pip install -U -qqq "mlflow[databricks]>=3.1" databricks-langchain "unitycatalog-ai[databricks]" langgraph

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./_config

# COMMAND ----------

# MAGIC %md ## 1. SQL function: one parameterised lookup over governed tables
# MAGIC The COMMENTs become the tool description the model reads. Write them like Module 1 taught.

# COMMAND ----------

# >>> SOLUTION: scalar SQL function returning JSON (or NOT_FOUND) for one order, incl. days_late and customer tier
spark.sql(f"""
CREATE OR REPLACE FUNCTION {FQ}.get_order_status(
  order_id STRING COMMENT 'Order id, e.g. ORD-10293')
RETURNS STRING
COMMENT 'Shipping status, promised date, ETA, days late and customer tier for ONE order. Use when a customer asks
where an order is, whether it is late, or before computing a refund. Not for refunds or address changes.'
RETURN COALESCE(
  (SELECT to_json(named_struct(
            'order_id', o.order_id, 'status', o.status, 'promised_date', o.promised_date, 'eta', o.eta,
            'days_late', GREATEST(datediff(o.eta, o.promised_date), 0), 'city', o.city,
            'customer_tier', c.tier, 'amount', o.amount, 'delivery_note', o.delivery_note))
   FROM {FQ}.orders o JOIN {FQ}.customers c ON c.customer_id = o.customer_id
   WHERE o.order_id = get_order_status.order_id),
  CONCAT('NOT_FOUND: no order ', order_id))
""")
# <<< SOLUTION
display(spark.sql(f"SELECT {FQ}.get_order_status('ORD-10377') AS r UNION ALL SELECT {FQ}.get_order_status('ORD-99999')"))

# COMMAND ----------

# MAGIC %md ## 2. Python function: business logic, sandboxed and governed

# COMMAND ----------

# >>> SOLUTION: Python UC function implementing policy RP-204 (read-only calculation, no refund issued)
spark.sql(f"""
CREATE OR REPLACE FUNCTION {FQ}.refund_eligibility(
  days_late INT COMMENT 'Days past the promised date (0 if on time)',
  tier STRING COMMENT 'Customer tier: gold | silver | standard',
  amount DOUBLE COMMENT 'Order value in INR')
RETURNS STRING
LANGUAGE PYTHON
COMMENT 'Computes late-delivery refund eligibility per policy RP-204. Read-only calculation; does NOT issue a refund.
Call get_order_status first to get days_late, tier and amount.'
AS $$
import json
if days_late is None or days_late <= 2:
    return json.dumps({{"eligible": False, "reason": "2 days late or less", "voucher_pct": 10 if days_late else 0}})
pct = {{"gold": 1.0, "silver": 0.5}}.get((tier or "").lower(), 0.25)
return json.dumps({{"eligible": True, "refund_pct": int(pct * 100), "refund": round(amount * pct, 2),
                   "note": "A human agent issues the refund."}})
$$
""")
# <<< SOLUTION
display(spark.sql(f"SELECT {FQ}.refund_eligibility(5, 'silver', 2400) AS r"))

# COMMAND ----------

# MAGIC %md ## 3. Unit-test the tools without an LLM

# COMMAND ----------

import json

from unitycatalog.ai.core.databricks import DatabricksFunctionClient

uc = DatabricksFunctionClient()
r = uc.execute_function(f"{FQ}.refund_eligibility", {"days_late": 5, "tier": "silver", "amount": 2400.0})
assert json.loads(r.value)["refund"] == 1200.0, r
r = uc.execute_function(f"{FQ}.get_order_status", {"order_id": "ORD-99999"})
assert r.value.startswith("NOT_FOUND"), r
print("tool unit tests passed")

# COMMAND ----------

# MAGIC %md ## 4. Use them from the agent

# COMMAND ----------

import mlflow
from databricks_langchain import ChatDatabricks, UCFunctionToolkit
from langgraph.prebuilt import create_react_agent

mlflow.set_experiment(EXPERIMENT)
mlflow.langchain.autolog()
uc_tools = UCFunctionToolkit(function_names=[f"{FQ}.get_order_status", f"{FQ}.refund_eligibility"]).tools
print([t.name for t in uc_tools])

agent = create_react_agent(ChatDatabricks(endpoint=LLM_ENDPOINT, temperature=0), tools=uc_tools,
                           prompt="You are an order-support assistant. Use the tools; never invent numbers.")
out = agent.invoke({"messages": [("user", "ORD-10377 arrived late. What refund is the customer eligible for?")]})
print(out["messages"][-1].content)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Governed write target for the approval-gated action (used in Part C)
# MAGIC UC functions are **read-only**: they cannot change data. Actions write through a governed table instead.
# MAGIC Here the agent may only *request* an address change; MODIFY on this table decides who can.

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {REQUESTS_TABLE} (
  order_id STRING, new_address STRING, requested_by STRING, requested_at TIMESTAMP, status STRING)
COMMENT 'Address-change requests created by the support agent after human approval.'""")
print(f"{REQUESTS_TABLE} ready")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Optional (admin): external API through a governed UC connection
# MAGIC Run only if you have CREATE CONNECTION and a secret scope `course` with key `shipco_token`.

# COMMAND ----------

CREATE_CONNECTION = False
if CREATE_CONNECTION:
    spark.sql("""
    CREATE CONNECTION IF NOT EXISTS shipco_api TYPE HTTP
    OPTIONS (host 'https://api.shipco.example', port '443', base_path '/v2',
             bearer_token secret('course', 'shipco_token'))""")
    spark.sql(f"GRANT USE CONNECTION ON CONNECTION shipco_api TO `{COURSE_GROUP}`")
    spark.sql(f"""
    CREATE OR REPLACE FUNCTION {FQ}.track_shipment(tracking_no STRING COMMENT 'Carrier tracking number')
    RETURNS STRING
    COMMENT 'Live tracking from ShipCo. Read-only GET. Use after get_order_status returns a tracking number.'
    RETURN (SELECT http_request(conn => 'shipco_api', method => 'GET', path => CONCAT('/track/', tracking_no)).text)""")
