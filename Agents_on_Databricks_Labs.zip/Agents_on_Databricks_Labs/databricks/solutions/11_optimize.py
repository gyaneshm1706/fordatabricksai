# Databricks notebook source
# MAGIC %md
# MAGIC # Lab 6 · Part B: one measured optimisation (14 min) — also Demo 14
# MAGIC **Goal:** find the worst traces, write a hypothesis, change **one** thing, re-run the same evaluation and
# MAGIC decide to ship or revert with numbers. Run `10_evaluate` first (it defines the dataset and baseline).

# COMMAND ----------

# MAGIC %pip install -U -qqq "mlflow[databricks]>=3.1" databricks-langchain "unitycatalog-ai[databricks]" databricks-sdk databricks-vectorsearch databricks-ai-bridge langgraph

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./_config

# COMMAND ----------

import mlflow
import pandas as pd

mlflow.set_experiment(EXPERIMENT)
baseline_run = get_setting("baseline_run_id")
assert baseline_run, "run 10_evaluate first"

# COMMAND ----------

# MAGIC %md ## 1. Diagnose from traces: distribution first, then the worst 10

# COMMAND ----------

# >>> SOLUTION: per-trace latency, LLM calls, tool calls and tokens for the baseline run
traces = mlflow.search_traces(run_id=baseline_run, max_results=500, return_type="list")
rows = []
for t in traces:
    usage = getattr(t.info, "token_usage", None) or {}
    rows.append({
        "trace_id": t.info.trace_id,
        "request": str(t.data.request)[:80],
        "ms": t.info.execution_duration,
        "llm_calls": len(t.search_spans(span_type="CHAT_MODEL")),
        "tool_calls": len(t.search_spans(span_type="TOOL")),
        "tokens": usage.get("total_tokens"),
    })
df = pd.DataFrame(rows)
# >>> STARTER
# traces = mlflow.search_traces(run_id=baseline_run, max_results=500, return_type="list")
# rows = []   # TODO: one dict per trace: trace_id, request, ms, llm_calls, tool_calls, tokens
# df = pd.DataFrame(rows, columns=["trace_id", "request", "ms", "llm_calls", "tool_calls", "tokens"])
# <<< SOLUTION
display(df.describe(percentiles=[0.5, 0.95]))
display(df.sort_values("ms", ascending=False).head(10))

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Write your hypothesis before changing anything
# MAGIC Example: *"Retrieval k 4→2 cuts input tokens ~25% and p95 latency, with correctness and groundedness within 2 points."*

# COMMAND ----------

HYPOTHESIS = "k 4->2 cuts tokens ~25%; correctness and groundedness hold within 2 points"
CHANGE = {"num_results": 2}                                       # exactly one change

# COMMAND ----------

# MAGIC %md ## 3. Re-run the same evaluation with the change

# COMMAND ----------

import importlib
import os
import sys

import yaml

sys.path.insert(0, AGENT_DIR)
cfg_path = os.path.join(AGENT_DIR, "agent_config.yaml")
config = yaml.safe_load(open(cfg_path))
ORIGINAL = {k: config.get(k) for k in CHANGE}
config.update(CHANGE)
yaml.safe_dump(config, open(cfg_path, "w"))
os.chdir(AGENT_DIR)
import support_agent

importlib.reload(support_agent)
AGENT = support_agent.AGENT

from mlflow.genai import datasets as genai_datasets

eval_ds = genai_datasets.get_dataset(EVAL_TABLE)

# Re-use the scorer definitions from 10_evaluate (same dataset, same scorers = a fair comparison)
from mlflow.entities import Feedback
from mlflow.genai.scorers import Correctness, Guidelines, RelevanceToQuery, RetrievalGroundedness, Safety, scorer


@scorer
def tool_success(trace) -> Feedback:
    bad = [s.name for s in trace.search_spans(span_type="TOOL") if str(s.outputs).startswith(("ERROR", "TOOL_ERROR"))]
    return Feedback(value=not bad, rationale=f"failed tools: {bad}" if bad else "all tools ok")


@scorer
def expected_tools_called(trace, expectations):
    expected = set(expectations.get("expected_tools", []))
    return None if not expected else expected <= {s.name.split("__")[-1] for s in trace.search_spans(span_type="TOOL")}


@scorer
def latency_slo(trace) -> bool:
    return trace.info.execution_duration < 8_000


@scorer
def llm_calls(trace) -> int:
    return len(trace.search_spans(span_type="CHAT_MODEL"))


SCORERS = [Correctness(), RelevanceToQuery(), RetrievalGroundedness(), Safety(),
           Guidelines(name="cites_sources", guidelines="Any statement about company policy cites a source in brackets."),
           tool_success, expected_tools_called, latency_slo, llm_calls]


def predict_fn(question: str) -> str:
    return AGENT.predict({"input": [{"role": "user", "content": question}]}).output[-1].content[0]["text"]


with mlflow.start_run(run_name="v0.3.1-candidate") as run:
    mlflow.set_tags({"agent_version": "0.3.1", "hypothesis": HYPOTHESIS, "change": str(CHANGE)})
    candidate = mlflow.genai.evaluate(data=eval_ds, predict_fn=predict_fn, scorers=SCORERS)

# COMMAND ----------

# MAGIC %md ## 4. Compare, then ship or revert

# COMMAND ----------

client = mlflow.tracking.MlflowClient()
base = client.get_run(baseline_run).data.metrics
cand = client.get_run(run.info.run_id).data.metrics
cmp = pd.DataFrame([(k, base.get(k), cand.get(k)) for k in sorted(set(base) | set(cand))],
                   columns=["metric", "baseline", "candidate"])
cmp["delta"] = cmp["candidate"] - cmp["baseline"]
display(cmp)

# >>> SOLUTION: decide with numbers: quality must hold (no drop > 0.02 on correctness/groundedness/safety)
quality = [m for m in cmp.metric if any(k in m for k in ("correctness", "groundedness", "safety")) and m.endswith("mean")]
drops = cmp[cmp.metric.isin(quality) & (cmp.delta < -0.02)]
decision = "REVERT" if len(drops) else "SHIP"
# >>> STARTER
# drops = cmp.iloc[0:0]
# decision = "TODO"   # TODO: SHIP only if correctness, groundedness and safety did not drop by more than 0.02
# <<< SOLUTION
print(f"Decision: {decision}\n{drops if len(drops) else 'quality held'}")
set_setting("candidate_decision", decision)
if decision == "REVERT":
    config.update(ORIGINAL)
    yaml.safe_dump(config, open(cfg_path, "w"))
    print("config reverted")
