# Databricks notebook source
# MAGIC %md
# MAGIC # Module 7 demo · Operating the deployed agent (Demo 16 + rollout)
# MAGIC Production scorers, cost from system tables, AI Gateway rate limits, and a canary traffic split with rollback.
# MAGIC Several APIs here are recent; if one differs in your workspace, the markdown explains the intent.

# COMMAND ----------

# MAGIC %pip install -U -qqq "mlflow[databricks]>=3.1" databricks-sdk

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./_config

# COMMAND ----------

import mlflow

mlflow.set_experiment(EXPERIMENT)
ENDPOINT = get_setting("endpoint_name")
print("endpoint:", ENDPOINT)

# COMMAND ----------

# MAGIC %md ## 1. Production quality monitoring: the same scorers as offline evaluation, on live traces

# COMMAND ----------

from mlflow.genai.scorers import Guidelines, RetrievalGroundedness, Safety, ScorerSamplingConfig

try:
    Safety().register(name="prod_safety").start(sampling_config=ScorerSamplingConfig(sample_rate=1.0))
    RetrievalGroundedness().register(name="prod_groundedness").start(sampling_config=ScorerSamplingConfig(sample_rate=0.2))
    Guidelines(name="cites_sources", guidelines="Policy answers cite sources.").register(name="prod_cites") \
        .start(sampling_config=ScorerSamplingConfig(sample_rate=0.2))
    print("production scorers running: safety 100%, groundedness 20%, citations 20%")
except Exception as e:
    print(f"production monitoring API not available here ({type(e).__name__}: {e}); use the experiment's Monitoring UI")

# COMMAND ----------

# MAGIC %md ## 2. Cost and usage by day and caller (system tables)

# COMMAND ----------

display(spark.sql(f"""
SELECT DATE_TRUNC('DAY', u.request_time) AS day, u.requester,
       COUNT(*) AS requests, SUM(u.input_token_count) AS input_tokens, SUM(u.output_token_count) AS output_tokens
FROM system.serving.endpoint_usage u
JOIN system.serving.served_entities e ON u.served_entity_id = e.served_entity_id
WHERE e.endpoint_name = '{ENDPOINT}' AND u.request_time >= current_date() - INTERVAL 7 DAYS
GROUP BY ALL ORDER BY day, input_tokens DESC"""))

# COMMAND ----------

# MAGIC %md ## 3. AI Gateway: a per-user rate limit, then a burst from one caller

# COMMAND ----------

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import AiGatewayRateLimit, AiGatewayRateLimitKey, AiGatewayRateLimitRenewalPeriod

w = WorkspaceClient()
try:
    w.serving_endpoints.put_ai_gateway(
        name=ENDPOINT,
        rate_limits=[AiGatewayRateLimit(calls=30, key=AiGatewayRateLimitKey.USER,
                                        renewal_period=AiGatewayRateLimitRenewalPeriod.MINUTE)])
    print("rate limit: 30 calls / user / minute")
except Exception as e:
    print(f"configure the limit in the endpoint's AI Gateway tab instead ({type(e).__name__}: {str(e)[:120]})")

# COMMAND ----------

oai = w.serving_endpoints.get_open_ai_client()
codes = {}
for i in range(40):
    try:
        oai.responses.create(model=ENDPOINT, input=[{"role": "user", "content": "Where is ORD-10293?"}])
        codes["200"] = codes.get("200", 0) + 1
    except Exception as e:
        key = "429" if "429" in str(e) else type(e).__name__
        codes[key] = codes.get(key, 0) + 1
print(codes)        # expect some 429s once the per-user limit is reached

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Canary rollout and one-step rollback
# MAGIC Needs two registered versions (e.g. re-run `12_deploy` after an improvement). Uses explicit traffic routes.

# COMMAND ----------

from databricks.sdk.service.serving import Route, ServedEntityInput, TrafficConfig

endpoint = w.serving_endpoints.get(ENDPOINT)
print([(e.name, e.entity_version) for e in endpoint.config.served_entities])


def served(version: str) -> ServedEntityInput:
    return ServedEntityInput(name=f"v{version}", entity_name=UC_MODEL, entity_version=version,
                             workload_size="Small", scale_to_zero_enabled=True)


def split(old: str, new: str, new_pct: int) -> None:
    w.serving_endpoints.update_config(
        name=ENDPOINT, served_entities=[served(old), served(new)],
        traffic_config=TrafficConfig(routes=[Route(served_model_name=f"v{old}", traffic_percentage=100 - new_pct),
                                             Route(served_model_name=f"v{new}", traffic_percentage=new_pct)]))
    print(f"v{old}: {100 - new_pct}%  v{new}: {new_pct}%")

# split("1", "2", 10)    # canary: watch production scorers per version for 24-72 h
# split("1", "2", 0)     # ROLLBACK: all traffic back to v1, then move the champion alias back

# COMMAND ----------

# MAGIC %md ## 5. Data freshness: alert when the index lags its source table

# COMMAND ----------

from databricks.vector_search.client import VectorSearchClient

desc = VectorSearchClient(disable_notice=True).get_index(VS_ENDPOINT, get_setting("active_index", SHARED_INDEX)).describe()
print({k: desc.get("status", {}).get(k) for k in ("ready", "detailed_state", "message", "indexed_row_count")})
