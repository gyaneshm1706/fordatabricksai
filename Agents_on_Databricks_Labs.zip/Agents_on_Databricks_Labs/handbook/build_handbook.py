"""Build the Databricks Lab Handbook PDF.   python build_handbook.py [output.pdf]

Content lives in handbook_content.py; this file only does layout (ReportLab).
"""
import pathlib
import sys

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (BaseDocTemplate, CondPageBreak, Flowable, Frame, KeepTogether, NextPageTemplate,
                                PageBreak, PageTemplate, Paragraph, Preformatted, Spacer, Table, TableStyle)
from reportlab.platypus.tableofcontents import TableOfContents

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import handbook_content as C  # noqa: E402

# ---------- fonts (Windows fonts have the glyphs we need: arrows, >=, en dash) ----------
FONTS = pathlib.Path("C:/Windows/Fonts")
pdfmetrics.registerFont(TTFont("Body", str(FONTS / "calibri.ttf")))
pdfmetrics.registerFont(TTFont("Body-Bold", str(FONTS / "calibrib.ttf")))
pdfmetrics.registerFont(TTFont("Body-Italic", str(FONTS / "calibrii.ttf")))
pdfmetrics.registerFont(TTFont("Body-BoldItalic", str(FONTS / "calibriz.ttf")))
pdfmetrics.registerFont(TTFont("Mono", str(FONTS / "consola.ttf")))
pdfmetrics.registerFont(TTFont("Mono-Bold", str(FONTS / "consolab.ttf")))
pdfmetrics.registerFont(TTFont("Sym", str(FONTS / "seguisym.ttf")))
from reportlab.pdfbase.pdfmetrics import registerFontFamily  # noqa: E402

registerFontFamily("Body", normal="Body", bold="Body-Bold", italic="Body-Italic", boldItalic="Body-BoldItalic")
registerFontFamily("Mono", normal="Mono", bold="Mono-Bold", italic="Mono", boldItalic="Mono-Bold")

NAVY = colors.HexColor("#13233F")
CORAL = colors.HexColor("#FF5A36")
TEAL = colors.HexColor("#0EA5A4")
AMBER = colors.HexColor("#F5A524")
VIOLET = colors.HexColor("#7C3AED")
SLATE = colors.HexColor("#64748B")
MIST = colors.HexColor("#EEF2F7")
INK = colors.HexColor("#0F172A")
CODEBG = colors.HexColor("#F3F5F8")

ST = {
    "body": ParagraphStyle("body", fontName="Body", fontSize=10.5, leading=14.5, textColor=INK, spaceAfter=5),
    "small": ParagraphStyle("small", fontName="Body", fontSize=9, leading=12, textColor=SLATE),
    "h1": ParagraphStyle("h1", fontName="Body-Bold", fontSize=22, leading=27, textColor=NAVY, spaceBefore=0, spaceAfter=10),
    "h2": ParagraphStyle("h2", fontName="Body-Bold", fontSize=14.5, leading=19, textColor=NAVY, spaceBefore=12, spaceAfter=5),
    "h3": ParagraphStyle("h3", fontName="Body-Bold", fontSize=11.5, leading=15, textColor=INK, spaceBefore=8, spaceAfter=3),
    "cell": ParagraphStyle("cell", fontName="Body", fontSize=9, leading=11.5, textColor=INK),
    "cellb": ParagraphStyle("cellb", fontName="Body-Bold", fontSize=9, leading=11.5, textColor=colors.white),
    "step": ParagraphStyle("step", fontName="Body", fontSize=10.5, leading=14.5, textColor=INK),
    "code": ParagraphStyle("code", fontName="Mono", fontSize=8.3, leading=10.6, textColor=INK),
    "toc1": ParagraphStyle("toc1", fontName="Body-Bold", fontSize=11, leading=17, leftIndent=0),
    "toc2": ParagraphStyle("toc2", fontName="Body", fontSize=9.5, leading=13, leftIndent=14, textColor=SLATE),
}
CALLOUT = {  # kind -> (label, colour)
    "check": ("CHECK", TEAL), "expect": ("EXPECTED OUTPUT", colors.HexColor("#2563EB")), "warn": ("WATCH OUT", AMBER),
    "fail": ("IF IT FAILS", CORAL), "note": ("NOTE", SLATE), "who": ("WHO / WHEN", VIOLET), "done": ("DONE WHEN", TEAL),
}


def md(text: str) -> str:
    """Tiny markup: **bold**, `code`, <br/> kept; escapes & < > otherwise."""
    import re
    text = text.replace("&", "&amp;").replace("<br/>", "\x00").replace("<", "&lt;").replace(">", "&gt;").replace("\x00", "<br/>")
    codes = []

    def _hold(m):                      # protect code spans so * inside them is not read as italics
        codes.append(m.group(1))
        return f"\x01{len(codes) - 1}\x02"

    text = re.sub(r"`([^`]+)`", _hold, text)
    text = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)
    text = re.sub(r"(?<![\w*])\*(?!\s)([^*\n]+?)(?<!\s)\*(?![\w*])", r"<i>\1</i>", text)
    return re.sub(r"\x01(\d+)\x02", lambda m: f'<font name="Mono" size="8.8" color="#9A2A12">{codes[int(m.group(1))]}</font>', text)


def plain(text: str) -> str:
    """Heading text for the contents page and running header: no markup characters."""
    return text.replace("`", "").replace("**", "")


class ChapterMark(Flowable):
    """Zero-size flowable that registers a TOC entry and the running header text."""

    def __init__(self, level, text, key):
        super().__init__()
        self.level, self.text, self.key = level, text, key

    def wrap(self, *a):
        return 0, 0

    def draw(self):
        self.canv.bookmarkPage(self.key)
        self.canv.addOutlineEntry(self.text, self.key, level=self.level, closed=self.level > 0)
        if self.level == 0:
            self.canv._chapter = self.text
        self.canv._doctemplate.notify("TOCEntry", (self.level, self.text, self.canv.getPageNumber(), self.key))


class Doc(BaseDocTemplate):
    def __init__(self, path):
        super().__init__(str(path), pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=20 * mm,
                         bottomMargin=18 * mm, title=C.TITLE, author="DataCouch Faculty", subject=C.SUBTITLE)
        fr = Frame(self.leftMargin, self.bottomMargin, self.width, self.height, id="f")
        self.addPageTemplates([PageTemplate("cover", [fr], onPage=self.cover_bg),
                               PageTemplate("body", [fr], onPage=self.header_footer)])

    def cover_bg(self, canv, doc):
        canv.saveState()
        canv.setFillColor(NAVY)
        canv.rect(0, 0, A4[0], A4[1], fill=1, stroke=0)
        canv.setFillColor(CORAL)
        canv.circle(A4[0] - 45 * mm, A4[1] - 70 * mm, 28 * mm, fill=1, stroke=0)
        canv.setFillColor(TEAL)
        canv.circle(A4[0] - 45 * mm, A4[1] - 70 * mm, 16 * mm, fill=1, stroke=0)
        canv.restoreState()

    def header_footer(self, canv, doc):
        canv.saveState()
        canv.setFont("Body", 8.5)
        canv.setFillColor(SLATE)
        canv.drawString(self.leftMargin, A4[1] - 12 * mm, C.SHORT_TITLE)
        canv.drawRightString(A4[0] - self.rightMargin, A4[1] - 12 * mm, getattr(canv, "_chapter", ""))
        canv.setStrokeColor(colors.HexColor("#D5DCE6"))
        canv.line(self.leftMargin, A4[1] - 13.5 * mm, A4[0] - self.rightMargin, A4[1] - 13.5 * mm)
        canv.drawString(self.leftMargin, 10 * mm, C.VERSION)
        canv.drawRightString(A4[0] - self.rightMargin, 10 * mm, f"Page {doc.page}")
        canv.restoreState()


W = A4[0] - 36 * mm
_key = [0]


def _k():
    _key[0] += 1
    return f"k{_key[0]}"


def h1(text):
    k = _k()
    return [PageBreak(), ChapterMark(0, plain(text), k), Paragraph(md(text), ST["h1"])]


def h2(text):
    k = _k()
    return [CondPageBreak(40 * mm), ChapterMark(1, plain(text), k), Paragraph(md(text), ST["h2"])]


def h3(text):
    return [CondPageBreak(25 * mm), Paragraph(md(text), ST["h3"])]


def p(text):
    return [Paragraph(md(text), ST["body"])]


def bullets(items):
    out = []
    for it in items:
        out.append(Paragraph(md(it), ST["body"], bulletText="•"))
    return [Table([[o] for o in out], colWidths=[W], style=[("LEFTPADDING", (0, 0), (-1, -1), 12),
                                                         ("TOPPADDING", (0, 0), (-1, -1), 0),
                                                         ("BOTTOMPADDING", (0, 0), (-1, -1), 0)])]


def steps(items, start=1):
    rows = []
    for i, it in enumerate(items, start):
        badge = Paragraph(f'<font name="Body-Bold" color="white">{i}</font>', ParagraphStyle("b", alignment=1, fontSize=9.5, leading=12))
        rows.append([badge, Paragraph(md(it), ST["step"])])
    t = Table(rows, colWidths=[7 * mm, W - 9 * mm], hAlign="LEFT")
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("BACKGROUND", (0, 0), (0, -1), NAVY),
                           ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                           ("LEFTPADDING", (1, 0), (1, -1), 8), ("LINEBELOW", (0, 0), (-1, -2), 3, colors.white)]))
    return [t, Spacer(1, 6)]


def code(text, title=None):
    lines = text.strip("\n")
    pre = Preformatted(lines, ST["code"], maxLineLength=110, newLineChars="")
    rows = ([[Paragraph(f'<font name="Body-Bold" size="8" color="#64748B">{md(title)}</font>', ST["small"])]] if title else []) + [[pre]]
    t = Table(rows, colWidths=[W])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), CODEBG), ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#D5DCE6")),
                           ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
                           ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    return [t, Spacer(1, 6)]


def callout(kind, content):
    label, col = CALLOUT[kind]
    body = content if isinstance(content, list) else [content]
    paras = [Paragraph(f'<font name="Body-Bold" size="8.5" color="{col.hexval()}">{label}</font>', ST["small"])]
    for b in body:
        if isinstance(b, str) and b.startswith("$ "):
            paras.append(Preformatted(b[2:], ST["code"], maxLineLength=105))
        else:
            paras.append(Paragraph(md(b), ParagraphStyle("c", parent=ST["body"], spaceAfter=2, bulletIndent=0),
                                   bulletText="•" if len(body) > 1 else None))
    t = Table([[x] for x in paras], colWidths=[W])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), MIST), ("LINEBEFORE", (0, 0), (0, -1), 3, col),
                           ("LEFTPADDING", (0, 0), (-1, -1), 9), ("TOPPADDING", (0, 0), (-1, -1), 2),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 2), ("TOPPADDING", (0, 0), (0, 0), 6),
                           ("BOTTOMPADDING", (0, -1), (-1, -1), 6)]))
    return [KeepTogether([t]), Spacer(1, 7)]


def table(header, rows, widths=None):
    widths = widths or [1 / len(header)] * len(header)
    data = [[Paragraph(md(h), ST["cellb"]) for h in header]] + [[Paragraph(md(str(c)), ST["cell"]) for c in r] for r in rows]
    t = Table(data, colWidths=[W * f for f in widths], repeatRows=1, hAlign="LEFT")
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), NAVY), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, MIST]),
                           ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#D5DCE6")),
                           ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                           ("LEFTPADDING", (0, 0), (-1, -1), 5), ("RIGHTPADDING", (0, 0), (-1, -1), 5)]))
    return [t, Spacer(1, 8)]


def checklist(items):
    rows = [[Paragraph('<font name="Sym" size="11">☐</font>', ST["cell"]), Paragraph(md(i), ST["cell"])] for i in items]
    t = Table(rows, colWidths=[7 * mm, W - 7 * mm], hAlign="LEFT")
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 0), (-1, -1), 0.3, colors.HexColor("#D5DCE6")),
                           ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
    return [t, Spacer(1, 8)]


BUILDERS = {"h1": h1, "h2": h2, "h3": h3, "p": p, "bullets": bullets, "steps": steps, "code": code,
            "callout": callout, "table": table, "checklist": checklist}


def render(blocks):
    story = []
    for b in blocks:
        kind, *args = b
        story += BUILDERS[kind](*args)
    return story


def cover():
    t = ParagraphStyle("t", fontName="Body-Bold", fontSize=30, leading=36, textColor=colors.white)
    s = ParagraphStyle("s", fontName="Body", fontSize=14, leading=19, textColor=colors.HexColor("#CADCFC"))
    m = ParagraphStyle("m", fontName="Body", fontSize=10.5, leading=15, textColor=colors.HexColor("#CADCFC"))
    tag = ParagraphStyle("tag", fontName="Body-Bold", fontSize=10, textColor=CORAL)
    return [Spacer(1, 52 * mm), Paragraph("LAB HANDBOOK", tag), Spacer(1, 4 * mm), Paragraph(C.TITLE, t), Spacer(1, 6 * mm),
            Paragraph(C.SUBTITLE, s), Spacer(1, 22 * mm)] + [Paragraph(md(x), m) for x in C.COVER_LINES] + [
            NextPageTemplate("body")]


def build(out):
    doc = Doc(out)
    toc = TableOfContents()
    toc.levelStyles = [ST["toc1"], ST["toc2"]]
    story = cover() + [PageBreak(), Paragraph("Contents", ST["h1"]), toc] + render(C.BLOCKS)
    doc.multiBuild(story)
    print(f"wrote {out}")


if __name__ == "__main__":
    build(pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "Databricks_Lab_Handbook.pdf")
