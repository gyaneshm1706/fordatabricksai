"""Handbook text. Blocks: ("h1", text), ("h2", text), ("h3", text), ("p", text), ("bullets", [..]), ("steps", [..]),
("code", text[, title]), ("callout", kind, text|[..]), ("table", header, rows[, widths]), ("checklist", [..])."""
from part1_setup import BLOCKS as SETUP
from part2_labs34 import BLOCKS as LABS34
from part3_labs567 import BLOCKS as LABS567

TITLE = "Databricks Lab Handbook"
SHORT_TITLE = "Building Agentic AI Systems on Databricks · Lab Handbook"
SUBTITLE = "Step-by-step setup, configuration, checks and troubleshooting, from instructor setup to Lab 7"
VERSION = "Version 1.0 · 4 November 2026 · matches databricks/labs in Agents_on_Databricks_Labs"
COVER_LINES = [
    "Building Agentic AI Systems on Databricks",
    "Covers: instructor setup · participant setup (00_setup) · Labs 3, 4, 5, 6 and 7 (notebooks 01–14) · cleanup",
    "Audience: instructors, teaching assistants and participants",
    "",
    "Read chapter 1 first. Do chapter 2 at least two days before Module 3.",
]
BLOCKS = SETUP + LABS34 + LABS567
