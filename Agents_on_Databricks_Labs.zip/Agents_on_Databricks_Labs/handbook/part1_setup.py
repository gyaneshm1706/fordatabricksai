"""Chapters 0-3: how to use, overview, instructor setup, participant setup."""

BLOCKS = [
    # ------------------------------------------------------------------ 0
    ("h1", "0. How to use this handbook"),
    ("p", "This handbook takes you from an empty Databricks workspace to the last Databricks lab of the program. "
          "Every lab step tells you **what to click or run**, **what you should see**, how to **check** it worked, "
          "and **what to do if it fails**. Follow the chapters in order the first time."),
    ("table", ["Chapter", "Who", "When"], [
        ["1. Overview: notebooks, dependencies, what each lab creates", "Everyone", "Before anything else"],
        ["2. Instructor setup (workspace, groups, warehouse, secrets, files, config, checkpoints)", "Instructor / admin", "At least 2 days before Module 3"],
        ["3. Participant setup: `00_setup`", "Every participant (and the instructor)", "Prework before Module 3"],
        ["4. Lab 3, Module 3: data grounding and a traced RAG agent", "Participants", "Module 3"],
        ["5. Lab 4, Module 4: Genie", "Participants", "Module 4"],
        ["6. Lab 5, Module 5: tools and governance", "Participants", "Module 5"],
        ["7. Lab 6, Module 6: evaluation, optimisation, deployment", "Participants", "Module 6"],
        ["8. Lab 7, Module 7: operations, multi-agent, Agent Bricks", "Participants", "Module 7"],
        ["9. Cleanup", "Participants, then instructor", "After the capstone is graded"],
        ["10. Troubleshooting (all errors in one table)", "Everyone", "Whenever something fails"],
        ["Appendices: settings keys, packages, checklists, verification status", "Instructor", "Reference"],
    ], [0.55, 0.25, 0.2]),
    ("h2", "Conventions"),
    ("bullets", [
        "`<you>` is your user name before the @, lower-case, with every character other than a–z and 0–9 replaced by `_`. "
        "Example: `priya.nair@corp.com` → `priya_nair`. Your schema is `course.<you>_support`.",
        "**Run a cell** means Shift+Enter in the notebook. **Run all** means the Run all button at the top.",
        "Notebook names refer to `databricks/labs/<name>` inside the course folder (for example `02_vector_search`).",
        "Lines shown under EXPECTED OUTPUT are what the notebook prints. Numbers marked “about” vary slightly between runs.",
        "UI labels are written as **Menu → Item**. Databricks renames menu items from time to time; if a label differs, "
        "look for the same function nearby.",
    ]),
    ("h2", "What has been verified"),
    ("table", ["Part", "Status"], [
        ["All 17 lab notebooks and 3 agent files", "Statically checked together with `_config`: no undefined names, no syntax errors (`outputs/databricks_static_check.txt`)."],
        ["Data generation, policy copy, section split, chunking, stable ids, benchmark SQL", "Executed on local PySpark: 16/16 checks pass (`outputs/databricks_local_dryrun.txt`)."],
        ["Vector Search, Model Serving, Genie, UC functions, MCP, MLflow judges, AI Functions, Agent Bricks", "**Need a Databricks workspace.** They have not been executed by the author. The instructor dry run in section 2.13 is the step that proves them in **your** workspace; this handbook lists the expected output for every step so you can tell immediately whether it worked. "
         "APIs in this area change quickly; the notebooks guard the most version-sensitive calls and **Appendix B** lists what to change if your workspace differs."],
    ], [0.38, 0.62]),

    # ------------------------------------------------------------------ 1
    ("h1", "1. Overview"),
    ("h2", "1.1 What the labs build"),
    ("p", "One support-agent use case runs through all Databricks labs. Each lab adds one layer to the previous one:"),
    ("table", ["Lab (module)", "Builds", "Key Databricks features"], [
        ["Lab 3 (Module 3)", "Policy documents → Delta chunks → Vector Search index → RAG agent with citations and MLflow traces", "Unity Catalog volumes, Delta + Change Data Feed, Vector Search, Foundation Model APIs, AI Functions, MLflow Tracing, ResponsesAgent"],
        ["Lab 4 (Module 4)", "A Genie space on the sales tables, made accurate with semantics and benchmarks, then used as a tool by the agent", "Genie spaces, comments and keys, metric views, Genie Conversation API"],
        ["Lab 5 (Module 5)", "Governed tools (UC functions), MCP integration, an approval-gated action, least-privilege grants and an access-control matrix", "UC functions (SQL + Python), managed MCP servers, row filters, grants, LangGraph interrupts"],
        ["Lab 6 (Module 6)", "Evaluation dataset and scorecard, one measured optimisation, deployment to Model Serving with endpoint checks", "MLflow GenAI evaluation, judges and custom scorers, Unity Catalog model registry, agents.deploy, Review App"],
        ["Lab 7 (Module 7)", "Production monitoring, rate limits, rollout, a multi-agent supervisor and an Agent Bricks comparison", "Production scorers, system tables, AI Gateway, traffic split, langgraph-supervisor, Agent Bricks Knowledge Assistant"],
    ], [0.17, 0.45, 0.38]),
    ("h2", "1.2 Notebook map"),
    ("table", ["Notebook", "Module / part", "Run by", "Time", "Needs first"], [
        ["`_config`", "all (via %run)", "nobody directly", "—", "instructor edits it once (2.7)"],
        ["`00_instructor_setup`", "setup", "instructor", "30–45 min", "chapter 2 steps 2.1–2.7"],
        ["`00_setup`", "prework", "everyone", "10 min", "instructor Phase 1–2"],
        ["`01_prepare_data`", "Lab 3 A", "participant", "12 min", "`00_setup`"],
        ["`02_vector_search`", "Lab 3 B, Demo 6", "participant", "10 min", "`01_prepare_data`"],
        ["`03_ai_functions`", "Module 3 demo", "instructor (optional for all)", "5 min", "`00_setup`"],
        ["`04_rag_agent` + `agents/rag_agent.py`", "Lab 3 C–D, Demo 7", "participant", "23 min", "`02_vector_search`"],
        ["`05_genie_agent`", "Lab 4 A, C, D, Demo 9", "participant", "35 min", "Genie space created in the UI"],
        ["`06_semantics`", "Lab 4 B, Demo 8", "participant", "15 min", "`05` Part A"],
        ["`07_tools`", "Lab 5 A, Demo 10", "participant", "12 min", "`00_setup`"],
        ["`09_mcp`", "Lab 5 B, Demo 11", "participant", "12 min", "`07_tools`"],
        ["`08_governance` + `agents/support_agent.py`", "Lab 5 C–D, Demo 12", "participant", "24 min", "`07`, `09`, warehouse, analyst secret"],
        ["`10_evaluate`", "Lab 6 A, Demo 13", "participant", "12 min", "`07`, `08` (Part C creates the requests table)"],
        ["`11_optimize`", "Lab 6 B, Demo 14", "participant", "14 min", "`10_evaluate`"],
        ["`12_deploy`", "Lab 6 C–D, Demo 15", "participant", "22 min + 10–20 min provisioning", "`11_optimize`"],
        ["`13_ops`", "Module 7 demo 16", "instructor (participants optional)", "10 min", "`12_deploy`"],
        ["`14_multi_agent`", "Lab 7, Demo 17", "participant", "36 min", "Labs 3–5; Knowledge Assistant for Part D"],
        ["`99_cleanup`", "after course", "participant", "2 min", "capstone graded"],
    ], [0.30, 0.18, 0.17, 0.14, 0.21]),
    ("callout", "note", "Run order inside Lab 5 is **07 → 09 → 08** (MCP before governance), as in the slides."),
    ("h2", "1.3 How labs hand over to each other"),
    ("p", "Labs save a few values in a small settings table so later notebooks find them automatically. "
          "`get_setting(key)` first reads your own `course.<you>_support.course_settings`, then the instructor's "
          "`course.shared.course_settings`."),
    ("table", ["Key", "Written by", "Read by", "Meaning"], [
        ["`active_index`", "`02_vector_search`", "04, 05, 08, 10, 11, 13, 14", "Your index, or the shared checkpoint index if yours was not ready"],
        ["`genie_space_id`", "`05_genie_agent` Part A", "05, 08, 09, 10, 14", "Your own Genie space"],
        ["`shared_genie_space_id`", "instructor (Phase 4)", "fallback when you have no space", "Instructor's Genie space on `course.shared`"],
        ["`baseline_run_id`", "`10_evaluate`", "`11_optimize`", "MLflow run id of the baseline evaluation"],
        ["`candidate_decision`", "`11_optimize`", "you", "SHIP or REVERT"],
        ["`endpoint_name`, `model_version`", "`12_deploy`", "12, 13, 99", "Your deployed agent endpoint"],
        ["`shared_checkpoint_endpoint`", "instructor (Phase 4)", "`12_deploy` Part D", "Used automatically while your endpoint provisions"],
        ["`shared_ka_endpoint`", "instructor (Phase 4)", "`14_multi_agent` Part D (paste into widget)", "Pre-built Knowledge Assistant endpoint"],
    ], [0.24, 0.2, 0.24, 0.32]),
    ("h2", "1.4 What each participant creates"),
    ("table", ["Object", "Name", "Created in"], [
        ["Schema", "`course.<you>_support`", "`00_setup`"],
        ["Volumes", "`raw_policies` (6 policy files), `lab_files` (benchmarks CSV)", "`00_setup`, `05_genie_agent`"],
        ["Tables", "`customers` (300), `products` (20), `orders` (3,008), `order_lines` (~6,000), `tickets` (60), `policy_raw`, `policy_text` (17), `policy_chunks` (17), `course_settings`, `address_change_requests`, `access_matrix`", "00, 01, 07, 08"],
        ["Vector index", "`course.<you>_support.policy_chunks_index`", "`02_vector_search`"],
        ["Metric view", "`order_metrics`", "`06_semantics`"],
        ["Functions", "`get_order_status`, `refund_eligibility`, `store_hours`, `region_filter`", "07, 09, 08"],
        ["Evaluation dataset", "`agent_eval_v1`", "`10_evaluate`"],
        ["Registered model", "`support_agent` (alias `champion`)", "`12_deploy`"],
        ["Serving endpoint", "created by `agents.deploy` (name printed by `12_deploy`)", "`12_deploy`"],
        ["MLflow experiment", "`/Users/<email>/agents-course`", "04 onwards"],
        ["Genie space", "`Sales - <your name>`", "UI, Lab 4"],
    ], [0.18, 0.56, 0.26]),

    # ------------------------------------------------------------------ 2
    ("h1", "2. Instructor setup"),
    ("callout", "who", ["Instructor or workspace admin, at least **2 days** before Module 3 (endpoint and index creation take time).",
                        "You need: workspace admin (or equivalent), **CREATE CATALOG** on the metastore, permission to create "
                        "Vector Search endpoints and serving endpoints, and access to the account console to manage groups."]),
    ("h2", "2.1 Check the workspace has every feature"),
    ("checklist", [
        "**Unity Catalog** is enabled for the workspace (Catalog Explorer shows catalogs other than `hive_metastore`).",
        "**Serverless** notebook compute and **serverless SQL warehouses** are available (recommended for all labs).",
        "**Mosaic AI Vector Search** is available in your region (Compute → Vector Search tab exists).",
        "**Model Serving** with **Foundation Model APIs (pay-per-token)**: Serving page lists `databricks-…` endpoints.",
        "A **tool-calling chat model** endpoint exists (for example a Claude, Llama 3.3 70B or GPT-class endpoint).",
        "The embedding endpoint `databricks-gte-large-en` (or another embedding endpoint) exists.",
        "**AI Functions** work: in the SQL editor `SELECT ai_query('<chat endpoint>', 'Reply with OK')` returns text.",
        "**Genie** (AI/BI) is enabled: **New → Genie space** exists.",
        "**Agent Bricks** is available for Module 7 Part D (if not, use the demo recording; the rest of Lab 7 still works).",
        "**Personal access tokens** are allowed for the workspace (only needed for the test-analyst identity in Lab 5).",
        "**System tables** `system.serving.*` are enabled (Module 7 cost queries; a metastore admin enables system schemas).",
    ]),
    ("callout", "fail", "If a feature is missing, contact your Databricks account team or workspace admin before going further. "
                        "Region availability differs; Vector Search, Genie and Agent Bricks are the most common gaps."),
    ("h2", "2.2 Groups and the test analyst user"),
    ("steps", [
        "Open the **account console** → **User management** → **Groups** → **Add group**. Create `agents-course-participants`.",
        "Create a second group `agents-course-analysts`.",
        "Add every participant (and yourself) to `agents-course-participants`.",
        "Create or pick one **test analyst** user. Add it **only** to `agents-course-analysts` (not to participants). "
        "Lab 5 uses it to prove that permissions work.",
        "In the workspace: **Settings → Identity and access → Groups**: make sure both groups are assigned to this workspace "
        "with **Workspace access** and **Databricks SQL access** entitlements.",
    ]),
    ("callout", "note", "Different group names are fine: put your names in `COURSE_GROUP` and `ANALYST_GROUP` in `_config` (2.7)."),
    ("h2", "2.3 SQL warehouse"),
    ("steps", [
        "**SQL Warehouses → Create SQL warehouse**. Name: `agents-course-wh`. Type: **Serverless**. Size: **Small**. "
        "Auto stop: 10 minutes. Scaling: max 1 cluster per ~10 participants (for 30 people: max 3).",
        "Open the warehouse → **Connection details**, or copy the id from the URL `/sql/warehouses/<id>`. "
        "This is `WAREHOUSE_ID` (a 16-character hex string like `4b9b953939869799`).",
        "Permissions are granted automatically by `00_instructor_setup` Phase 1 (CAN USE for both groups).",
    ]),
    ("h2", "2.4 The analyst token (secret)"),
    ("p", "Lab 5 calls Databricks as the test analyst to prove the grants. The analyst's token is stored in a secret scope; "
          "participants can read it from notebooks, but never see or paste it."),
    ("steps", [
        "Sign in as the **test analyst** → **Settings → Developer → Access tokens → Generate new token**. Comment: `agents-course`. "
        "Lifetime: 30 days. Copy the token.",
        "On your own laptop install the Databricks CLI (one time), then log in:",
    ]),
    ("code", "winget install Databricks.DatabricksCLI          # Windows (or: brew install databricks/tap/databricks on macOS)\n"
             "databricks auth login --host https://<your-workspace-url>\n"
             "databricks secrets create-scope course           # skip if 00_instructor_setup Phase 1 already created it\n"
             "databricks secrets put-secret course analyst_pat # paste the analyst token when prompted\n"
             "databricks secrets list-secrets course           # shows: analyst_pat", "Terminal"),
    ("callout", "check", "`databricks secrets list-secrets course` lists `analyst_pat`. Phase 1 of `00_instructor_setup` grants READ on the scope to the participant group."),
    ("h2", "2.5 Choose the model endpoints"),
    ("steps", [
        "Open **Serving**. Filter on **Foundation models** (pay-per-token).",
        "Pick a **tool-calling chat model** for `LLM_ENDPOINT` (strongest available; used by the agent and the supervisor).",
        "Pick a **smaller chat model** for `LLM_SMALL_ENDPOINT` (cheaper; used by Lab 7 workers and optimisation). "
        "It must also support tool calling.",
        "Note the **embedding** endpoint for `EMBEDDING_ENDPOINT` (default `databricks-gte-large-en`).",
        "Test the chat model in **Playground**: choose it, add any UC function as a tool if offered, ask a question. "
        "If tool calling fails in the Playground, choose another model.",
    ]),
    ("callout", "warn", "Endpoint names are workspace- and region-specific. The defaults in `_config` are examples. "
                        "Use exactly the names on your Serving page."),
    ("h2", "2.6 Put the course files in the workspace"),
    ("p", "Each participant needs **their own copy** of the course folder: notebooks write `agents/agent_config.yaml` "
          "next to the agent code, so a single shared copy would make participants overwrite each other. "
          "Use the clean copy without virtual environments (for example `D:\\GYANESH\\Updated_raw\\Agents_on_Databricks_Labs`)."),
    ("h3", "Option A (recommended): Git folder per participant"),
    ("steps", [
        "Push the course folder to a Git repository (GitHub, Azure DevOps, GitLab or Bitbucket). Do not include `.venv`, `and` or `outputs` folders.",
        "Each participant: **Workspace → Home → Create → Git folder**. Paste the repository URL. Git provider: as appropriate. "
        "Folder name: `Agents_on_Databricks_Labs`. Click **Create Git folder**.",
        "If the repository is private, each participant first adds Git credentials under **Settings → Linked accounts**.",
    ]),
    ("h3", "Option B: import once, then each participant clones the folder"),
    ("code", "databricks workspace import-dir \"D:\\GYANESH\\Updated_raw\\Agents_on_Databricks_Labs\" "
             "/Workspace/Shared/Agents_on_Databricks_Labs", "Terminal (instructor)"),
    ("steps", [
        "Run the command above (it imports notebooks as notebooks and other files, such as `agents/*.py` and `data/*`, as workspace files).",
        "Each participant: **Workspace → Shared → Agents_on_Databricks_Labs → three-dot menu → Clone**, destination: their **Home** folder.",
        "If your workspace does not offer Clone for folders, each participant runs the same `import-dir` command with their own "
        "destination `/Workspace/Users/<email>/Agents_on_Databricks_Labs`.",
    ]),
    ("callout", "check", ["The folder in the workspace looks like this (only the parts the Databricks labs use):",
                          "$ Agents_on_Databricks_Labs/\n  data/orders.json, data/policies/*.md (6 files)\n"
                          "  databricks/labs/   _config, 00_instructor_setup, 00_setup, 01_ ... 14_, 99_cleanup  (notebooks)\n"
                          "  databricks/labs/agents/   genie_tool.py, rag_agent.py, support_agent.py  (files, not notebooks)\n"
                          "  databricks/labs/lab_assets/   genie_instructions.md, benchmarks_template.csv",
                          "`agents/*.py` must be **files** (plain Python icon), not notebooks. `00_setup` reads `data/policies` two levels above the notebook folder."]),
    ("h2", "2.7 Edit `_config` (once, before participants copy the folder)"),
    ("p", "Open `databricks/labs/_config` and edit **only the first block** (instructor settings). If you distribute via Git, "
          "commit the change so every copy has it. Edit `databricks/solutions/_config` the same way if you demo from solutions."),
    ("table", ["Variable", "Set to", "Where to find it"], [
        ["`CATALOG`", "`course`", "Keep, unless your naming policy requires another catalog name"],
        ["`SHARED_SCHEMA`", "`shared`", "Keep"],
        ["`VS_ENDPOINT`", "`agents-course-vs`", "Keep; Phase 2 creates it"],
        ["`LLM_ENDPOINT`", "your tool-calling chat endpoint", "Serving page (2.5)"],
        ["`LLM_SMALL_ENDPOINT`", "your smaller chat endpoint", "Serving page (2.5)"],
        ["`EMBEDDING_ENDPOINT`", "`databricks-gte-large-en`", "Serving page"],
        ["`WAREHOUSE_ID`", "e.g. `4b9b953939869799`", "Warehouse → Connection details (2.3)"],
        ["`COURSE_GROUP`", "`agents-course-participants`", "Group name (2.2)"],
        ["`ANALYST_GROUP`", "`agents-course-analysts`", "Group name (2.2)"],
    ], [0.24, 0.33, 0.43]),
    ("callout", "warn", "Do not edit anything below the line `derived per-participant names (do not edit)`. Those names are computed per user."),
    ("h2", "2.8 Compute"),
    ("bullets", [
        "**Recommended:** serverless notebook compute. Attach each notebook to **Serverless** in the compute selector.",
        "**Alternative:** a classic cluster with the latest **LTS** Databricks Runtime (16.x LTS or newer), access mode "
        "**Dedicated** (single user) or **Standard**, Unity Catalog enabled. Python and pandas UDFs are used in Lab 3.",
        "Every lab notebook starts with `%pip install …` followed by `dbutils.library.restartPython()`. Always run those two cells first. "
        "Python variables are lost at the restart; that is expected.",
    ]),
    ("h2", "2.9 Run `00_instructor_setup`, Phase 1 and Phase 2"),
    ("steps", [
        "Open `databricks/labs/00_instructor_setup` in **your own** copy, attach serverless compute.",
        "Run the `%pip` cell and the restart cell, then the `%run ./_config` cell.",
        "Run **Phase 1** (two cells).",
        "Run **Phase 2** (Vector Search endpoint). It waits until the endpoint is ONLINE: 5–15 minutes.",
        "In the UI: **Compute → Vector Search → agents-course-vs → Permissions**: add `agents-course-participants` with **Can Use** "
        "(or **Can Manage** if participants get permission errors creating indexes).",
    ]),
    ("callout", "expect", ["$ user=<your email>\nschema=course.<you>_support\nindex=course.<you>_support.policy_chunks_index\nllm=<LLM_ENDPOINT>\nexperiment=/Users/<email>/agents-course",
                           "$ Phase 1 done: catalog, shared schema, shared settings table and grants ready\nCAN USE on warehouse <id> granted\nsecret scope 'course' created          (or: ... already exists)\nREAD on secret scope 'course' granted to agents-course-participants",
                           "$ {'state': 'ONLINE', ...}"]),
    ("callout", "fail", ["`CREATE CATALOG` fails with a storage-root error: create it with a managed location, e.g. "
                         "`CREATE CATALOG course MANAGED LOCATION 'abfss://<container>@<account>.dfs.core.windows.net/course'`, then re-run Phase 1.",
                         "`PERMISSION_DENIED` on CREATE CATALOG: ask a metastore admin to grant you CREATE CATALOG, or to create the catalog and make you its owner.",
                         "Group not found in GRANT: the group name in `_config` must match exactly (case-sensitive) and the group must be assigned to the workspace.",
                         "`WAREHOUSE_ID is empty`: set it in `_config` (2.7), re-run the `%run ./_config` cell, then Phase 1 cell 2."]),
    ("h2", "2.10 Run `00_setup` and `01_prepare_data` yourself, then Phase 3"),
    ("steps", [
        "Run `00_setup` exactly as a participant would (chapter 3). It must end with **ALL CHECKS PASSED** (the shared settings checks do not exist there).",
        "Run `01_prepare_data` (section 4.1). It must print **Checkpoint A passed**.",
        "Back in `00_instructor_setup`, run **Phase 3**. It deep-clones your tables into `course.shared` and creates the "
        "checkpoint index `course.shared.policy_chunks_index`.",
    ]),
    ("callout", "expect", "$ checkpoint index creating (ready in a few minutes)"),
    ("callout", "check", "**Compute → Vector Search → agents-course-vs** lists `course.shared.policy_chunks_index`; after a few minutes its status is **Online / Ready**."),
    ("h2", "2.11 Shared assets for later modules"),
    ("h3", "A. Shared Genie space (before Module 4)"),
    ("steps", [
        "**New → Genie space**. Title `Sales - shared`. Warehouse: `agents-course-wh`.",
        "Add tables `course.shared.orders`, `customers`, `products`, `order_lines`.",
        "Paste the general instructions from `databricks/labs/lab_assets/genie_instructions.md` (the block under *General instructions*).",
        "**Share** → add `agents-course-participants` and `agents-course-analysts` with **Can Run**.",
        "Copy the space id from the URL `…/genie/rooms/<space_id>`.",
    ]),
    ("h3", "B. Checkpoint agent endpoint (before Module 6)"),
    ("steps", [
        "As yourself, run Labs 3–6 once (`02`, `04`, `05`, `06`, `07`, `09`, `08`, `10`, `11`, `12`). This is also your dry run (2.13).",
        "`12_deploy` prints your endpoint name. When the endpoint is **Ready**: **Serving → endpoint → Permissions** → add "
        "`agents-course-participants` with **Can Query**.",
    ]),
    ("h3", "C. Knowledge Assistant (before Module 7)"),
    ("steps", [
        "**Agents → Agent Bricks → Knowledge Assistant → Build** (menu names can vary). Name: `support-policies`.",
        "Description: *Answers customer-support policy questions with citations.* Knowledge source: the volume "
        "`/Volumes/course/shared/…` or your own `raw_policies` volume.",
        "Wait for the build (can take a while). Then on its endpoint: **Permissions** → participants **Can Query**. Copy the endpoint name.",
    ]),
    ("h3", "D. Save the shared settings (Phase 4)"),
    ("steps", [
        "In `00_instructor_setup` run the Phase 4 cell once to create the widgets at the top of the notebook.",
        "Fill `shared_genie_space_id`, `shared_checkpoint_endpoint`, `shared_ka_endpoint` (any you have so far) and run the cell again.",
    ]),
    ("callout", "expect", "A table with the keys you filled, e.g. `shared_genie_space_id | 01f0a1b2c3...`"),
    ("h2", "2.12 Phase 5: automated readiness check"),
    ("p", "Run the Phase 5 cell. Re-run it until it prints **INSTRUCTOR SETUP COMPLETE**. `setting shared_ka_endpoint` may stay "
          "FAILED until Module 7 without blocking."),
    ("callout", "expect", "$ catalog + shared schema           OK (...)\nchat endpoint                      OK (<LLM_ENDPOINT>)\nsmall chat endpoint                OK (...)\nembedding endpoint                 OK (databricks-gte-large-en)\nvector search endpoint ONLINE      OK\ncheckpoint index ready             OK\nsql warehouse                      OK (agents-course-wh)\nparticipant group exists           OK\nanalyst group exists               OK\nsecret course/analyst_pat          OK\nai_query works                     OK (OK)\nsetting shared_genie_space_id      OK (01f0...)\nsetting shared_checkpoint_endpoint OK (...)\nsetting shared_ka_endpoint         OK (...)\n\nINSTRUCTOR SETUP COMPLETE"),
    ("h2", "2.13 Dry run (the step that proves everything works)"),
    ("p", "Two days before Module 3, run every lab notebook as yourself, in the order of section 1.2, and tick each "
          "CHECK box in chapters 3–8. Then pin package versions:"),
    ("steps", [
        "After `12_deploy` succeeds, copy the list it prints under `PINNED` (for example `mlflow==3.x.y`).",
        "Replace `>=3.1` and the unpinned names in each notebook's `%pip` cell with those exact versions, so every participant gets "
        "the versions you tested. Commit or re-distribute the folder.",
        "Record any change you had to make (Appendix B lists the likely ones).",
    ]),
    ("h2", "2.14 Capacity for a class"),
    ("table", ["Resource", "Per participant", "Plan for 30 participants"], [
        ["Vector Search indexes", "1", "One standard endpoint usually hosts many small indexes; check your endpoint's index limit and create a second endpoint if needed"],
        ["Serving endpoints (Lab 6)", "1", "Check the workspace endpoint quota; if it is low, deploy in pairs and share `endpoint_name`"],
        ["Pay-per-token calls", "~300–600 per module", "Rate limits can return 429 when 30 people evaluate at once: stagger Lab 6 Part A, or reduce cases"],
        ["SQL warehouse", "shared", "Max 3 clusters; Genie and governance tests queue otherwise"],
        ["Genie spaces", "1", "No special quota"],
    ], [0.24, 0.18, 0.58]),

    # ------------------------------------------------------------------ 3
    ("h1", "3. Participant setup: `00_setup`"),
    ("callout", "who", "Every participant, as prework before Module 3 (about 10 minutes). The instructor runs it too (2.10)."),
    ("h2", "3.1 Before you start"),
    ("checklist", [
        "You can log in to the workspace and you are in the group `agents-course-participants`.",
        "You have **your own** copy of the course folder in your Home folder (2.6).",
        "The instructor has completed Phase 1 and Phase 2 of `00_instructor_setup`.",
    ]),
    ("h2", "3.2 Steps"),
    ("steps", [
        "Open `Agents_on_Databricks_Labs/databricks/labs/00_setup`. In the compute selector choose **Serverless** (or the course cluster).",
        "Run the `%pip install` cell, then the `dbutils.library.restartPython()` cell.",
        "Run the `%run ./_config` cell. Note your schema name in the output.",
        "Run the schema cell: creates `course.<you>_support` and the volume `raw_policies`.",
        "Run the **Course data** cell: generates and saves the 5 tables (about 30–60 seconds).",
        "Run the **Policy documents** cell: copies the 6 policy files from the course folder into your volume.",
        "Run the **Readiness checks** cell.",
    ]),
    ("callout", "expect", ["$ user=priya.nair@corp.com\nschema=course.priya_nair_support\n...",
                           "$ schema course.priya_nair_support and volume /Volumes/course/priya_nair_support/raw_policies ready",
                           "$ course.priya_nair_support.customers: 300 rows\ncourse.priya_nair_support.products: 20 rows\ncourse.priya_nair_support.orders: 3008 rows\ncourse.priya_nair_support.order_lines: about 6000 rows\ncourse.priya_nair_support.tickets: 60 rows",
                           "A file listing with 6 files: address_changes.md, refunds.md, refunds_2024.md, returns_IN.md, returns_US.md, shipping.md",
                           "$ schema write             OK\nchat endpoint            OK\nsmall chat endpoint      OK\nembedding endpoint       OK\nvector search endpoint   OK\nsql warehouse            OK\nai_query                 OK\n\nALL CHECKS PASSED"]),
    ("callout", "fail", ["`run this notebook from the course Git folder`: the notebook cannot find `data/policies`. Your copy is missing the "
                         "`data` folder or the notebook is not at `databricks/labs/`. Re-copy the whole folder (2.6).",
                         "`PERMISSION_DENIED … CREATE SCHEMA`: you are not in the participant group, or Phase 1 was not run. Tell the instructor.",
                         "`chat endpoint FAILED … does not exist`: `_config` still has an example name. The instructor fixes `LLM_ENDPOINT` (2.7).",
                         "`sql warehouse FAILED: WAREHOUSE_ID not set`: instructor sets `WAREHOUSE_ID` in `_config`.",
                         "`vector search endpoint FAILED`: Phase 2 not finished yet, or no Can Use permission on the endpoint (2.9 step 5).",
                         "`ai_query FAILED`: AI Functions not enabled, or the model endpoint name is wrong.",
                         "Any error after the restart cell such as `NameError: FQ`: you skipped the `%run ./_config` cell. Run it again."]),
    ("callout", "done", "The last line is **ALL CHECKS PASSED**. Post it in the course chat; post the full output if any check FAILED."),
]
