"""Chapters 4-5: Lab 3 (Module 3) and Lab 4 (Module 4)."""

LAB_START = ("callout", "note", ["Every notebook: attach **Serverless** compute → run the `%pip` cell → run the restart cell → "
                                 "run `%run ./_config` → then the lab cells in order. Never skip the `%run ./_config` cell after a restart."])

BLOCKS = [
    # ------------------------------------------------------------------ 4
    ("h1", "4. Lab 3 (Module 3): data grounding and a traced RAG agent"),
    ("p", "Goal: a RAG agent in your schema that retrieves from your own Vector Search index, answers with citations, "
          "declines out-of-scope questions, and produces MLflow traces. 45 minutes in class."),
    ("checklist", ["`00_setup` printed ALL CHECKS PASSED.", "The checkpoint index `course.shared.policy_chunks_index` is Ready (instructor, 2.10)."]),
    LAB_START,

    ("h2", "4.1 Part A: prepare documents (`01_prepare_data`, 12 min)"),
    ("steps", [
        "Run the `%pip install langchain-text-splitters` cell, the restart cell and `%run ./_config`.",
        "**Bronze** cell: reads the 6 files in your volume into `policy_raw` and displays them (columns `file`, `raw`).",
        "Skip the optional `ai_parse_document` markdown cell (it is for PDFs).",
        "**Silver** cell: parses each file's front matter (doc_type, policy_id, region, effective_date, superseded) and splits on "
        "`## ` headings into `policy_text`. Displays 17 rows.",
        "**Gold** cell: chunks each section, prefixes it with its heading, computes `chunk_id` = SHA-256 of source|section|text, "
        "writes `policy_chunks` and turns on **Change Data Feed**.",
        "**Checkpoint A** cell: shows chunk statistics and checks CDF and id uniqueness.",
    ]),
    ("callout", "expect", ["Silver: 17 rows, one per section. The two `refunds_2024.md` rows have `superseded = true`.",
                           "$ chunks  avg_tokens  max_tokens  superseded_chunks\n    17          37         105                  2",
                           "$ Checkpoint A passed: chunks ready, ids unique, CDF on"]),
    ("callout", "fail", ["`read_files` finds no files: `00_setup` policy cell was not run, or the volume path differs. Run `display(dbutils.fs.ls(VOLUME_PATH))`.",
                         "`ModuleNotFoundError: langchain_text_splitters`: run the `%pip` cell and the restart cell again.",
                         "`CDF is not enabled`: run `ALTER TABLE course.<you>_support.policy_chunks SET TBLPROPERTIES (delta.enableChangeDataFeed = true)` and re-run Checkpoint A.",
                         "`chunk_id must be unique`: you edited the chunking; the id must include source, section and text."]),
    ("callout", "done", "**Checkpoint A passed** printed."),

    ("h2", "4.2 Part B: Vector Search index, filters, recall (`02_vector_search`, 10 min, Demo 6)"),
    ("steps", [
        "Run `%pip`, restart, `%run ./_config`.",
        "**Create index** cell: creates `course.<you>_support.policy_chunks_index` (Delta Sync, managed embeddings, TRIGGERED). "
        "If it already exists, it triggers a sync instead.",
        "**Wait** cell: polls up to 6 minutes. If your index is not ready, the rest of the notebook uses the shared checkpoint "
        "index; you lose nothing.",
        "**Query** cell: three searches. Compare *no filter*, *India + global, current only* and *ANN vs HYBRID* for `policy RP-204`.",
        "Lab task: write three filtered queries of your own in a new cell (copy the pattern).",
        "**Recall** cell: recall@k on 20 labelled questions with four settings.",
        "**SQL** cell: the same index from SQL with `vector_search()`.",
        "**Last** cell: saves the index you used as `active_index` for later labs.",
    ]),
    ("callout", "expect", ["$ index creating\nusing course.<you>_support.policy_chunks_index      (or course.shared.policy_chunks_index)",
                           "$ — no filter\n0.0xx  refunds.md > Late deliveries  [GLOBAL]\n...",
                           "$ recall@4 baseline            : 8x%\nrecall@4 current-only filter : 8x–9x%\nrecall@4 filter + HYBRID     : 9x%\nrecall@2 filter + HYBRID     : 8x%",
                           "Exact percentages vary by embedding model. The filtered and HYBRID rows should be equal or higher than the baseline.",
                           "$ Checkpoint B: index ... ready; recall measured. Saved as your active index for later labs."]),
    ("callout", "fail", ["`create_delta_sync_index` PERMISSION_DENIED: you need Can Use/Can Manage on the endpoint (instructor, 2.9 step 5).",
                         "Index stays PROVISIONING > 6 min: continue; the notebook switches to the shared index automatically.",
                         "`Table does not have change data feed enabled`: fix as in 4.1, then delete and recreate the index.",
                         "Filter error (`filters` not supported / invalid): the filter syntax differs by endpoint type. Remove the filter in that query and continue.",
                         "SQL cell prints `vector_search with query_text => failed` then succeeds with `query`: that is expected on some runtimes."]),
    ("callout", "done", "Checkpoint B line printed. `get_setting('active_index')` now returns your index (or the shared one)."),

    ("h2", "4.3 Demo: AI Functions (`03_ai_functions`, 5 min, instructor)"),
    ("steps", [
        "Run `%run ./_config` (no `%pip` needed).",
        "`ai_classify` over 20 tickets, then its accuracy against `true_intent` (expect roughly 0.7–0.95).",
        "`ai_query` summaries for recent tickets, then `ai_query` with `responseFormat` for structured extraction.",
    ]),
    ("callout", "fail", "`ai_query ... endpoint not found`: `LLM_ENDPOINT` is wrong in `_config`. `responseFormat` unsupported: skip that cell; it needs a recent runtime."),

    ("h2", "4.4 Parts C–D: author and trace the RAG agent (`04_rag_agent`, 23 min, Demo 7)"),
    ("p", "The agent code is in `databricks/labs/agents/rag_agent.py` (a plain Python file). The notebook writes "
          "`agents/agent_config.yaml`, imports the agent and runs it."),
    ("steps", [
        "Run `%pip` (mlflow, databricks-langchain, databricks-vectorsearch, langgraph), restart, `%run ./_config`.",
        "**Config** cell: writes `agent_config.yaml` with your endpoint, active index and `num_results: 4`, and sets the MLflow experiment.",
        "**Load and ask** cell: imports `rag_agent`, runs 5 questions inside the MLflow run `rag-v1`.",
        "Open the **Traces** tab of the experiment (or the trace widget under the cell). For each answer: open the "
        "`search_policies` RETRIEVER span, check each [source > section] citation matches a returned document, note latency and tokens.",
        "**Trace list** cell: prints one line per trace with the retrieved sources.",
        "**Part D**: the solution cell changes `num_results` to 2 and re-runs under `rag-v1-k2`. Compare the two runs' traces. "
        "Try your own single change instead (a filter, the tool description, k).",
    ]),
    ("callout", "expect", ["$ {'llm_endpoint': '...', 'vs_index': 'course.<you>_support.policy_chunks_index', 'num_results': 4}",
                           "$ Q: Can I get a refund on a late order?\nA: Orders delivered more than 2 days late are eligible ... gold 100%, silver 50%, standard 25% ...\n   [refunds.md > Late deliveries]",
                           "$ Q: What is the capital of Australia?\nA: I could not find a policy that answers this question.   (or a polite decline)",
                           "$ tr-1a2b...  2400 ms  retrieved=['refunds.md', 'shipping.md', ...]"]),
    ("callout", "fail", ["`ModelConfig ... agent_config.yaml not found`: the config cell did not run, or a later restart reset the working directory. Re-run from the config cell.",
                         "`ImportError` for `databricks_langchain`: re-run the `%pip` and restart cells.",
                         "Answers without citations: the model ignored the instruction. Re-run once; if persistent use a stronger `LLM_ENDPOINT`.",
                         "`429 Too Many Requests`: the pay-per-token endpoint is rate limited. Wait 30 seconds and re-run.",
                         "No traces in the experiment: check `EXPERIMENT` path in the `_config` output and refresh the Traces tab.",
                         "`AttributeError` around `create_text_output_item` or `ResponsesAgent`: MLflow version mismatch. Install the version pinned by the instructor (2.13)."]),
    ("callout", "done", "Five answers printed; policy answers carry citations; the off-topic question is declined; traces show RETRIEVER spans."),

    # ------------------------------------------------------------------ 5
    ("h1", "5. Lab 4 (Module 4): Genie"),
    ("p", "Goal: a Genie space that scores at least 85% on 20 benchmarks, declines out-of-scope questions, and is used by your agent. 50 minutes."),
    ("table", ["Part", "Where", "Time"], [
        ["A. Create the space, ask 5 questions, save its id", "Genie UI + `05_genie_agent` (first part)", "10 min"],
        ["B. Semantics: comments, keys, metric view", "`06_semantics` + Genie UI", "15 min"],
        ["C. Benchmarks", "`05_genie_agent` (render cell) + Genie UI", "15 min"],
        ["D. Genie as a tool in your agent", "`05_genie_agent` (Part D)", "10 min"],
    ], [0.5, 0.35, 0.15]),
    ("checklist", ["Lab 3 done (`active_index` saved).", "You have CAN USE on the course warehouse (instructor Phase 1)."]),

    ("h2", "5.1 Part A: create your Genie space (UI)"),
    ("steps", [
        "**New → Genie space**.",
        "Title: `Sales - <your name>`. Warehouse: `agents-course-wh`.",
        "**Add data** → `course` → `<you>_support` → tick `orders`, `customers`, `products`, `order_lines` → **Create**.",
        "Ask the five sample questions from `lab_assets/genie_instructions.md` (Part A list). For each answer click **Show code** and note what is wrong "
        "(typical: cancelled orders included in revenue, calendar instead of fiscal quarter). Question 5 (employee attrition) should be declined.",
        "Copy the space id from the browser URL: `…/genie/rooms/<space_id>` (a long hex string).",
        "Open `05_genie_agent`. Run `%pip`, restart, `%run ./_config`.",
        "Run the widget cell once: a widget **Genie space id** appears at the top. Paste your id into it and run the cell again.",
        "Run the **Conversation API** cells: Genie answers the late-orders question from code, then a follow-up keeps context.",
    ]),
    ("callout", "expect", ["$ saved genie_space_id=01f0...",
                           "$ Genie SQL (...):\nSELECT COUNT(*) ... FROM course.<you>_support.orders WHERE region = 'North' ...\n\ncount(1)\n<number>",
                           "Follow-up prints SQL filtered to `region = 'North'`."]),
    ("callout", "fail", ["`paste your Genie space id`: the widget is empty. Paste the id and re-run.",
                         "`PERMISSION_DENIED` from Genie: you lack CAN USE on the warehouse or SELECT on your tables (you own them, so usually the warehouse).",
                         "`AttributeError: get_message_attachment_query_result`: older SDK; the code falls back automatically. If both fail, upgrade `databricks-sdk`.",
                         "Genie is slow on the first question: the warehouse is starting (about 1 minute)."]),

    ("h2", "5.2 Part B: semantics (`06_semantics`, Demo 8)"),
    ("steps", [
        "Open `06_semantics`, run `%run ./_config` (no `%pip`).",
        "**Comments** cell: business-language comments on tables and columns (units, allowed statuses, the definition of late).",
        "**Keys** cell: primary keys on customers, products, orders; foreign keys orders→customers, order_lines→orders/products.",
        "**Metric view** cell: creates `order_metrics` (Revenue, Orders, Average Order Value, Late Orders, Late Rate; filter excludes cancelled).",
        "**Query** cell: revenue and late rate by region for the last 90 days.",
        "In the Genie UI: **Configure → Data** add `order_metrics`. **Instructions → General** paste the block from `genie_instructions.md`.",
        "Ask the same five questions. Compare the SQL with Part A: revenue now uses `MEASURE(Revenue)`; quarters are fiscal.",
    ]),
    ("callout", "expect", ["$ keys added", "A table of 4 regions with revenue and late_rate; **North has the highest late rate** (about 0.45 vs about 0.25–0.30 elsewhere)."]),
    ("callout", "fail", ["Key cell prints `orders_pk: ... already exists`: harmless when re-running.",
                         "Metric view error mentioning `version`: the YAML spec version differs in your workspace. Change `version: 0.1` to the version in the current docs and re-run.",
                         "`WITH METRICS` not recognised: metric views need a recent runtime or serverless. Switch compute to Serverless.",
                         "Genie still ignores the metric view: make sure it was **added to the space** (Data tab), not only created."]),

    ("h2", "5.3 Part C: benchmarks"),
    ("steps", [
        "In `05_genie_agent` run the **benchmarks** cell: it renders 20 questions with your table names, saves "
        "`/Volumes/course/<you>_support/lab_files/genie_benchmarks.csv` and displays them.",
        "In the Genie space: **Benchmarks → Add benchmark**. For each row paste the question and the expected SQL (or import the CSV if your UI offers import). "
        "For the 3 out-of-scope rows, add the question with no SQL answer.",
        "**Run all benchmarks**. Open each failure, read the generated SQL, fix with **one** example SQL query or instruction at a time "
        "(the example in `genie_instructions.md` fixes late-orders questions), then re-run all.",
    ]),
    ("callout", "check", "Score at least 85%; the three out-of-scope questions (attrition, marketing budget, salaries) are declined."),
    ("callout", "note", "Typical scores: about 60% before semantics, about 80% with comments and the metric view, 90%+ with 3–5 example queries."),

    ("h2", "5.4 Part D: Genie as a tool in your agent (Demo 9)"),
    ("steps", [
        "In `05_genie_agent` run the **Part D** cell: an agent with `search_policies` (Vector Search) and `sales_analyst` (your Genie space).",
        "It asks an analytics question, then a policy question.",
        "Open the newest traces: the `sales_analyst` span contains the Genie SQL; the second question calls `search_policies`.",
    ]),
    ("callout", "expect", "$ Q: How many orders were late last week in the North region?\nTools: ['sales_analyst']\nA: <a number> orders ...\n\nQ: And what does our policy say we owe customers whose orders are late?\nTools: ['search_policies']\nA: ... more than 2 days late ... [refunds.md > Late deliveries]"),
    ("callout", "fail", ["Wrong routing (Genie used for the policy question): improve one tool description and re-run.",
                         "`TOOL_ERROR: Genie unavailable`: warehouse stopped or space id wrong. Run the Conversation API cell to test the space directly."]),
    ("callout", "done", "Benchmarks ≥ 85%, and a trace that shows `sales_analyst` for analytics and `search_policies` for policy."),
]
