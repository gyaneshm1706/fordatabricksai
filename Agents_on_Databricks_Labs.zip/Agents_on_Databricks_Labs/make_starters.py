"""Generate participant files from the solution files.

Solution files mark lab work like this:

    # >>> SOLUTION: hint shown to participants
    ...reference code...
    # >>> STARTER            (optional)
    # ...starter code, commented out in the solution...
    # <<< SOLUTION

  python make_starters.py --fill   # completed lab files: reference code kept, markers removed (default)
  python make_starters.py --todo   # exercise versions: reference code replaced by '# TODO: hint'
  python make_starters.py --check  # fail if the lab files differ from what --fill would produce
  add --force to overwrite lab files you have completed yourself (they are protected otherwise)

A lab file is "yours" (protected) when its solution has SOLUTION blocks but the lab file has no TODO left
and differs from the reference, e.g. module01/*.py that you filled in by hand.
"""
import hashlib
import json
import pathlib
import re
import shutil
import sys

ROOT = pathlib.Path(__file__).resolve().parent
PAIRS = [  # (solution dir, lab dir)
    (ROOT / "module01" / "solution", ROOT / "module01"),
    (ROOT / "module02" / "solution", ROOT / "module02"),
    (ROOT / "databricks" / "solutions", ROOT / "databricks" / "labs"),
]
START = re.compile(r"^(\s*)# >>> SOLUTION:?\s*(.*)$")
STARTER = re.compile(r"^\s*# >>> STARTER\s*$")
END = re.compile(r"^\s*# <<< SOLUTION\s*$")


def strip(text: str) -> str:
    """Exercise version: TODO + starter code instead of the reference code."""
    out, mode, indent, hint, starter = [], "copy", "", "", []
    for line in text.splitlines():
        if mode == "copy":
            m = START.match(line)
            if m:
                mode, indent, hint, starter = "solution", m.group(1), m.group(2) or "complete this step", []
            else:
                out.append(line)
        elif mode in ("solution", "starter"):
            if STARTER.match(line):
                mode = "starter"
            elif END.match(line):
                out.append(f"{indent}# TODO: {hint}")
                if mode == "starter":
                    out.extend(indent + re.sub(r"^# ?", "", s.strip()) if s.strip() else "" for s in starter)
                elif indent:
                    out.append(f"{indent}raise NotImplementedError({('TODO: ' + hint)!r})")
                mode = "copy"
            elif mode == "starter":
                starter.append(line)
    if mode != "copy":
        raise ValueError("unterminated SOLUTION block")
    return "\n".join(out) + "\n"


def fill(text: str) -> str:
    """Completed version: keep the reference code, drop markers and commented-out starter code."""
    out, mode = [], "copy"
    for line in text.splitlines():
        m = START.match(line)
        if mode == "copy" and m:
            mode = "solution"
            if m.group(2):
                out.append(f"{m.group(1)}# {m.group(2)[0].upper()}{m.group(2)[1:]}")   # keep the hint as a comment
        elif mode != "copy" and STARTER.match(line):
            mode = "starter"
        elif mode != "copy" and END.match(line):
            mode = "copy"
        elif mode != "starter":
            out.append(line)
    if mode != "copy":
        raise ValueError("unterminated SOLUTION block")
    return "\n".join(out) + "\n"


MANIFEST = ROOT / ".lab_manifest.json"     # fingerprints of the files this script wrote


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _manifest() -> dict:
    return json.loads(MANIFEST.read_text(encoding="utf-8")) if MANIFEST.exists() else {}


def is_users_own(src_text: str, target: pathlib.Path) -> bool:
    """True for a lab file someone edited by hand after this script wrote it (never overwrite it silently)."""
    if "# >>> SOLUTION" not in src_text or not target.exists():
        return False
    current = target.read_text(encoding="utf-8")
    written = _manifest().get(target.relative_to(ROOT).as_posix())
    if written is not None:                        # we wrote it: it's yours only if it changed since
        return _sha(current) != written
    return "TODO:" not in current and current != fill(src_text)   # no record: completed by hand


def build(mode: str = "fill", force: bool = False) -> int:
    stale, kept = 0, []
    manifest = _manifest()
    transform = strip if mode == "todo" else fill
    for src, dst in PAIRS:
        if not src.exists():
            continue
        for f in src.rglob("*"):
            if f.is_dir() or "__pycache__" in f.parts:
                continue
            target = dst / f.relative_to(src)
            target.parent.mkdir(parents=True, exist_ok=True)
            if f.suffix != ".py":
                if mode != "check":
                    shutil.copy2(f, target)
                continue
            src_text = f.read_text(encoding="utf-8")
            content = transform(src_text) if mode != "check" else fill(src_text)
            if not force and is_users_own(src_text, target):
                kept.append(str(target.relative_to(ROOT)))
            elif mode == "check":
                stale += (not target.exists()) or target.read_text(encoding="utf-8") != content
            else:
                target.write_text(content, encoding="utf-8")
                manifest[target.relative_to(ROOT).as_posix()] = _sha(content)
    if mode != "check":
        MANIFEST.write_text(json.dumps(manifest, indent=1, sort_keys=True), encoding="utf-8")
    if mode == "check":
        print("lab files match the reference" if not stale else f"{stale} lab files differ from the reference")
    else:
        print(f"lab files written ({'exercise TODO' if mode == 'todo' else 'completed'} versions)")
    for k in kept:
        print(f"  kept your own completed file: {k}   (use --force to overwrite)")
    return 1 if stale else 0


if __name__ == "__main__":
    args = sys.argv[1:]
    mode = "todo" if "--todo" in args else "check" if "--check" in args else "fill"
    sys.exit(build(mode, force="--force" in args))
