"""Lab 1, Part C: chaos tests for safe_call(). Run: python chaos.py   (add --solution to test the reference)"""
import os
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "solution") if "--solution" in sys.argv else str(HERE))
sys.path.insert(1, str(HERE.parent / "common"))
os.environ["APPROVAL"] = "auto-deny"

import safe_call as sc  # noqa: E402
import tools  # noqa: E402

sc.BACKOFF_SECONDS = 0.01


def call(name, **args):
    return {"name": name, "args": args, "id": "test"}


def t1_unknown_tool():
    return sc.safe_call(call("delete_database")).startswith("ERROR: unknown tool")


def t2_invalid_args_no_crash():
    return sc.safe_call(call("get_order_status", order_id="10293")).startswith("INVALID_ARGS")


def t3_transient_timeout_retried():
    tools.CHAOS["fail_next"] = 2
    out = sc.safe_call(call("get_order_status", order_id="ORD-10293"))
    return '"status": "shipped"' in out


def t4_persistent_timeout_gives_up():
    tools.CHAOS["fail_next"] = 10
    out = sc.safe_call(call("get_order_status", order_id="ORD-10102"))
    tools.CHAOS["fail_next"] = 0
    return out == "ERROR: tool unavailable after retries"


def t5_loop_guard():
    first = sc.safe_call(call("get_order_status", order_id="ORD-10555"))
    second = sc.safe_call(call("get_order_status", order_id="ORD-10555"))
    return "status" in first and second.startswith("ERROR: duplicate call")


def t6_action_needs_approval():
    before = dict(tools.ORDERS["ORD-10555"])
    out = sc.safe_call(call("change_address", order_id="ORD-10555", new_address="12 MG Road, Pune 411001"))
    return out.startswith("DENIED") and tools.ORDERS["ORD-10555"] == before


if __name__ == "__main__":
    tests = [t1_unknown_tool, t2_invalid_args_no_crash, t3_transient_timeout_retried,
             t4_persistent_timeout_gives_up, t5_loop_guard, t6_action_needs_approval]
    passed = 0
    for t in tests:
        sc.reset_run()
        try:
            ok = bool(t())
        except NotImplementedError as e:
            ok, e_msg = False, f"not implemented yet ({e})"
        except Exception as e:  # a crash is a failure: safe_call must never raise
            ok, e_msg = False, f"raised {type(e).__name__}: {e}"
        else:
            e_msg = ""
        passed += ok
        print(f"{'PASS' if ok else 'FAIL'}  {t.__name__}  {e_msg}")
    print(f"\n{passed}/{len(tests)} chaos tests passed")
    sys.exit(0 if passed == len(tests) else 1)
