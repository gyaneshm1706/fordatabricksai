"""Module 1 environment smoke test. Run: python check_env.py"""
import os
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "solution"))
sys.path.insert(1, str(HERE.parent / "common"))

ok = True
print(f"Python {sys.version.split()[0]}")
if sys.version_info < (3, 11):
    print("WARN: Python 3.11+ recommended")

try:
    import langchain_core, langgraph, pydantic  # noqa: F401
    print("LIBS OK")
except ImportError as e:
    ok = False
    print(f"LIBS MISSING: {e}. Run: pip install -r requirements.txt")

try:
    from tools import TOOLS
    assert len(TOOLS) == 4
    print("TOOLS OK")
except Exception as e:
    ok = False
    print(f"TOOLS FAILED: {e}")

model = os.getenv("MODEL", "offline")
try:
    if model == "offline":
        from offline_model import make_offline_model
        llm = make_offline_model()
    else:
        from langchain.chat_models import init_chat_model
        llm = init_chat_model(model, temperature=0)
    reply = llm.bind_tools(TOOLS).invoke("Where is ORD-10293?")
    assert reply.tool_calls, "model did not call a tool; does it support tool calling?"
    print(f"MODEL OK ({model}) -> {reply.tool_calls[0]['name']}")
except Exception as e:
    ok = False
    print(f"MODEL FAILED ({model}): {type(e).__name__}: {e}")

print("\nALL CHECKS PASSED" if ok else "\nFIX THE ITEMS ABOVE")
sys.exit(0 if ok else 1)
