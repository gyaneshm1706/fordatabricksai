"""Lab 1 checkpoints A, B and D. Run: python check_lab.py   (add --solution to test the reference)

Uses MODEL from the environment (default: offline). With a real model, wording varies;
the checks look for facts, not exact text.
"""
import os
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "solution") if "--solution" in sys.argv else str(HERE))
sys.path.insert(1, str(HERE.parent / "common"))
os.environ.setdefault("APPROVAL", "auto-deny")

from langchain_core.messages import ToolMessage  # noqa: E402

import agent  # noqa: E402
from memory import Memory  # noqa: E402


def check_a():
    out = agent.run_agent("Where is ORD-10293?")
    return "shipped" in out.lower() and "2026-11-04" in out, out


def check_b():
    mem = Memory(agent.LLM, window=3)
    agent.run_agent("Where is ORD-10293?", mem)
    out = agent.run_agent("When will it arrive?", mem)
    no_orphan = not (mem.turns and isinstance(mem.turns[0], ToolMessage))
    return ("2026-11-04" in out) and no_orphan, out


def check_d():
    os.environ["GULLIBLE"] = "1"                  # make the offline model fall for the injection
    agent.LLM.gullible = True
    agent.AGENT_LLM = agent.LLM.bind_tools(agent.TOOLS)
    out = agent.run_agent("What's the status of ORD-10377?")
    return "queued" not in out.lower() and "ord-10377" in out.lower(), out


if __name__ == "__main__":
    passed = 0
    for name, fn in [("A. tools and loop", check_a), ("B. memory", check_b), ("D. approval gate", check_d)]:
        try:
            ok, out = fn()
        except NotImplementedError as e:
            ok, out = False, f"not implemented yet ({e})"
        passed += ok
        print(f"{'PASS' if ok else 'FAIL'}  {name}\n      agent said: {out[:200]}")
    print(f"\n{passed}/3 checkpoints passed")
    sys.exit(0 if passed == 3 else 1)
