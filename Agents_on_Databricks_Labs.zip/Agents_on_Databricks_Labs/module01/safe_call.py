"""Module 1: validation, retries, loop guard and approval gate (Lab Part C and D)."""
from __future__ import annotations

import json
import os
import time

from pydantic import ValidationError

from tools import TOOLS

TOOL_MAP = {t.name: t for t in TOOLS}
NEEDS_APPROVAL = {"change_address", "issue_refund"}
BACKOFF_SECONDS = 0.2          # short for the lab; use 1-2 s in production

_seen: set[str] = set()


def reset_run() -> None:
    """Call at the start of every agent run so the loop guard is per run."""
    _seen.clear()


def approve(call: dict) -> bool:
    """Human approval gate. APPROVAL=off disables it (Demo 2, run 1 only)."""
    mode = os.getenv("APPROVAL", "on")
    if mode == "off":
        return True
    if mode in ("auto-deny", "auto-approve"):   # for tests and chaos.py
        return mode == "auto-approve"
    answer = input(f"\nAPPROVE {call['name']} {json.dumps(call['args'])}? [y/N] ")
    return answer.strip().lower() == "y"


def safe_call(call: dict, retries: int = 2) -> str:
    """Run one tool call and always return a string the model can reason about."""
    name, args = call.get("name"), call.get("args") or {}
    tool = TOOL_MAP.get(name)
    if tool is None:
        return f"ERROR: unknown tool {name}. Available: {', '.join(TOOL_MAP)}"

    key = f"{name}:{json.dumps(args, sort_keys=True)}"
    if key in _seen:
        return f"ERROR: duplicate call {name} {json.dumps(args)}; use the earlier result"
    _seen.add(key)

    if name in NEEDS_APPROVAL and not approve({"name": name, "args": args}):
        return f"DENIED: a human did not approve {name}"

    for attempt in range(retries + 1):
        try:
            return str(tool.invoke(args))
        except ValidationError as e:                      # bad input: retrying will not help
            errs = "; ".join(f"{'.'.join(map(str, x['loc']))}: {x['msg']}" for x in e.errors())
            return f"INVALID_ARGS: {errs}"
        except (TimeoutError, ConnectionError):           # transient: back off and retry
            if attempt < retries:
                time.sleep(BACKOFF_SECONDS * 2 ** attempt)
        except Exception as e:                            # anything else: report, never crash the loop
            return f"TOOL_ERROR: {type(e).__name__}: {e}"
    return "ERROR: tool unavailable after retries"
