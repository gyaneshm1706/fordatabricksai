"""Module 1: validation, retries, loop guard and approval gate (Lab Part C and D)."""
from __future__ import annotations

import json
import os
import time

from pydantic import ValidationError

from tools import TOOLS

TOOL_MAP = {t.name: t for t in TOOLS}
NEEDS_APPROVAL = {"change_address", "issue_refund"}
BACKOFF_SECONDS = 0.2          # short for the lab; use 1-2 s in production

_seen: set[str] = set()


def reset_run() -> None:
    """Call at the start of every agent run so the loop guard is per run."""
    _seen.clear()


def approve(call: dict) -> bool:
    """Human approval gate. APPROVAL=off disables it (Demo 2, run 1 only)."""
    mode = os.getenv("APPROVAL", "on")
    if mode == "off":
        return True
    if mode in ("auto-deny", "auto-approve"):   # for tests and chaos.py
        return mode == "auto-approve"
    answer = input(f"\nAPPROVE {call['name']} {json.dumps(call['args'])}? [y/N] ")
    return answer.strip().lower() == "y"


def safe_call(call: dict, retries: int = 2) -> str:
    """Run one tool call and always return a string the model can reason about."""
    # >>> SOLUTION: unknown tool, loop guard, approval, then invoke with validation and retry policies
    tool = TOOL_MAP.get(call["name"])
    if tool is None:
        return f"ERROR: unknown tool {call['name']}"
    sig = call["name"] + json.dumps(call["args"], sort_keys=True)
    if sig in _seen:
        return "ERROR: duplicate call, use the earlier result"
    _seen.add(sig)
    if call["name"] in NEEDS_APPROVAL and not approve(call):
        return "DENIED: a human rejected this action"
    for attempt in range(retries + 1):
        try:
            return str(tool.invoke(call["args"]))
        except ValidationError as e:                    # bad args: the model must fix them
            return f"INVALID_ARGS: {e.errors()[0]['msg']}"
        except (TimeoutError, ConnectionError):         # transient: retry with backoff
            time.sleep(BACKOFF_SECONDS * 2 ** attempt)
    return "ERROR: tool unavailable after retries"
    # >>> STARTER
    # return str(TOOL_MAP[call["name"]].invoke(call["args"]))   # naive version: works for Part A, crashes on bad input
    # <<< SOLUTION
