"""Module 1 tools: the contracts the agent can call (Lab Part A and D)."""
from __future__ import annotations

import json
import os
import pathlib
import re

from langchain_core.tools import tool
from pydantic import BaseModel, Field

ROOT = next(p for p in pathlib.Path(__file__).resolve().parents if (p / "data" / "orders.json").exists())
DATA = json.loads((ROOT / "data" / "orders.json").read_text(encoding="utf-8"))
ORDERS, CUSTOMERS = DATA["orders"], DATA["customers"]
POLICY_DIR = ROOT / "data" / "policies"

# Chaos hooks, used by chaos.py to simulate an unreliable backend.
CHAOS = {"fail_next": 0}


def _maybe_fail() -> None:
    if CHAOS["fail_next"] > 0:
        CHAOS["fail_next"] -= 1
        raise TimeoutError("simulated upstream timeout")


def untrusted(text: str) -> str:
    """Wrap free text that a customer or third party controls (Demo 2, step 6)."""
    if not text or os.getenv("WRAP_UNTRUSTED", "0") != "1":
        return text
    return f"<untrusted_data>{text}</untrusted_data>"


# ---------------------------------------------------------------- read tools
class OrderId(BaseModel):
    order_id: str = Field(pattern=r"^ORD-\d{5}$", description="Order id, e.g. ORD-12345")


@tool(args_schema=OrderId)
def get_order_status(order_id: str) -> str:
    """Get shipping status and ETA for ONE order.
    Use when the customer asks where an order is or when it will arrive.
    Do NOT use for refunds or address changes."""
    _maybe_fail()
    o = ORDERS.get(order_id)
    if o is None:
        return f"NOT_FOUND: no order {order_id}"
    return json.dumps({
        "order_id": order_id,
        "status": o["status"],
        "order_date": o["order_date"],
        "promised_date": o["promised_date"],
        "eta": o["eta"],
        "city": o["city"],
        "tracking_no": o["tracking_no"],
        "delivery_note": untrusted(o["delivery_note"]),
    })


class PolicyQuery(BaseModel):
    topic: str = Field(min_length=3, description="What the customer asks about, e.g. 'refund for late delivery'")


def _sections() -> list[tuple[str, str, str]]:
    """(file, heading, text) for every section of every current (not superseded) policy."""
    out = []
    for path in sorted(POLICY_DIR.glob("*.md")):
        raw = path.read_text(encoding="utf-8")
        if "superseded: true" in raw:
            continue
        body = raw.split("---", 2)[-1]
        for block in re.split(r"\n(?=## )", body):
            lines = block.strip().splitlines()
            if lines and lines[0].startswith("## "):
                out.append((path.name, lines[0][3:].strip(), " ".join(lines[1:]).strip()))
    return out


@tool(args_schema=PolicyQuery)
def get_shipping_policy(topic: str) -> str:
    """Look up company support policies (refunds, late deliveries, shipping, returns,
    address changes). Returns the most relevant policy sections with citations."""
    _maybe_fail()
    words = _keywords(topic)
    scored = [(2 * len(words & _keywords(heading)) + len(words & _keywords(text)), f, heading, text)
              for f, heading, text in _sections()]          # a heading match counts double
    top = [s for s in sorted(scored, key=lambda s: -s[0]) if s[0] > 0][:2]
    if not top:
        return "No policy section matches that topic."
    return "\n".join(f"[{f} > {heading}] {text}" for _, f, heading, text in top)


STOPWORDS = {"the", "and", "for", "what", "how", "can", "you", "your", "are", "with", "that", "this",
             "does", "did", "will", "when", "where", "who", "why", "about", "from", "have", "has", "our", "any",
             "policy", "policie", "get", "please", "tell"}


def _stem(w: str) -> str:
    """Crude stemmer so 'damaged'/'damage' and 'items'/'item' match."""
    for suffix in ("ing", "ed", "es", "s", "e"):
        if len(w) > 4 and w.endswith(suffix):
            return w[: -len(suffix)]
    return w


def _keywords(text: str) -> set[str]:
    """Stemmed lower-case words of 3+ letters, minus stopwords."""
    return {_stem(w) for w in re.findall(r"[a-z]{3,}", text.lower())} - STOPWORDS


# -------------------------------------------------------------- action tools
class AddressChange(OrderId):
    new_address: str = Field(min_length=10, max_length=200, description="Street, city and PIN code")


@tool(args_schema=AddressChange)
def change_address(order_id: str, new_address: str) -> str:
    """ACTION: change the delivery address of an order in status 'placed'.
    Requires human approval. Do not use for shipped orders."""
    o = ORDERS.get(order_id)
    if o is None:
        return f"NOT_FOUND: no order {order_id}"
    if o["status"] != "placed":
        return f"REJECTED: {order_id} is {o['status']}; the address can only change while the order is 'placed'"
    o["address"] = new_address
    return f"OK: delivery address for {order_id} changed to {new_address}"


class Refund(OrderId):
    amount: float = Field(gt=0, le=100000)


@tool(args_schema=Refund)
def issue_refund(order_id: str, amount: float) -> str:
    """ACTION: queue a refund for human processing. Requires human approval."""
    return f"OK: refund of {amount:.2f} for {order_id} queued for a human agent"


READ_TOOLS = [get_order_status, get_shipping_policy]
ACTION_TOOLS = [change_address, issue_refund]
TOOLS = READ_TOOLS + ACTION_TOOLS
