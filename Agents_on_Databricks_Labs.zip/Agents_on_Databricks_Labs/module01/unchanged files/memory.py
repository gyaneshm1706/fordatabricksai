"""Module 1: short-term window, running summary and long-term facts (Lab Part B)."""
from __future__ import annotations

from langchain_core.messages import BaseMessage, SystemMessage, ToolMessage


class Memory:
    def __init__(self, llm, window: int = 8):
        self.llm, self.window = llm, window
        self.summary: str = ""
        self.turns: list[BaseMessage] = []
        self.facts: dict[str, str] = {}             # long-term; persist to a DB in production

    def _cut_index(self) -> int:
        """Index where the kept window starts."""
        cut = len(self.turns) - self.window
        # TODO: never start the window on a ToolMessage (it would be orphaned from its AI tool call)
        pass   # BUG: the window can start on a ToolMessage whose AI tool call was trimmed away
        return cut

    def add(self, msg: BaseMessage) -> None:
        self.turns.append(msg)
        if len(self.turns) > self.window:
            cut = self._cut_index()
            old, self.turns = self.turns[:cut], self.turns[cut:]
            if old:
                self.summary = self.llm.invoke(
                    "Update this summary with the new turns.\n"
                    f"Summary: {self.summary}\nTurns: {[m.content for m in old]}"
                ).content

    def remember(self, key: str, value: str) -> None:
        self.facts[key] = value

    def context(self, instructions: str) -> list[BaseMessage]:
        facts = "\n".join(f"- {k}: {v}" for k, v in self.facts.items()) or "- none"
        return [SystemMessage(f"{instructions}\n\nKnown facts:\n{facts}\n"
                              f"Earlier conversation: {self.summary or 'none'}"),
                *self.turns]
