"""Module 1: validation, retries, loop guard and approval gate (Lab Part C and D)."""
from __future__ import annotations

import json
import os
import time

from pydantic import ValidationError

from tools import TOOLS

TOOL_MAP = {t.name: t for t in TOOLS}
NEEDS_APPROVAL = {"change_address", "issue_refund"}
BACKOFF_SECONDS = 0.2          # short for the lab; use 1-2 s in production

_seen: set[str] = set()


def reset_run() -> None:
    """Call at the start of every agent run so the loop guard is per run."""
    _seen.clear()


def approve(call: dict) -> bool:
    """Human approval gate. APPROVAL=off disables it (Demo 2, run 1 only)."""
    mode = os.getenv("APPROVAL", "on")
    if mode == "off":
        return True
    if mode in ("auto-deny", "auto-approve"):   # for tests and chaos.py
        return mode == "auto-approve"
    answer = input(f"\nAPPROVE {call['name']} {json.dumps(call['args'])}? [y/N] ")
    return answer.strip().lower() == "y"


def safe_call(call: dict, retries: int = 2) -> str:
    """Run one tool call and always return a string the model can reason about."""
    # TODO: unknown tool, loop guard, approval, then invoke with validation and retry policies
    return str(TOOL_MAP[call["name"]].invoke(call["args"]))   # naive version: works for Part A, crashes on bad input
