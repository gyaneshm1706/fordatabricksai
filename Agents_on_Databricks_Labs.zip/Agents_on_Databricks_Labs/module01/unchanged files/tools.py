"""Module 1 tools: the contracts the agent can call (Lab Part A and D)."""
from __future__ import annotations

import json
import os
import pathlib
import re

from langchain_core.tools import tool
from pydantic import BaseModel, Field

ROOT = next(p for p in pathlib.Path(__file__).resolve().parents if (p / "data" / "orders.json").exists())
DATA = json.loads((ROOT / "data" / "orders.json").read_text(encoding="utf-8"))
ORDERS, CUSTOMERS = DATA["orders"], DATA["customers"]
POLICY_DIR = ROOT / "data" / "policies"

# Chaos hooks, used by chaos.py to simulate an unreliable backend.
CHAOS = {"fail_next": 0}


def _maybe_fail() -> None:
    if CHAOS["fail_next"] > 0:
        CHAOS["fail_next"] -= 1
        raise TimeoutError("simulated upstream timeout")


def untrusted(text: str) -> str:
    """Wrap free text that a customer or third party controls (Demo 2, step 6)."""
    if not text or os.getenv("WRAP_UNTRUSTED", "0") != "1":
        return text
    return f"<untrusted_data>{text}</untrusted_data>"


# ---------------------------------------------------------------- read tools
class OrderId(BaseModel):
    order_id: str = Field(pattern=r"^ORD-\d{5}$", description="Order id, e.g. ORD-12345")


@tool(args_schema=OrderId)
def get_order_status(order_id: str) -> str:
    """Get shipping status and ETA for ONE order.
    Use when the customer asks where an order is or when it will arrive.
    Do NOT use for refunds or address changes."""
    # TODO: look up ORDERS; return JSON with status, dates, city, tracking_no and delivery_note; NOT_FOUND if missing
    raise NotImplementedError('TODO: look up ORDERS; return JSON with status, dates, city, tracking_no and delivery_note; NOT_FOUND if missing')


class PolicyQuery(BaseModel):
    topic: str = Field(min_length=3, description="What the customer asks about, e.g. 'refund for late delivery'")


def _sections() -> list[tuple[str, str, str]]:
    """(file, heading, text) for every section of every current (not superseded) policy."""
    out = []
    for path in sorted(POLICY_DIR.glob("*.md")):
        raw = path.read_text(encoding="utf-8")
        if "superseded: true" in raw:
            continue
        body = raw.split("---", 2)[-1]
        for block in re.split(r"\n(?=## )", body):
            lines = block.strip().splitlines()
            if lines and lines[0].startswith("## "):
                out.append((path.name, lines[0][3:].strip(), " ".join(lines[1:]).strip()))
    return out


@tool(args_schema=PolicyQuery)
def get_shipping_policy(topic: str) -> str:
    """Look up company support policies (refunds, late deliveries, shipping, returns,
    address changes). Returns the most relevant policy sections with citations."""
    # TODO: score each section by keyword overlap with the topic; return the top 2 as "[file > heading] text"
    raise NotImplementedError('TODO: score each section by keyword overlap with the topic; return the top 2 as "[file > heading] text"')


# -------------------------------------------------------------- action tools
class AddressChange(OrderId):
    new_address: str = Field(min_length=10, max_length=200, description="Street, city and PIN code")


@tool(args_schema=AddressChange)
def change_address(order_id: str, new_address: str) -> str:
    """ACTION: change the delivery address of an order in status 'placed'.
    Requires human approval. Do not use for shipped orders."""
    # TODO: reject unknown or non-'placed' orders; otherwise update the address and return OK
    raise NotImplementedError("TODO: reject unknown or non-'placed' orders; otherwise update the address and return OK")


class Refund(OrderId):
    amount: float = Field(gt=0, le=100000)


@tool(args_schema=Refund)
def issue_refund(order_id: str, amount: float) -> str:
    """ACTION: queue a refund for human processing. Requires human approval."""
    return f"OK: refund of {amount:.2f} for {order_id} queued for a human agent"


READ_TOOLS = [get_order_status, get_shipping_policy]
ACTION_TOOLS = [change_address, issue_refund]
TOOLS = READ_TOOLS + ACTION_TOOLS
