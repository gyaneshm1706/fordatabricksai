"""API adapters: a real HTTP client with guardrails, and an offline fake with the same contract."""
from __future__ import annotations

import time


def _wrap(text: str) -> str:
    return f"<untrusted_data>{text}</untrusted_data>"


class ShippingApi:
    def __init__(self, base_url: str, timeout: float = 5.0, retries: int = 3):
        import httpx
        self.httpx = httpx
        self.http = httpx.Client(base_url=base_url, timeout=timeout)
        self.retries = retries

    def track(self, tracking_no: str) -> str:
        # GET with timeout; retry only transport errors with backoff; return wrapped fields
        for attempt in range(self.retries):
            try:
                r = self.http.get(f"/track/{tracking_no}")
                r.raise_for_status()
                data = r.json()
                return _wrap(f"{data.get('status')} {data.get('last_scan')}")
            except self.httpx.TransportError:
                time.sleep(0.5 * 2 ** attempt)
            except self.httpx.HTTPStatusError as e:
                return f"ERROR: shipping API returned {e.response.status_code}"
        return "ERROR: shipping API unavailable"


class FakeShippingApi:
    """Offline stand-in that returns plausible scans for known tracking numbers."""

    SCANS = {"TRK-88812": "in transit, last scan Mumbai hub", "TRK-88907": "delivered, signed by reception",
             "TRK-88950": "delivered", "TRK-87001": "delivered", "TRK-89120": "out for delivery"}

    def __init__(self, **_):
        pass

    def track(self, tracking_no: str) -> str:
        scan = self.SCANS.get(tracking_no)
        return _wrap(scan) if scan else f"NOT_FOUND: tracking number {tracking_no}"
