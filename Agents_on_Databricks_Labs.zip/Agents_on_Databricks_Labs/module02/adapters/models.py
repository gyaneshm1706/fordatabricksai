"""ChatModel adapters. Each exposes `.chat` (a LangChain chat model) and `.check()` (fail fast)."""
from __future__ import annotations

from core.paths import ROOT  # noqa: F401  (adds common/ to sys.path)
from core.ports import ConfigError


class _Base:
    provider = "base"

    def __init__(self, name: str, temperature: float = 0.0, **kwargs):
        self.name, self.temperature, self.kwargs = name, temperature, kwargs
        self.chat = self._build()

    def _build(self):
        from langchain.chat_models import init_chat_model
        try:
            return init_chat_model(f"{self.provider}:{self.name}", temperature=self.temperature, **self.kwargs)
        except ImportError as e:
            raise ConfigError(f"{self.provider} adapter needs its integration package: {e}") from e

    def check(self) -> None:
        """One tiny call so misconfiguration fails at start-up, not on the first customer."""
        try:
            self.chat.invoke("ping", max_tokens=5) if self.provider != "ollama" else self.chat.invoke("ping")
        except Exception as e:  # translate vendor errors into our own error type
            raise ConfigError(f"model {self.name} not available for provider {self.provider}: "
                              f"{type(e).__name__}: {str(e)[:160]}") from e

    def __repr__(self) -> str:
        return f"{self.provider}/{self.name}"


class Anthropic(_Base):
    provider = "anthropic"


class OpenAI(_Base):
    provider = "openai"


class Ollama(_Base):
    provider = "ollama"


class Databricks(_Base):
    """Module 3 preview: a Databricks serving endpoint through databricks-langchain."""
    provider = "databricks"

    def _build(self):
        try:
            from databricks_langchain import ChatDatabricks
        except ImportError as e:
            raise ConfigError("pip install databricks-langchain to use the Databricks adapter") from e
        return ChatDatabricks(endpoint=self.name, temperature=self.temperature)


class Offline(_Base):
    """Deterministic rule-based model (no network). See common/offline_model.py."""
    provider = "offline"

    def _build(self):
        from offline_model import make_offline_model
        return make_offline_model()

    def check(self) -> None:
        return None
