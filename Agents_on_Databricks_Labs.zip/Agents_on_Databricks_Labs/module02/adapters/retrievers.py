"""Retriever adapters: Keyword (offline, no deps), Chroma and FAISS (vector stores)."""
from __future__ import annotations

import math
import re
from collections import Counter

from core.paths import DATA
from core.ports import ConfigError, Doc


def load_policy_chunks(include_superseded: bool = False) -> list[Doc]:
    """Heading-aware chunks: one chunk per '## ' section, with metadata for filters and citations."""
    docs = []
    for path in sorted((DATA / "policies").glob("*.md")):
        raw = path.read_text(encoding="utf-8")
        _, front, body = raw.split("---", 2)
        meta = dict(line.split(": ", 1) for line in front.strip().splitlines())
        if meta.get("superseded") == "true" and not include_superseded:
            continue
        for block in re.split(r"\n(?=## )", body):
            lines = block.strip().splitlines()
            if lines and lines[0].startswith("## "):
                section = lines[0][3:].strip()
                docs.append(Doc(text=" ".join(lines[1:]).strip(), source=f"{path.name} > {section}",
                                metadata={**meta, "file": path.name, "section": section}))
    return docs


def _tokens(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]{3,}", text.lower())


def _match(doc: Doc, filters: dict | None) -> bool:
    for k, v in (filters or {}).items():
        allowed = v if isinstance(v, (list, tuple, set)) else [v]
        if doc.metadata.get(k) not in allowed:
            return False
    return True


class Keyword:
    """BM25-style keyword retriever over the policy chunks. Offline and dependency-free."""

    def __init__(self, k: int = 4, min_score: float = 0.2):
        self.k, self.min_score = k, min_score
        self.docs = load_policy_chunks()
        self.tf = [Counter(_tokens(d.metadata["section"] + " " + d.text)) for d in self.docs]
        n = len(self.docs)
        df = Counter(t for tf in self.tf for t in tf)
        self.idf = {t: math.log(1 + (n - c + 0.5) / (c + 0.5)) for t, c in df.items()}
        self.avg = sum(sum(tf.values()) for tf in self.tf) / max(n, 1)

    def search(self, query: str, k: int | None = None, filters: dict | None = None) -> list[Doc]:
        # Score with BM25, apply filters and min_score, return the top k as Doc objects
        q = _tokens(query)
        scored = []
        for doc, tf in zip(self.docs, self.tf):
            if not _match(doc, filters):
                continue
            length = sum(tf.values())
            s = sum(self.idf.get(t, 0) * tf[t] * 2.2 / (tf[t] + 1.2 * (0.25 + 0.75 * length / self.avg)) for t in q)
            scored.append((s, doc))
        scored.sort(key=lambda x: -x[0])
        top = scored[0][0] if scored else 0
        return [Doc(d.text, d.source, round(s / top, 3) if top else 0.0, d.metadata)
                for s, d in scored[: k or self.k] if top and s / top >= self.min_score]


class Chroma:
    """Vector retriever. Build the index first with: python ingest.py --store chroma"""

    def __init__(self, path: str = "./data/chroma", k: int = 4, min_score: float = 0.35, embedding: str | None = None):
        try:
            from langchain_chroma import Chroma as _Chroma
        except ImportError as e:
            raise ConfigError("pip install langchain-chroma to use the Chroma adapter") from e
        if not (DATA.parent / path).exists():
            raise ConfigError(f"no Chroma index at {path}; run: python ingest.py")
        self.db = _Chroma(persist_directory=str(DATA.parent / path), embedding_function=make_embeddings(embedding))
        self.k, self.min_score = k, min_score

    def search(self, query: str, k: int | None = None, filters: dict | None = None) -> list[Doc]:
        hits = self.db.similarity_search_with_relevance_scores(query, k=k or self.k, filter=filters or None)
        return [Doc(d.page_content, d.metadata["source"], s, d.metadata) for d, s in hits if s >= self.min_score]


class FAISS:
    """In-memory FAISS index built at start-up (re-embeds every run; fine for the lab)."""

    def __init__(self, k: int = 4, min_score: float = 0.35, embedding: str | None = None):
        try:
            from langchain_community.vectorstores import FAISS as _FAISS
        except ImportError as e:
            raise ConfigError("pip install langchain-community faiss-cpu to use the FAISS adapter") from e
        docs = load_policy_chunks()
        self.db = _FAISS.from_texts([d.text for d in docs], make_embeddings(embedding),
                                    metadatas=[{**d.metadata, "source": d.source} for d in docs])
        self.k, self.min_score = k, min_score

    def search(self, query: str, k: int | None = None, filters: dict | None = None) -> list[Doc]:
        hits = self.db.similarity_search_with_relevance_scores(query, k=k or self.k, filter=filters or None)
        return [Doc(d.page_content, d.metadata["source"], s, d.metadata) for d, s in hits if s >= self.min_score]


def make_embeddings(name: str | None):
    """'ollama:nomic-embed-text', 'openai:text-embedding-3-small', ... (changing it means re-indexing)."""
    name = name or "ollama:nomic-embed-text"
    try:
        from langchain.embeddings import init_embeddings
        return init_embeddings(name)
    except Exception as e:
        raise ConfigError(f"embedding model {name} unavailable: {e}") from e
