"""Tracer adapters: Console (no deps), Langfuse (open source, self-hostable) and Null."""
from __future__ import annotations

import time
from contextlib import contextmanager
from typing import Any

from langchain_core.callbacks import BaseCallbackHandler

from core.ports import ConfigError


class _ConsoleHandler(BaseCallbackHandler):
    """Prints a span per model and tool call, with latency and token usage."""

    def __init__(self):
        self.t0: dict[Any, float] = {}

    def on_chat_model_start(self, serialized, messages, *, run_id, **kw):
        self.t0[run_id] = time.perf_counter()

    def on_llm_end(self, response, *, run_id, **kw):
        ms = (time.perf_counter() - self.t0.pop(run_id, time.perf_counter())) * 1000
        msg = response.generations[0][0].message
        usage = getattr(msg, "usage_metadata", None) or {}
        calls = [c["name"] for c in (getattr(msg, "tool_calls", None) or [])]
        what = f"tool_calls={calls}" if calls else "final answer"
        print(f"  span LLM   {ms:7.1f} ms  tokens={usage.get('total_tokens', '?'):>5}  {what}")

    def on_tool_start(self, serialized, input_str, *, run_id, **kw):
        self.t0[run_id] = time.perf_counter()
        self.names = getattr(self, "names", {})
        self.names[run_id] = (serialized or {}).get("name", "tool")

    def on_tool_end(self, output, *, run_id, **kw):
        ms = (time.perf_counter() - self.t0.pop(run_id, time.perf_counter())) * 1000
        text = getattr(output, "content", output)
        print(f"  span TOOL  {ms:7.1f} ms  {self.names.pop(run_id, 'tool'):<16} -> {str(text)[:90]}")


class Console:
    def __init__(self, **_):
        self.handler = _ConsoleHandler()

    def callbacks(self) -> list:
        return [self.handler]

    @contextmanager
    def span(self, name: str, **attrs):
        t0 = time.perf_counter()
        print(f"trace {name} {attrs}")
        yield
        print(f"trace {name} done in {(time.perf_counter() - t0) * 1000:.0f} ms")

    def flush(self) -> None:
        pass


class Langfuse:
    """Needs LANGFUSE_PUBLIC_KEY, LANGFUSE_SECRET_KEY and LANGFUSE_HOST in the environment."""

    def __init__(self, **_):
        try:
            from langfuse import get_client
            from langfuse.langchain import CallbackHandler
        except ImportError as e:
            raise ConfigError("pip install 'langfuse>=3' to use the Langfuse tracer") from e
        self.client = get_client()
        self.handler = CallbackHandler()

    def callbacks(self) -> list:
        return [self.handler]

    @contextmanager
    def span(self, name: str, **attrs):
        with self.client.start_as_current_span(name=name) as span:
            span.update_trace(tags=[f"{k}={v}" for k, v in attrs.items()], metadata=attrs)
            yield

    def flush(self) -> None:
        self.client.flush()


class Null:
    def __init__(self, **_):
        pass

    def callbacks(self) -> list:
        return []

    @contextmanager
    def span(self, name: str, **attrs):
        yield

    def flush(self) -> None:
        pass
