"""Module 2 entry point.

  python app.py "Where is ORD-10293?"                 # AGENT_ENV=offline by default
  AGENT_ENV=cloud python app.py "Is ORD-10377 late, and what does the policy say about late orders?"
  python app.py --questions questions.txt              # Lab Part C
"""
from __future__ import annotations

import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))

from core.graph import build_agent, run_traced  # noqa: E402
from core.ports import ConfigError  # noqa: E402


def main(argv: list[str]) -> int:
    try:
        app = build_agent()
    except ConfigError as e:
        print(f"CONFIG ERROR: {e}")
        return 2
    print(f"env={app.env}  model={app.ports['model']!r}  retriever={type(app.ports['retriever']).__name__}")
    if argv[:1] == ["--questions"]:
        questions = [q.strip() for q in pathlib.Path(argv[1]).read_text(encoding="utf-8").splitlines() if q.strip()]
    else:
        questions = [" ".join(argv) or "Is ORD-10377 late, and what does the policy say about late orders?"]
    for q in questions:
        print(f"\nQ: {q}")
        r = run_traced(app, q)
        print(f"A: {r.answer}\n   tools={r.tools_called} sources={r.sources}")
    app.ports["tracer"].flush()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
