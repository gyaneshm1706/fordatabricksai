"""Ports: the only interfaces the portable core depends on."""
from __future__ import annotations

from contextlib import AbstractContextManager
from dataclasses import dataclass, field
from typing import Any, Protocol


class ConfigError(RuntimeError):
    """Raised by adapters and the factory for configuration problems (readable, vendor-neutral)."""


@dataclass
class Doc:
    text: str
    source: str                                   # for citations, e.g. "refunds.md > Late deliveries"
    score: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


class ChatModel(Protocol):
    chat: Any                                     # a LangChain BaseChatModel (common interface)

    def check(self) -> None: ...                  # fail fast on start-up


class Retriever(Protocol):
    def search(self, query: str, k: int | None = None, filters: dict | None = None) -> list[Doc]: ...


class OrdersStore(Protocol):
    def get_order(self, order_id: str) -> str: ...


class ShippingApi(Protocol):
    def track(self, tracking_no: str) -> str: ...


class Tracer(Protocol):
    def callbacks(self) -> list: ...              # LangChain callback handlers for the run

    def span(self, name: str, **attrs: Any) -> AbstractContextManager: ...

    def flush(self) -> None: ...
