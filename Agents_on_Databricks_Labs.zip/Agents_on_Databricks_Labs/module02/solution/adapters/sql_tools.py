"""Structured-data adapter: read-only, parameterised SQL over SQLite."""
from __future__ import annotations

import json
import sqlite3

from core.paths import DATA


def build_db(path=DATA / "shop.db") -> None:
    """Create data/shop.db from data/orders.json (idempotent)."""
    data = json.loads((DATA / "orders.json").read_text(encoding="utf-8"))
    con = sqlite3.connect(path)
    con.executescript("""
        DROP TABLE IF EXISTS orders; DROP TABLE IF EXISTS customers;
        CREATE TABLE customers (id TEXT PRIMARY KEY, name TEXT, tier TEXT, region TEXT);
        CREATE TABLE orders (id TEXT PRIMARY KEY, customer_id TEXT, status TEXT, order_date TEXT,
                             promised_date TEXT, eta TEXT, city TEXT, region TEXT, amount REAL,
                             tracking_no TEXT, delivery_note TEXT);""")
    con.executemany("INSERT INTO customers VALUES (?,?,?,?)",
                    [(k, v["name"], v["tier"], v["region"]) for k, v in data["customers"].items()])
    con.executemany("INSERT INTO orders VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    [(k, v["customer_id"], v["status"], v["order_date"], v["promised_date"], v["eta"],
                      v["city"], v["region"], v["amount"], v["tracking_no"], v["delivery_note"])
                     for k, v in data["orders"].items()])
    con.commit()
    con.close()


class SqliteOrders:
    def __init__(self, dsn: str = "file:data/shop.db?mode=ro", max_rows: int = 50):
        db_file = DATA / "shop.db"
        if not db_file.exists():
            build_db(db_file)
        dsn = dsn.replace("file:data/", f"file:{DATA.as_posix()}/")
        # >>> SOLUTION: open the connection read-only (mode=ro in the DSN) and keep max_rows
        self.con = sqlite3.connect(dsn, uri=True, check_same_thread=False)
        self.max_rows = max_rows
        # <<< SOLUTION

    def get_order(self, order_id: str) -> str:
        # >>> SOLUTION: parameterised query joined to customers; NOT_FOUND if no rows; JSON otherwise
        cur = self.con.execute(
            "SELECT o.id AS order_id, o.status, o.promised_date, o.eta, o.city, o.tracking_no, "
            "c.tier AS customer_tier, o.delivery_note "
            "FROM orders o JOIN customers c ON c.id = o.customer_id WHERE o.id = ?", (order_id,))
        rows = cur.fetchmany(self.max_rows)
        if not rows:
            return f"NOT_FOUND: {order_id}"
        cols = [c[0] for c in cur.description]
        return json.dumps([dict(zip(cols, r)) for r in rows])
        # <<< SOLUTION

    def tracking_no(self, order_id: str) -> str | None:
        row = self.con.execute("SELECT tracking_no FROM orders WHERE id = ?", (order_id,)).fetchone()
        return row[0] if row else None
