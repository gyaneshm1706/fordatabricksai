"""Build adapters from config/<env>.yaml. The core never imports a vendor SDK directly."""
from __future__ import annotations

import os
import pathlib

import yaml

from adapters import api_tools, models, retrievers, sql_tools, tracers
from core.ports import ConfigError

CONFIG_DIR = pathlib.Path(__file__).resolve().parents[1] / "config"

REGISTRY = {
    "model": {"offline": models.Offline, "anthropic": models.Anthropic, "openai": models.OpenAI,
              "ollama": models.Ollama, "databricks": models.Databricks},
    "retriever": {"keyword": retrievers.Keyword, "chroma": retrievers.Chroma, "faiss": retrievers.FAISS},
    "sql": {"sqlite": sql_tools.SqliteOrders},
    "api": {"http": api_tools.ShippingApi, "fake": api_tools.FakeShippingApi},
    "tracer": {"console": tracers.Console, "langfuse": tracers.Langfuse, "none": tracers.Null},
}


def read_config(env: str) -> dict:
    path = CONFIG_DIR / f"{env}.yaml"
    if not path.exists():
        raise ConfigError(f"no config for AGENT_ENV={env} (expected {path})")
    cfg = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    parent = cfg.pop("extends", None)
    if parent:                                    # cloud.yaml can list only what differs
        base = read_config(parent)
        for port, spec in cfg.items():
            base[port] = spec if "adapter" in spec else {**base.get(port, {}), **spec}
        cfg = base
    return cfg


def load(env: str | None = None, fail_fast: bool = True) -> dict:
    env = env or os.getenv("AGENT_ENV", "offline")
    cfg = read_config(env)
    built = {"env": env}
    # >>> SOLUTION: for each port, pop the 'adapter' name, look it up in REGISTRY and construct it with the remaining keys
    for port, impls in REGISTRY.items():
        spec = dict(cfg.get(port) or {})
        name = spec.pop("adapter", None)
        if name not in impls:
            raise ConfigError(f"{env}.yaml: {port}.adapter must be one of {sorted(impls)}, got {name!r}")
        built[port] = impls[name](**spec)
    # <<< SOLUTION
    if fail_fast:
        built["model"].check()
    return built
