"""Locate the lab repository root (the folder that contains data/orders.json)."""
import pathlib
import sys


def repo_root() -> pathlib.Path:
    p = pathlib.Path(__file__).resolve()
    for parent in p.parents:
        if (parent / "data" / "orders.json").exists():
            return parent
    raise FileNotFoundError("data/orders.json not found above " + str(p))


ROOT = repo_root()
DATA = ROOT / "data"
if str(ROOT / "common") not in sys.path:
    sys.path.append(str(ROOT / "common"))
