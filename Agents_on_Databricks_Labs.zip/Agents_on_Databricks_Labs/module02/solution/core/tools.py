"""Wrap ports as LangChain tools with typed contracts (same rules as Module 1)."""
from __future__ import annotations

from langchain_core.tools import tool
from pydantic import BaseModel, Field


class OrderId(BaseModel):
    order_id: str = Field(pattern=r"^ORD-\d{5}$", description="Order id, e.g. ORD-12345")


class PolicyQuery(BaseModel):
    query: str = Field(min_length=3, description="The customer's policy question in plain words")
    region: str | None = Field(default=None, description="Customer region code, e.g. IN or US, if known")


def build_tools(retriever, sql, api) -> list:
    @tool("get_order", args_schema=OrderId)
    def get_order(order_id: str) -> str:
        """Get status, promised date, ETA and customer tier for ONE order.
        Use when the customer asks where an order is, or whether it is late."""
        return sql.get_order(order_id)

    @tool("search_policy", args_schema=PolicyQuery)
    def search_policy(query: str, region: str | None = None) -> str:
        """Search current support policies (refunds, late deliveries, shipping, returns, address changes).
        Returns sections as '[file > section] text'. Cite them in the answer."""
        # >>> SOLUTION: filter by region (plus GLOBAL) when given; NOT_FOUND when nothing relevant; cite sources
        filters = {"region": [region, "GLOBAL"]} if region else None
        docs = retriever.search(query, filters=filters)
        if not docs:
            return "NOT_FOUND: no relevant policy"
        return "\n".join(f"[{d.source}] {d.text}" for d in docs)
        # <<< SOLUTION

    @tool("track_shipment", args_schema=OrderId)
    def track_shipment(order_id: str) -> str:
        """Live carrier tracking for a SHIPPED order. Read-only."""
        tracking_no = sql.tracking_no(order_id)
        if not tracking_no:
            return f"NOT_FOUND: {order_id} has no tracking number (not shipped yet)"
        return api.track(tracking_no)

    return [get_order, search_policy, track_shipment]
