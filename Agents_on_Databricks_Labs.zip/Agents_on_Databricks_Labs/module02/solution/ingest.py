"""Lab 2, Part B: index the policy chunks into Chroma (needed for AGENT_ENV=local).

  python ingest.py                                  # uses ollama:nomic-embed-text
  python ingest.py --embedding openai:text-embedding-3-small
Changing the embedding model means re-running this: vectors from different models are not comparable.
"""
import argparse
import pathlib
import shutil
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))

from adapters.retrievers import load_policy_chunks, make_embeddings  # noqa: E402
from core.paths import DATA  # noqa: E402

p = argparse.ArgumentParser()
p.add_argument("--embedding", default="ollama:nomic-embed-text")
p.add_argument("--path", default="data/chroma")
args = p.parse_args()

from langchain_chroma import Chroma  # noqa: E402

target = DATA.parent / args.path
shutil.rmtree(target, ignore_errors=True)
docs = load_policy_chunks()
Chroma.from_texts(texts=[d.text for d in docs],
                  metadatas=[{**d.metadata, "source": d.source} for d in docs],
                  embedding=make_embeddings(args.embedding),
                  persist_directory=str(target))
print(f"indexed {len(docs)} chunks from {DATA / 'policies'} into {target}")
