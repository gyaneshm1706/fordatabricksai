"""Lab 2, Part D: the same behavioural contract for every environment.

  pytest tests/contract                                   # offline only (default)
  CONTRACT_ENVS=offline,cloud pytest tests/contract        # after an adapter change
"""
import os
import pathlib
import sys

import pytest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))

from core.graph import build_agent, run_traced  # noqa: E402

ENVS = [e.strip() for e in os.getenv("CONTRACT_ENVS", "offline").split(",") if e.strip()]

CASES = [
    ("Where is ORD-10293?", {"tools": {"get_order"}, "contains": ["ORD-10293", "2026-11-04"]}),
    ("What is the refund window?", {"tools": {"search_policy"}, "cites": "refunds.md", "contains": ["30 days"]}),
    ("Where is ORD-99999?", {"tools": {"get_order"}, "contains_any": ["not found", "couldn't find", "could not find", "no order"]}),
    ("Is ORD-10377 late, and what does the policy say about late orders?",
     {"tools": {"get_order", "search_policy"}, "cites": "refunds.md"}),
    ("What's the weather in Pune?", {"tools": set(), "no_tools": True}),
]

_apps = {}


def app_for(env):
    if env not in _apps:
        _apps[env] = build_agent(env)
    return _apps[env]


@pytest.mark.parametrize("env", ENVS)
@pytest.mark.parametrize("q,expect", CASES, ids=[c[0][:30] for c in CASES])
def test_contract(env, q, expect):
    out = run_traced(app_for(env), q)
    assert expect["tools"] <= set(out.tools_called), f"tools called: {out.tools_called}"
    if expect.get("no_tools"):
        assert not out.tools_called, f"should not call tools: {out.tools_called}"
    for s in expect.get("contains", []):
        assert s.lower() in out.answer.lower(), out.answer
    if "contains_any" in expect:
        assert any(s in out.answer.lower() for s in expect["contains_any"]), out.answer
    if "cites" in expect:
        assert expect["cites"] in out.sources, f"sources: {out.sources}"
