"""Run every local lab (Modules 1-2) end to end and save the output.

  python run_local_labs.py            # writes outputs/local_labs_output.txt
Uses MODEL / AGENT_ENV from the environment; defaults to the offline model (no key or network needed).
"""
import datetime
import os
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent
OUT = ROOT / "outputs" / "local_labs_output.txt"

STEPS = [
    # (title, working dir, args, extra env)
    ("Module 1 · environment check", "module01", ["check_env.py"], {}),
    ("Module 1 · Lab Part C: chaos tests", "module01", ["chaos.py"], {}),
    ("Module 1 · Lab checkpoints A, B, D", "module01", ["check_lab.py"], {}),
    ("Module 1 · Demo 1: one tool call, full trace", "module01", ["agent.py", "Where is ORD-10293?"], {"VERBOSE": "1"}),
    ("Module 1 · Demo 1: parallel tool calls", "module01", ["agent.py", "Compare ORD-10293 and ORD-10377"], {"VERBOSE": "1"}),
    ("Module 1 · Demo 1: out of scope (no tool)", "module01", ["agent.py", "What's the weather in Pune?"], {}),
    ("Module 1 · Demo 1: hard stop (MAX_STEPS=1)", "module01", ["agent.py", "Compare ORD-10293 and ORD-10377"], {"MAX_STEPS": "1"}),
    ("Module 1 · policy question with citation", "module01", ["agent.py", "Can I get a refund on a late order?"], {}),
    ("Module 1 · Demo 2 run 1: injection succeeds (APPROVAL=off)", "module01", ["agent.py", "Status of ORD-10377?"],
     {"GULLIBLE": "1", "APPROVAL": "off", "VERBOSE": "1"}),
    ("Module 1 · Demo 2 run 2: approval gate denies it", "module01", ["agent.py", "Status of ORD-10377?"],
     {"GULLIBLE": "1", "APPROVAL": "auto-deny", "VERBOSE": "1"}),
    ("Module 1 · Demo 2 run 3: untrusted-data wrapper", "module01", ["agent.py", "Status of ORD-10377?"],
     {"GULLIBLE": "1", "APPROVAL": "off", "WRAP_UNTRUSTED": "1", "VERBOSE": "1"}),
    ("Module 2 · Lab Parts A-C: five questions with console tracing", "module02", ["app.py", "--questions", "questions.txt"], {}),
    ("Module 2 · Demo 3: a bad config fails fast with a readable error", "module02", ["app.py", "Where is ORD-10293?"],
     {"AGENT_ENV": "does-not-exist"}),
    ("Module 2 · Lab Part D: contract tests", "module02", ["-m", "pytest", "tests/contract", "-v", "-p", "no:cacheprovider"], {}),
]


def main() -> int:
    OUT.parent.mkdir(exist_ok=True)
    lines = [f"Local lab run {datetime.datetime.now():%Y-%m-%d %H:%M}  python {sys.version.split()[0]}  "
             f"MODEL={os.getenv('MODEL', 'offline')}  AGENT_ENV={os.getenv('AGENT_ENV', 'offline')}", ""]
    failures = 0
    for title, cwd, args, env in STEPS:
        e = {**os.environ, "PYTHONWARNINGS": "ignore", "PYTHONIOENCODING": "utf-8", **env}
        p = subprocess.run([sys.executable, *args], cwd=ROOT / cwd, env=e, capture_output=True, text=True,
                           encoding="utf-8", timeout=300)
        expected_fail = "does-not-exist" in env.get("AGENT_ENV", "")
        ok = (p.returncode == 0) != expected_fail
        failures += not ok
        flags = " ".join(f"{k}={v}" for k, v in env.items())
        lines += ["=" * 100, f"{'OK  ' if ok else 'FAIL'} {title}",
                  f"$ {flags + ' ' if flags else ''}python {' '.join(args)}   (in {cwd}/, exit {p.returncode})", "-" * 100,
                  (p.stdout + p.stderr).rstrip(), ""]
        print(f"{'OK  ' if ok else 'FAIL'} {title}")
    lines.append(f"SUMMARY: {len(STEPS) - failures}/{len(STEPS)} steps behaved as expected")
    OUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"\n{len(STEPS) - failures}/{len(STEPS)} steps OK. Full output: {OUT}")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
